<?php
defined('_NOAH') or die('Restricted access');
class ItemDetailsPresentation extends DetailsPresentation
{

function processContent(&$tpl)
{
    global $lll,$gorumroll,$list2Colors;
    
    $tpl->zebraDetails = $this->zebraDetails;
    $tpl->listAndMethod = "$gorumroll->list-$gorumroll->method";
    $tpl->detailsMethods = "";
    $class = $this->base->get_class();
    $attrs=$this->typ["attributes"];
    $this->base->hasGeneralRights($rights);
    $attributeList = isset($this->typ["order"]) ?
                     $this->typ["order"] : array_keys($this->typ["attributes"]);
    $tpl->headerMethods=array();
    if( $s=$this->base->showModTool($rights) ) $tpl->headerMethods[]=$s;
    if( $s=$this->base->showDelTool($rights) ) $tpl->headerMethods[]=$s;

    $tpl->title = sprintf($lll["detail_info"],ucfirst($lll[$class]));
    
    $tpl->rows = array();
    $tpl->pictures = array();
    $tpl->sideBarContent = array("fields"=>array(), "top"=>array(), "bottom"=>array());
    $tpl->mainPicture = "";
    $picFieldExists = FALSE;
    foreach( $attributeList as $attr )
    {
        $val = & $this->typ["attributes"][$attr];
        if ( in_array("details",$val) )
        {
            if( isset($val["sidebar"]) )
            {
                $tpl->sideBarContent["fields"][] = $attr;
                $tpl->sideBarContent[$val["sidebar"]][] = $this->base->showListVal($attr);
            }
            if( in_array("section",$val) )
            {
                if( isset($lll[$attr]) )$tpl->rows[$attr]=array("separator"=>$lll[$attr]);
            }
            elseif( in_array("widecontent_details",$val) )
            {
                if( !($valTxt=$this->base->showListVal($attr)) ) $valTxt="&nbsp;";
                $tpl->rows[$attr]=array("widecontent"=>$valTxt);
            }
            elseif( in_array("notable",$val) )
            {
                $valTxt=$this->base->showListVal($attr);
                $tpl->rows[$attr]=array("notable"=>$valTxt);
            }
            else
            {
                if( !in_array("file",$val) || in_array("media",$val) )
                {
                    $lllProp =& new LllProperties( $this->base, $attr );
                    $txt = $lllProp->getLabel();
                    if( ($valTxt=$this->base->showListVal($attr))==="" ) $valTxt="&nbsp;";
                    $tpl->rows[$attr]=array("label"=>$txt, "value"=>$valTxt);
                }
                else
                {
                      $picFieldExists = TRUE;
                      if( in_array("pictureTag",$val) ) $tpl->mainPicture = $this->base->showPicture($attr, "large");
                      $pic = $this->base->showPicture($attr, "small");
                      if( $pic["tag"] )
                      {
                          $tpl->pictures[]=$pic;
                      }
                }
            }    
        }
    }
    if( !$picFieldExists ) $tpl->pictures=FALSE;
    if( $picFieldExists && empty($tpl->mainPicture["tag"]) )
    {
        if( count($tpl->pictures) ) $tpl->mainPicture = $tpl->pictures[0];
        else $tpl->mainPicture["tag"] = $this->base->showEmptyPicture();
    }
}

} // end class
?>
