<?php
defined('_NOAH') or die('Restricted access');

class ControlPanel extends Object
{

function hasObjectRights(&$hasRight, $method, $giveError=FALSE)
{
    hasAdminRights($isAdm);
    $hasRight->objectRight = $isAdm;
    if( !$hasRight && $giveError )
    {
        handleError($lll["permission_denied"]);
    }
}

function showHtmlList()
{
    global $lll;

    hasAdminRights($isAdm);
    if( !$isAdm ) LocationHistory::rollBack(new AppController("/"));
    JavaScript::addCss(CSS_DIR . "/category.css");
    $catArr = array();
    $adminsettCtrl =& new AppController("settings/modify_form");
    $contentManagementCtrl =& new AppController("content/modify_form");
    $usersCtrl =& new AppController("user/list");
    $NotificationsCtrl =& new AppController("notification/list");
    $checkconfCtrl =& new AppController("checkconf/show");
    $checkUpdatesCtrl =& new AppController("checkconf/updates");
    $customListsCtrl =& new AppController("customlist/list");
    $rssCtrl =& new AppController("rss/modify_form/1");
    $items = array("adminsett", "contentManagement", "users", "Notifications", "customLists", "checkconf", "checkUpdates");
    if( class_exists("rss") ) $items[]="rss";
    foreach( $items as $item )
    {
        $catArr[]=array(
            "title"=>$lll[$item],
            "description"=>$lll["{$item}Description"],
            "link"=>${$item."Ctrl"}->makeUrl(),
            "picture"=>""
        );
    }
    View::assign( "categories", $catArr );
}

}

?>