<?php
defined('_NOAH') or die('Restricted access');
$subscription_typ =
    array(
        "attributes"=>array(
            "id"=>array(
                "type"=>"INT",
                "auto increment",
                "form hidden"
            ),
            "cid"=>array(
                "type"=>"INT",
                "form hidden"
            ),
            "catName"=>array(
                "type"=>"VARCHAR",
                "no column",
                "form invisible",
                "conditions"=>array("\$gorumroll->list=='subscription_my'"=>"list"),
                "link_to"=>array("class"=>"appcategory", "id"=>"cid", "other_attr"=>"name"),
            ),
            "uid"=>array(
                "type"=>"INT",
                "form invisible"
            ),
            "userName"=>array(
                "type"=>"VARCHAR",
                "no column",
                "conditions"=>array("\$gorumroll->list=='subscription_cat'"=>"list"),
                "link_to"=>array("class"=>"user", "id"=>"uid", "other_attr"=>"name", "not_exists"=>"Not registered"),
            ),
            "email"=>array(
                "type"=>"VARCHAR",
                "text",
                "max"=>255,
                "mandatory",
                "safetext",
                "conditions"=>array("\$gorumroll->list=='subscription_cat'"=>"list")
            ),
        ),
        "primary_key"=>"id",
        "delete_confirm"=>"userName",
        "sort_criteria_sql"=>"catName",
    );

class Subscription extends Object
{

function create()
{
    global $gorumuser, $gorumroll, $gorumrecognised;
    
    $this->cid = $gorumroll->rollid;
    if( !$gorumrecognised && !$this->email )
    {
        return Roll::setFormInvalid("emailMandatory");
    }
    elseif( $gorumrecognised )
    {
        $this->uid = $gorumuser->id;
        $this->rollBackNum = 1;
    }
    else
    {
        $this->email=strtolower(trim($this->email));
        $ret = load( $this, array("cid", "email") );
        if( !$ret ) return Roll::setFormInvalid("alreadySubscribed");
    }
    create($this);
    Roll::setInfoText("subscribed");
}

function delete()
{
    global $gorumuser, $gorumroll, $gorumrecognised;

    if( isset($this->id) && $this->id )
    {
        delete($this);
    }
    elseif( isset($this->email) && $this->email )
    {
        $this->cid = $gorumroll->rollid;
        delete($this, array("email"));
        $this->rollBackNum = 1;
        Roll::setInfoText("unsubscribed");
    }
    elseif( $gorumrecognised )
    {
        $this->cid = $gorumroll->rollid;
        $this->uid = $gorumuser->id;
        delete($this, array("cid", "uid"));
        $this->rollBackNum = 1;
        Roll::setInfoText("unsubscribed");
    }
}

function getListSelect()
{
    global $gorumroll, $subscription_typ, $gorumuser;

    hasAdminRights($isAdm);
    if ($gorumroll->list=="subscription_cat")
    {
        if( !$isAdm ) handleError("Permission denied");
        $select = array("SELECT s.*, u.name AS userName ".
                  "FROM @subscription AS s LEFT JOIN @user AS u ".
                  "ON s.uid=u.id WHERE cid=#rollid#", $gorumroll->rollid);
        $subscription_typ["attributes"]["userName"][]="list";
        $subscription_typ["attributes"]["email"][]="list";
    }
    elseif ($gorumroll->list=="subscription_my")
    {
        $select = array("SELECT s.*, c.wholeName AS catName ".
                  "FROM @subscription AS s, @category AS c ".
                  "WHERE c.id=s.cid AND uid=#gorumuser->id#", $gorumuser->id);
        $subscription_typ["attributes"]["catName"][]="list";
    }
    return $select;
}

function getOrderBy()
{
    global $gorumroll;
    if ($gorumroll->list=="subscription_cat")
    {
        return "u.name ASC";
    }
    elseif ($gorumroll->list=="subscription_my")
    {
        return "c.wholeName ASC";
    }
}

function showNewTool()
{
    return "";
}

function showModTool()
{
    return "";
}

function showDetailsTool()
{
    return "";
}
}

?>