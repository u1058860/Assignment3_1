<?php
defined('_NOAH') or die('Restricted access');
$category_typ["attributes"]["description"] =
            array(
                "type"=>"TEXT",
                "textarea",
                "rows"=>5,
                "cols"=>50,
                "details",
                "allow_html"
            );
$category_typ["attributes"]["showDescription"] =
            array(
                "type"=>"INT",
                "bool",
                "yesno",
                "default"=>"1",
            );
$category_typ["attributes"]["keywords"] =
            array(
                "type"=>"TEXT",
                "textarea",
                "rows"=>5,
                "cols"=>50,
                "details",
            );
$category_typ["attributes"]["picture"] =
            array(
                "type"=>"VARCHAR",
                "file",
                "max" =>"250"
             );
$category_typ["attributes"]["allowAd"] =
            array(
                "type"=>"INT",
                "bool",
                "yesno",
                "default"=>"1",
                "show_relation"=>"allowAd"
            );
$category_typ["attributes"]["allowSubmitAdAdmin"] =
            array(
                "type"=>"INT",
                "bool",
                "default"=>"0",
                "relation"=>"allowAd"
            );
$category_typ["attributes"]["customAdListTitle"] =
            array(
                "type"=>"VARCHAR",
                "text",
                "max" =>"250",
                "relation"=>"allowAd"
             );
$category_typ["attributes"]["immediateAppear"] =
            array(
                "type"=>"INT",
                "bool",
                "yesno",
                "default"=>"1",
                "relation"=>"allowAd",
            );
$category_typ["attributes"]["inactivateOnModify"] =
            array(
                "type"=>"INT",
                "bool",
                "yesno",
                "default"=>"1",
            );
$category_typ["attributes"]["expirationEnabled"]=
            array(
                "type"=>"INT",
                "default"=>"0",
                "conditions"=>array("class_exists('response')"=>array("bool", "show_relation"=>"expirationEnabled")),
            );
$category_typ["attributes"]["expiration"]=
            array(
                "type"=>"INT",
                "text",
                "yesno",
                "default"=>"0",
                "conditions"=>array("class_exists('response')"=>array("relation"=>"expirationEnabled")),
            );
$category_typ["attributes"]["expirationOverride"]=
            array(
                "type"=>"INT",
                "values"=>array(customfield_forNone, customfield_forLoggedin, customfield_forAdmin),
                "default"=>"0",  // none
                "cols"=>1,
                "conditions"=>array("class_exists('response')"=>array("radio", "relation"=>"expirationEnabled")),
            );
$category_typ["attributes"]["restartExpOnModify"] =
            array(
                "type"=>"INT",
                "bool",
                "yesno",
                "default"=>"0",
                "relation"=>"expirationEnabled"
            );
$category_typ["attributes"]["sortId"]=
            array(
                "type"=>"INT",
            );
$category_typ[]="smartform";

class AppCategory extends Category
{

var $globalStat;

function AppCategory()
{
    $this->globalStat = & new GlobalStat();
    $this->Category();
}

function get_table()
{
    return "category";
}

function create($fromInstall = FALSE, $fromClone = FALSE)
{
    global $lll;

    if( !isset($this->sortId) )
    {
        $query = "SELECT MAX(sortId) as sortId FROM @category WHERE up=#up#";
        loadSQL( $catStat = new AppCategory, array($query, $this->up) );
        $this->sortId = isset($catStat->sortId) ? $catStat->sortId+100 : 100;
    }
    $this->handleExpirationFieldsContraversy();
    Category::create();
    if( !$fromClone && !Roll::isFormInvalid() )
    {
        $this->addDefaultCustomFields($fromInstall);
        $this->storeAttachment();
        Roll::setInfoText("created", $lll[$this->get_class()]);
    }
}

function addDefaultCustomFields($fromInstall = FALSE)
{
    global $lll;
    
    if( $this->up )
    {        
        // az alkategoria orokli az apja custom fieldjeit:
        G::load( $customFields, array("SELECT * FROM @customfield WHERE cid=#up#", $this->up));
        foreach( $customFields as $cf )
        {
            $cf->cid = $this->id;
            unset($cf->id);
            create($cf);
        }
    }
    else
    {
        ItemField::addDefaultCustomFields($fromInstall, $this->id);
    }
}

function modify( $whereFields="" )
{
    global $recursive;

    // betoltjuk aregi category-t:
    G::load( $oldObject, $this->id, "appcategory" );
    $this->handleExpirationFieldsContraversy();
    parent::modify($whereFields);
    // recursive esetben csak a wholeName valtoztatasarol van szo,
    // nincs attachment feltoltes, exp, vagy immediateAppear valtoztatas:    
    if( !Roll::isFormInvalid() && empty($recursive) )
    {
        $this->storeAttachment();
        $this->handleExpirationChanges($oldObject->expiration);
        $this->handleImmediateAppearChanges($oldObject->immediateAppear);
        CacheManager::resetCache($this->id);
    }
}

// biztositjuk, hogy ne legyen ellentmondas a kulonbozo expirationnel kapcsolatos mezok kozt:
function handleExpirationFieldsContraversy()
{
    if( isset($this->expirationEnabled) )
    {
        // ha az egyik nulla, a masiknak is nullanak kell lenni
        if( !$this->expirationEnabled ) 
        {
            $this->expiration = 0;
            $this->expirationOverride = customfield_forNone;
        }
        elseif( empty($this->expiration) && $this->expirationOverride==customfield_forNone ) $this->expirationEnabled=0;
    }
}

function handleExpirationChanges( $oldExp )
{
    if( !isset($this->expiration) ) return; // akkor lehet, ha allowAd=FALSE
    if( !$oldExp && $this->expiration )  // most allitjuk be az expirationt
    {
        $exp = Date::add($this->expiration, Date_Day);
        executeQuery("UPDATE @item SET expirationTime=#exp#, expEmailSent=0 WHERE cid=#this->id# AND status=1", $exp->getDbFormat(), $this->id);
    }
    elseif( $oldExp && !$this->expiration )  // most szuntetjuk meg az expirationt
    {
        executeQuery("UPDATE @item SET expirationTime=0, expEmailSent=0, renewalNum=0 WHERE cid=#this->id#", $this->id);
    }
    elseif( $this->expiration != $oldExp )  // lejarati ido valtoztatas
    {
        $diff = $this->expiration - $oldExp;
        executeQuery("UPDATE @item SET expirationTime=expirationTime + INTERVAL $diff DAY WHERE cid=#this->id# AND expirationTime!=0", $this->id);
        if( $diff>0 ) // hosszabbitas eseten
        {
            // ha mar kuldtunk emailt, de a hosszabbitas reven ujra lagalabb expNoticeBefore tavlataba kerul a lejarat, akkor ujra kell majd kuldeni emailt:
            executeQuery("UPDATE @item SET expEmailSent=0 WHERE cid=#this->id# AND expEmailSent=1 AND DATEDIFF(expirationTime, NOW())>=#daysBefore#", $this->id, $this->s->expNoticeBefore);
        }
    }
}

function handleImmediateAppearChanges( $oldImmediateAppear )
{
    if( !$oldImmediateAppear && $this->immediateAppear )
    {
        // ha eppen imediateAppear-ra allitottak, akkor minden inactive
        // ad-ot aktivra allitunk a kategoriaban:
        getDbCount( $count, array("SELECT COUNT(*) FROM @item WHERE cid=#this->id# AND status=0", $this->id));
        if( $this->expiration ) 
        {
            $expirationTime = Date::add($exp, Date_Day);
            $exp = ", expirationTime = '".$expirationTime->getDbFormat()."', expEmailSent=0";
        }
        else $exp="";
        executeQuery("UPDATE @item SET status=1 $exp WHERE cid=#this->id# AND status=0", $this->id);
        load($this);  // hogy a directItemNum betoltodjon
        $this->increaseDirectItemNum($count);
    }
}

function delete( $whereFields="" )
{
    global $recursive, $siteDemo;

    if( $siteDemo ) return Roll::setInfoText("This operation is not permitted in the demo.");
    Category::delete($whereFields);
    if( $this->picture )
    {
        $ret=@unlink(CAT_PIC_DIR . "/$this->id".".".$this->picture);
        if(!$ret) Roll::setInfoText("cantdelfile",$this->picture);
    }

    // Kitoroljuk az azonos id-ju customfield objektumokat is:
    executeQuery("DELETE FROM @customfield WHERE cid=#this->id#", $this->id);
    if( !$recursive )
    {
        $this->nextAction =& new AppController("list/$this->up");  // a torles utan az apja listajara ugrunk
    }
}

function showNavBar($withLink=FALSE)
{
    global $gorumroll, $lll, $navBarSeparator;
    if( empty($this->id) ) return "";
    $s="";
    $ctrl =& new AppController("/");
    $s.=$ctrl->generAnchor($lll["home"]);

    $this->cacheFatherObjects();
    global $fatherCatList;
    foreach( $fatherCatList as $fatherCat )
    {
        if( $fatherCat->id!=$this->id )
        {
            $s.=$navBarSeparator;
            $ctrl =& new AppController("cat/list/$fatherCat->id");
            $s.=$ctrl->generAnchor($fatherCat->name);
        }
    }
    $s.=$navBarSeparator;
    if( $gorumroll->method=="showhtmllist" && $gorumroll->list=="appcategory" )
    {
        $s.=htmlspecialchars($this->name);
    }
    else
    {
        $ctrl =& new AppController("cat/list/$this->id");
        $s.=$ctrl->generAnchor($this->name);
    }
    return $s;
}

function showHtmlList()
{
    global $gorumroll,$colspNum, $gorumcategory;

    JavaScript::addCss(CSS_DIR . "/category.css");
    $s="";
    $this->id = $gorumcategory = $gorumroll->rollid;
    // Ha ilyen-olyan torlesi kavarasok kovetkezteben ez az objektum
    // mar nem letezik, akkor a home-ra megyunk:
    if( load($this) ) $gorumroll->rollid = 0;
    $this->loadHtmlList($list);
    hasAdminRights($isAdm);
    $rangeSelText = "";
    $catArr = array();
    $i=0;
    foreach( $list as $listItem ) 
    {
        $ctrl =& new AppController("cat/list/$listItem->id");
        $catArr[$i]->link=$ctrl->makeUrl();
        $catArr[$i]->title=htmlspecialchars($listItem->getAttr("name"));
        $catArr[$i]->description=$listItem->showDescription ? $listItem->getAttr("description") : "";
        $catArr[$i]->itemNum=$listItem->itemNum;
        if( $listItem->picture ) 
        {
            $catArr[$i]->picture=CAT_PIC_DIR . "/$listItem->id.$listItem->picture";
        }
        else $catArr[$i]->picture="";
        $i++;
    }
    if( $gorumroll->rollid && $this->allowAd ) // Home-ban nem kell
    {
        $ctrl =& new AppController("item/list/$gorumroll->rollid");
        $gorumroll->processMethod($ctrl, "contentTemplate/advertisementList" );
    }
    View::assign( "categories", $catArr );
}

function valid()
{
    if (!isset($_FILES["picture"]["name"]) ||
        $_FILES["picture"]["name"]=="")
    {
        return Category::valid();
    }
    if (isset($_FILES["picture"]["name"]) && strstr($_FILES["picture"]["name"]," "))
    {
        return Roll::setFormInvalid("spacenoatt");
    }
    if ($_FILES["picture"]["size"]==0) 
    {
        return Roll::setFormInvalid("picFileSizeNull");
    }
    if ($_FILES["picture"]["tmp_name"]=="none") 
    {
        return Roll::setFormInvalid("picFileSizeToLarge1");
    }
    if (!is_uploaded_file( //ONLY from php 4.02 !!!
            $_FILES["picture"]["tmp_name"]))
    {
        handleError("Possible attack");
    }
    $fname=$_FILES["picture"]["tmp_name"];
    $size = getimagesize( $fname );
    if (!$size) return Roll::setFormInvalid("notValidImageFile");
    return Category::valid();
}

function storeAttachment()
{
    if (!isset($_FILES["picture"]["name"]) || $_FILES["picture"]["name"]=="") return;
    $fname=$_FILES["picture"]["tmp_name"];
    $f=@fopen($fname,"r");
    if (!$f)  return Roll::setInfoText("cantOpenFile");
    $extensions = array("", "gif", "jpg", "png");
    //$checkBits = array(0, IMG_GIF, IMG_JPG, IMG_PNG);
    $size = getimagesize( $fname );
    $type = $size[2]; // az image tipus, 1=>GIF, 2=>JPG, 3=>PNG
    $file = fread($f,$_FILES["picture"]["size"]);
    $ext = $extensions[$type];
    $foname = CAT_PIC_DIR . "/$this->id".".".$ext;
    $fo = fopen($foname,"w");
    //TODO: error handle
    fwrite( $fo,$file);
    fclose( $fo );
    /*
    $foname_gray = CAT_PIC_DIR$this->id"."_gray.".$ext;
    if( defined("IMG_GIF") && function_exists("ImageTypes") )  // GD support
    {
        // mas fg-eket kell hivni az image tipusnak megfeleloen:
        $create_fg = array("", "ImageCreateFromGIF", "ImageCreateFromJPEG",
                               "ImageCreateFromPNG");
        $save_fg = array("", "ImageGIF", "ImageJPEG", "ImagePNG");
        $src_im = $create_fg[$type]($fname);
        if( $src_im && imagefilter($src_im, IMG_FILTER_GRAYSCALE) )
        {
            $save_fg[$type]( $src_im, $foname_gray );
        }
        imagedestroy($src_im);
    }
    else copy($foname, $foname_gray);
    */
    // A picture-ben csak azt taroljuk el, hogy mi a kiterjesztes:
    executeQuery( "UPDATE @category SET picture=#$ext# WHERE id=#this->id#", $ext, $this->id );
    $_FILES["picture"]["name"]="";
    return ok;
}

// Ez azert kell, mert a catregory listben egy kategory list es egy
// ad list is van, de a lapozo toolnak csak az ad listre kell
// vonatkoznia
function getLimit()
{
    return "";
}

function organizeForm()
{
    global $gorumroll, $lll, $jQueryLib, $curvyCorners, $lll, $siteDemo, $paginateCategoryOrganizerFromNumberOfCats, $infoText;

    hasAdminRights( $isAdm );
    if( !$isAdm ) handleErrorPerm( __FILE__, __LINE__ );
    if( !class_exists('rss') ) return;
    
    JavaScript::addInclude(GORUM_JS_DIR . $jQueryLib);
    JavaScript::addInclude(GORUM_JS_DIR . "/jquery/interface/iutil.js");
    JavaScript::addInclude(GORUM_JS_DIR . "/jquery/interface/idrag.js");
    JavaScript::addInclude(GORUM_JS_DIR . "/jquery/interface/idrop.js");
    JavaScript::addInclude(GORUM_JS_DIR . "/jquery/interface/isortables.js");
    JavaScript::addInclude(GORUM_JS_DIR . "/jquery/inestedsortable.js");
    JavaScript::addInclude(GORUM_JS_DIR . "/jquery/jquery.nestedsortablewidget.js");
    JavaScript::addCss(CSS_DIR . "/nestedsortablewidget.css");
    if( !empty($curvyCorners) )
    {
        if( $infoText && !$siteDemo ) Roll::setInfoText("useDragAndDrop");
        elseif( $siteDemo ) Roll::setInfoText("Use drag-and-drop to reorganize the categories! Saving and cloning is disabled in the demo version.");
        $addCurvyCornersToHeader = "
                $('#organize_widget').corner({
                    tl: { radius: 6 }, 
                    tr: { radius: 6 }, 
                    bl: { radius: 0 }, 
                    br: { radius: 0 },
                    autoPad: false
                });
        ";
    }
    else 
    {
        $addCurvyCornersToHeader="";
        Roll::setInfoText("");
    }
    if( $this->getCategoryCount()>$paginateCategoryOrganizerFromNumberOfCats )
    {
        $paginate = ", paginate: true, itemsPerPage: $paginateCategoryOrganizerFromNumberOfCats";
    }
    else $paginate = "";
    include_once(NOAH_APP . "/clonecat.php");
    $cloneOverlay =& new OverlayController(array(
        "id"=>"cloneOverlay",
        "ajaxFromHref"=>TRUE,
        "postponeOnloadAction"=>TRUE,
        "expose"=>TRUE,
        "size"=>4
	));
    JavaScript::addOnload("
        $('#organize_widget').NestedSortableWidget({
            loadUrl: '$_SERVER[PHP_SELF]',
            loadUrlParams: {list: 'appcategory', method: 'get_json_tree'},
            loadRequestType: 'POST',
            saveUrl: 'index.php',
            saveUrlParams: {list: 'appcategory', method: 'organize'},
            colsWidth: [200,80,80,100],
            padding: [4, 5, 4, 10],
            whiteMargin: 1,
            fadeOutHover: false,
            onLoad: function(){
                $addCurvyCornersToHeader
                $('.nsw-save-progress-wrap').eq(1).hide();
                ".$cloneOverlay->getOnloadAction()."
            },
            text: {
                saveButton: '$lll[organizeSaveButton]',
                saveMessage: '$lll[organizeSaveMessage]',
                saveError: '$lll[organizeSaveError]',
                nextPageDrop: '$lll[organizeNextPageDrop]',
                previousPageDrop: '$lll[organizePreviousPageDrop]',
                nextItems: '$lll[organizeNextItems]',
                previousItems: '$lll[organizePreviousItems]',
                loadError: '$lll[organizeLoadError]'
            }
            $paginate
        });
    ");
}  

function & getCategoryTree( $cats )
{
    $tree = array();
    for( $i=0; $i<count($cats); $i++ )
    {
        G::load( $subCats, "SELECT * FROM @category WHERE up={$cats[$i]->id} ORDER BY sortId ASC" );
        unset($cats[$i]->s);
        unset($cats[$i]->globalStat);
        unset($cats[$i]->creationtime);
        $node = array("cat"=>$cats[$i], "index"=>$i, "subCats"=>$this->getCategoryTree( $subCats ));
        $tree[]=$node;    
    }
    return $tree;
}

function getJsonTree()
{
    global $lll;
    
    hasAdminRights( $isAdm );
    if( !$isAdm ) handleErrorPerm( __FILE__, __LINE__ );

    $count = $this->getCategoryCount();
    G::load( $cats, "SELECT * FROM @category WHERE up=0 ORDER BY sortId ASC" );
    $tree = & $this->getCategoryTree( $cats );
    $requestFirstIndex = isset($_POST["requestFirstIndex"]) ? $_POST["requestFirstIndex"] : 0;
    $s='
        {
          "requestFirstIndex" : '.$requestFirstIndex.',
          "firstIndex" : 0,
          "count": '.$count.',
          "totalCount" :'.$count.',
          "columns":["'.$lll["name"].'", "'.$lll["methods"].'", "'.$lll["appcategory_allowAd"].'", "'.$lll["exp"].'", "'.$lll["unmoderated"].'"],
          "items": 
          [';
            for( $i=0; $i<count($tree); $i++ ) $s.=$this->treeNodeToJson($tree[$i]);
    $s.=" ]
        }";
    echo $s;
    die();
}

function getCategoryCount()
{
    getDbCount( $count, "SELECT COUNT(*) FROM @category" );
    return $count;
}

function treeNodeToJson($node)
{
    $s="";
    if( $node["index"] ) $s.=",\n";
    $s.="{\n";
    $s.='"id": '.$node["cat"]->id.',';
    $s.='"info": ["' . addcslashes(htmlspecialchars($node["cat"]->name), '"') . '", "' . 
                       $node["cat"]->showTools() . '", "' . 
                       $node["cat"]->showListVal("allowAd") . '", "' . 
                       $node["cat"]->showListVal("expiration") . '", "' . 
                       $node["cat"]->showListVal("immediateAppear") . '"]';
    if( count($node["subCats"]) )
    {
        $s.=',
            "children": 
            [
            ';
                for( $i=0; $i<count($node["subCats"]); $i++ ) $s.=$this->treeNodeToJson($node["subCats"][$i]);
        $s.=']
        ';
    }
    $s.="}\n";
    return $s;    
}

function organize()
{
    global $siteDemo;
    
    hasAdminRights( $isAdm );
    if( !$isAdm ) handleErrorPerm( __FILE__, __LINE__ );
    if( !class_exists('rss') || $siteDemo ) return;
    
    ini_set("max_execution_time", 0);
    $hierarchyChanged = FALSE;
    $sortId = 100;
    $firstIndex = 0;
    // ebben osszegyujtjuk az osszes olyan kategoria id-jet, ami egy valtoztatott blokkban van:
    $cidsInBlocksSoFar = array();
    if( AppCategory::is_assoc($_REQUEST['nested-sortable-widget']) ) $modifiedBlocks = array($_REQUEST['nested-sortable-widget']);
    else $modifiedBlocks = & $_REQUEST['nested-sortable-widget'];
    // ha nincs pagination:
    if( count($modifiedBlocks)==1 && $modifiedBlocks[0]["count"]==$this->getCategoryCount() )
    {
        //$fp->log("No pagination");
        $this->updateOrderIter( $modifiedBlocks[0], $sortId, $firstIndex, $hierarchyChanged, $cidsInBlocksSoFar );
    }
    else
    {
        //$fp->log("Pagination");
        // lekerjuk a valtoztatas elotti kategoria fat, mert ossze kell fesulni a valtoztatott blokkokkal:
        G::load( $cats, "SELECT * FROM @category WHERE up=0 ORDER BY sortId ASC" );
        $tree = & $this->getCategoryTree( $cats );
        //$fp->log($tree, "Tree");
        $firstNode = & $tree[0];
        // $tIndex egy tomb ami a tree egy agan levo node-okra mutato referenciakat tartalmaz:
        $tIndex = array($firstNode);
        foreach( $modifiedBlocks as $block )  // vegigmegyunk a blokkokon
        {
            //$fp->group("Block begins - first index: $firstIndex");
            //$fp->log($sortId, "Starting sortId");
            //$fp->log($block["firstIndex"], "First index of the block");
            // a regi fa nodjainak sortId-jit frissitgetjuk addig, amig el nem jutunk az aktualis blokkig:
            while( $firstIndex < $block["firstIndex"] )
            {
                $this->updateOriginalTreeNode( $tree, $tIndex, $sortId );
                $firstIndex++;
            }
            //$fp->log($firstIndex, "First index after updating old nodes");
            //$fp->log($sortId, "SortId after updating old nodes");
            // a blokk elemeinek update-je:
            $this->updateOrderIter( $block, $sortId, $firstIndex, $hierarchyChanged, $cidsInBlocksSoFar );
            //$fp->log($firstIndex, "First index after updating block");
            //$fp->log($sortId, "SortId after updating block");
            // amig az a blokkokban mar szereplo nodokat tartalmaz, "skippeljuk" a regi fat:
            while( $tIndex && in_array($tIndex[count($tIndex)-1]["cat"]->id, $cidsInBlocksSoFar) ) $this->advanceTreeIndex($tree, $tIndex);
            //$fp->groupend();
        }
        //$fp->group("Updating the rest of the old nodes");
        // az osszes valtoztatott blokk utani regi faban levo elemet is update-ezni kell:
        while( $tIndex ) $this->updateOriginalTreeNode( $tree, $tIndex, $sortId );
        //$fp->groupend();
    }
    if( $hierarchyChanged ) $this->recalculateAllItemNums(TRUE);
    die();
}

function updateOriginalTreeNode( &$tree, &$tIndex, &$sortId )
{    
    // a $tIndex altal mutattott aktualis node-hoz tartozo kategoria sortId-jet frissitjuk.
    // az aktualis node mindig a $tIndex utolso eleme:
    //$fp->log("Setting sortId original node: id: ".$tIndex[count($tIndex)-1]["cat"]->id.", sortId: $sortId" );
    executeQuery("UPDATE @category SET sortId=#sortId# WHERE id=#id#", $sortId, $tIndex[count($tIndex)-1]["cat"]->id);
    $sortId+=100;  
    $this->advanceTreeIndex($tree, $tIndex);
}

// $tIndex egy tomb ami a tree egy agan levo node-okra mutato referenciakat tartalmaz
function advanceTreeIndex( &$tree, &$tIndex )
{
    // "leptetjuk" a $tIndexet a fa melysegi bejarasa szerinti kovetkezo node-ra.
    // a lev�l-node-tol kezdve keressuk a tovabbhaladasi lehetoseget:
    $i=count($tIndex)-1;
    // ha vannak al-kategoriak, akkor tudunk egyel melyebbre menni a faban:
    if( count($tIndex[$i]["subCats"]) ) 
    {
        $tIndex[]=$tIndex[$i]["subCats"][0];
    }
    // ha a node-dal azonos szinten, letezik meg tovabbi alkategoria, akkor a node-ot kicsereljuk ra:
    elseif( $i && isset($tIndex[$i-1]["subCats"][$tIndex[$i]["index"]+1]) )
    {
        $tIndex[$i]=$tIndex[$i-1]["subCats"][$tIndex[$i]["index"]+1];
    }
    // ha nem letezik, visszalepunk annyival, amennyivel csak szukseges:
    elseif( $i ) 
    {
        while( $i ) // amig tudunk visszalepni
        {
            unset($tIndex[$i--]);
            // ha a visszalepes utani szinten, van tovabbi alkategoria:
            if( $i && isset($tIndex[$i-1]["subCats"][$tIndex[$i]["index"]+1]) )
            {
                $tIndex[$i]=$tIndex[$i-1]["subCats"][$tIndex[$i]["index"]+1];
            }
            elseif( !$i )
            {
                //$fp->log($tIndex[$i]["index"]+1, "Checking root index");
                // ha a gyokerben vagyunk es letezik tovabbi fo-kategoria, akkor tovabblepunk ra:
                if( isset($tree[$tIndex[$i]["index"]+1]) ) $tIndex[$i] = & $tree[$tIndex[$i]["index"]+1];
                else $tIndex=FALSE; // ha nincs tobb node a faban
            }
        }
    }
    else
    {
        //$fp->log($tIndex[$i]["index"]+1, "Checking root index");
        // ha a gyokerben vagyunk es letezik tovabbi fo-kategoria, akkor tovabblepunk ra:
        if( isset($tree[$tIndex[$i]["index"]+1]) ) $tIndex[$i] = & $tree[$tIndex[$i]["index"]+1];
        else $tIndex=FALSE; // ha nincs tobb node a faban
    }
    //if( $tIndex ) $fp->log(array_map(create_function('$v', 'return array($v["cat"]->id, $v["index"]);'), $tIndex), "tIndex");
    //else $fp->log($tIndex, "tIndex" );
}

function updateOrderIter( &$node, &$sortId, &$firstIndex, &$hierarchyChanged, &$cidsInBlocksSoFar )
{
    $wholeNamePrefix="";
    $firstIndex += count($node["items"]);
    foreach( $node["items"] as $n )
    {
        $this->updateOrder( $n, 0, $sortId, $wholeNamePrefix, $hierarchyChanged, $cidsInBlocksSoFar ); 
    }
}

function is_assoc($array) 
{
    foreach (array_keys($array) as $k => $v) 
    {
        if ($k !== $v) return true;
    }
    return false;
}

function updateOrder( $node, $up, &$sortId, $wholeNamePrefix, &$hierarchyChanged, &$cidsInBlocksSoFar )
{
    $cidsInBlocksSoFar[] = $node["id"];
    list( $oldUp, $name ) = G::getAttr( $node["id"], "appcategory", "up", "name" );
    $wholeName = $wholeNamePrefix ? $wholeNamePrefix." - ".$name : $name;
    //$fp->log("Setting sortId block node: id: ".$node["id"].", sortId: $sortId" );
    executeQuery("UPDATE @category SET up=#up#, wholeName=#wholeName#, sortId=#sortId# WHERE id=#id#", 
                 $up, $wholeName, $sortId, $node["id"]);
    //file_put_contents("test.html", "$node[id]: $sortId\n", FILE_APPEND );
    $hierarchyChanged = $hierarchyChanged || $oldUp!=$up;
    $sortId+=100;
    if( isset($node["children"]) ) 
    {
        foreach( $node["children"] as $subNode ) $this->updateOrder( $subNode, $node["id"], $sortId, $wholeName, $hierarchyChanged, $cidsInBlocksSoFar );
    }
}

function showTools()
{
    global $lll;
    
    $ctrl1 =& new AppController("appcategory/modify_form/$this->id");
    $ctrl2 =& new AppController("appcategory/delete_form/$this->id");
    $ctrl4 =& new AppController("field/sortfield_form/$this->id");
    $ctrl3 =& new OverlayController(array(
        "id"=>"cloneOverlay"
	));
    $ajaxFromHref =& new AppController("clonecat/create_form/$this->id");
    return "<span class='methods'>".$ctrl1->generAnchor($lll["icon_modify"]) . " | " . 
                                    $ctrl2->generAnchor($lll["icon_delete"]) . " | " . 
                                    $ctrl3->generAnchor($lll["clone"], "overlay", $ajaxFromHref->makeUrl()) . " | " . 
                                    $ctrl4->generAnchor($lll["fields"])."</span>";
}

function cloneCategory()
{
    global $lll, $gorumroll;

    hasAdminRights( $isAdm );
    if( !$isAdm ) return;

    $this->id = $gorumroll->rollid;
    if( load($this) ) return;
    
    // Cloning the category:
    unset($this->id);
    unset($this->creationtime);
    $this->name = sprintf($lll["copyOfCategory"], $this->name);
    $this->subCatNum = $this->directSubCatNum = $this->itemNum = $this->directItemNum = 0;
    $this->picture = "";
    $this->sortId-=10;
    $this->create(FALSE, TRUE);  // fromClone=TRUE
    
    // Cloning the custom fields:
    G::load($fields, array("SELECT * FROM @customfield WHERE cid=#cid#", $gorumroll->rollid));
    foreach( $fields as $field )
    {
        unset($field->id);
        $field->cid = $this->id;
        create($field);
    }
    Roll::setInfoText("categoryCloned");
    $this->rollBackNum = 1;
}

function hasModeration()
{
    static $hasModeration = FALSE;
    
    if( $hasModeration!==FALSE ) return $hasModeration;
    getDbCount( $hasModeration, "SELECT COUNT(*) FROM @category WHERE immediateAppear=0" );
    return $hasModeration;
}

function hasExpiration()
{
    static $hasExpiration = FALSE;
    
    if( $hasExpiration!==FALSE ) return $hasExpiration;
    getDbCount( $hasExpiration, "SELECT COUNT(*) FROM @category WHERE expirationEnabled=1" );
    return $hasExpiration;
}

}
?>
