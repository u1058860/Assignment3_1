<?php
defined('_NOAH') or die('Restricted access');

class CheckConf extends Object
{
var $installFiles = array("install.php", "installlib.php", "app/installlib.php", "uninstall.php", "autoinstall.php", "update.php", "update.lib.php", "u.php", "update-rss.php", "noah.ini.php");
var $appFiles = array("assignments.php","controller.php","init.php","search.php","cronjob.php","globalstat.php","item_detailspresentation.php","settings.php",
"category.php","customfield.php","item.php","staticpage.php","checkconf.php","include.php","subscription.php","user.php","config.php",                   
"include_view.php","response.php","tar.class.php","varfields.php","constants.php","error.php","rss.php","terms.txt","shoppingcart.php", "updatelib.php",
"advertisement.php", "globalsettings.php", "style.css", "template.php", "template1.php");
    
function show()
{
    global $gorumroll,$lll,$gorumuser, $dontRemoveInstallFiles, $CONFIG_FILE_DIR, $noahVersion;
    
    JavaScript::addCss(CSS_DIR . "/checkconf.css?$noahVersion");
    $globalStat = new GlobalStat;
    if ($globalStat->congrat) {
        View::assign("congrat", $lll["congrat"]);
        $globalStat->congrat = FALSE;
        modify($globalStat);
    }
    
    $report = array();
    $st=join("",file($CONFIG_FILE_DIR . "/config.php"));
    $p="^<\?";
    $cfe=FALSE;
    if (!ereg($p,$st)) 
    {
        $cfe=TRUE;
        $report[]=array($lll["confpreerr"], 'conferr');
    }
    $p="\?>$";
    $p1="\?>\n$";
    $p2="\?>\r\n$";
    if (!ereg($p,$st) && !ereg($p1,$st) && !ereg($p2,$st)) 
    {
        $cfe=TRUE;
        $report[]=array($lll["confposterr"], 'conferr');
    }
    if( $cfe ) $report[]=array($lll["conffileok"], 'confok');

    if( $gorumuser->password==getPassword("admin") ) 
    {
        $report[]=array($lll["chadmpass"], 'conferr');
    }
    $settings = & new AppSettings;
    if( $settings->adminEmail=="" ) 
    {
        $report[]=array($lll["chsyspass"], 'conferr');
        $report[]=array($lll["chsyspass_expl"], 'confexpl');
    }
    else
    {
        $ctrl = new AppController("checkconf/mailtest");
        $report[]=array($ctrl->generAnchor($lll["triggerMailTest"]), 'confok');
    }

    if( !defined("IMG_GIF") || !function_exists("ImageTypes"))//nincs GD
    {
        $report[]=array($lll["nogd"], 'conferr');
        $report[]=array($lll["nogd_expl"], 'confexpl');
    }
    if ( !is_writeable(ini_get("session.save_path")) ) 
    {
        $error_message = "The configured Path for Session files (".ini_get("session.save_path").") is not writeable!";
    }
    
    $this->checkWritePermission( $noPermDirs );
    if( count($noPermDirs) )
    {
        $report[]=array(sprintf($lll["nopermission"], implode(", ", $noPermDirs)), 'conferr');
        $report[]=array($lll["nopermission_expl"], 'confexpl');
    }
    
    // Nice URL section:
    View::assign("rewriteOn", $gorumroll->rewriteOn);
    if( !$gorumroll->rewriteOn )
    {
        if( function_exists("apache_get_modules") )
        {
            View::assign("rewriteModuleEnabled", in_array("mod_rewrite", apache_get_modules()));
        }
        else View::assign("rewriteModuleEnabled", "unsure" );
    }    
    
    
    if( (!empty($dontRemoveInstallFiles) || $this->installFilesRemoved()) &&
        $this->appFilesRemoved() && $this->backupFilesRemoved() && $globalStat->defPageConf) 
    {
        $ctrl =& new AppController("checkconf", "remove_first_check");
        View::assign("clickToDisappear", "$lll[confdisapp] ".$ctrl->generAnchor($lll["here1"]).".<br>$lll[confclicheck]" );
    }
    View::assign("report", $report);
}

function mailTest()
{
    global $gorumroll,$lll,$gorumuser, $noahVersion;
    JavaScript::addCss(CSS_DIR . "/checkconf.css?$noahVersion");
    $settings = & new AppSettings;
    // Mail teszt:
    Notification::gmail($errMsg, 
                        $settings->adminEmail, 
                        "Test mail",
                        "Test mail", 
                        $settings->adminFromName,TRUE,
                        $settings->adminEmail,$settings->adminEmail );
    if( $errMsg ) 
    {
        $report[]=array(sprintf($lll["mailerr"], $errMsg), 'conferr');
        //$report[]=array($lll["mailerr_expl"], 'confexpl');
    }
    else
    {
        $report[]=array(sprintf($lll["mailok"], $settings->adminEmail), 'confok');
    }            
    View::assign("checkTitle", $lll["checkMailtestTitle"]);
    View::assign("report", $report);
}

function installFilesRemoved()
{
    global $lll, $noahVersions;
    
    $found = FALSE;
    $unnecessaryAppFiles = array();
    foreach( $this->installFiles as $f )
    {
        if( file_exists($f) ) $unnecessaryAppFiles[] = $f;
    }
    foreach( $noahVersions as $v )
    {
        if( file_exists("updateinfo-$v.php") ) $unnecessaryAppFiles[] = "updateinfo-$v.php";
    }
    if( $found = count($unnecessaryAppFiles) )
    {
        $ctrl = new AppController("checkconf/inst_file_remove");
        View::assign("instFileRemove", sprintf($lll["instFileRemove"], 
                                               implode(", ", $unnecessaryAppFiles), 
                                               $ctrl->makeUrl()));
    }
    return !$found;
}

function appFilesRemoved()
{
    global $lll, $noahVersions;
    
    $found = FALSE;
    $unnecessaryAppFiles = array();
    foreach( $this->appFiles as $f )
    {
        if( file_exists($f) ) $unnecessaryAppFiles[] = $f;
    }
    if( $found = count($unnecessaryAppFiles) )
    {
        $ctrl = new AppController("checkconf/app_file_remove");
        View::assign("appFileRemove", sprintf($lll["appFileRemove"], 
                                               implode(", ", $unnecessaryAppFiles), 
                                               $ctrl->makeUrl()));
        View::assign("appFileRemoveExpl", $lll["appFileRemoveExpl"]);
    }
    return !$found;
}

function backupFilesRemoved()
{
    global $lll, $noahVersions;
    
    $found = FALSE;
    $unnecessaryBackupDirs = array();
    foreach( $noahVersions as $v )
    {
        if( file_exists("backup-$v") ) $unnecessaryBackupDirs[] = "backup-$v";
    }
    if( $found = count($unnecessaryBackupDirs) )
    {
        $ctrl = new AppController("checkconf/backup_file_remove");
        View::assign("backupFileRemove", sprintf($lll["backupFileRemove"], 
                                               implode(", ", $unnecessaryBackupDirs), 
                                               $ctrl->makeUrl()));
        View::assign("backupFileRemoveExpl", $lll["backupFileRemoveExpl"]);
    }
    return !$found;
}

function checkWritePermission( &$noPermDirs )
{
    $noPermDirs = array();
    foreach( array(AD_PIC_DIR, USER_PIC_DIR, CAT_PIC_DIR, UPLOAD_DIR, USER_UPLOAD_DIR, LOG_DIR, FEED_DIR) as $dir )
    {
        $fName = "$dir/dummy";
        if( !($f = @fopen($fName,"w")) ) $noPermDirs[]=$dir;
        @fclose( $f );
        @unlink( $fName );
    }
}

function removeInstFiles()
{
    global $dontRemoveInstallFiles, $noahVersions;
    
    if( !empty($dontRemoveInstallFiles) ) return;
    hasAdminRights($isAdm);
    if( !$isAdm ) LocationHistory::rollBack(new AppController("/"));
    foreach( $this->installFiles as $f )
    {
        if( file_exists($f) ) @unlink($f);
    }
    foreach( $noahVersions as $v )
    {
        if( file_exists("updateinfo-$v.php") ) @unlink("updateinfo-$v.php");
    }
    $this->rollBackNum = 1;    
}

function removeAppFiles()
{
    hasAdminRights($isAdm);
    if( !$isAdm ) LocationHistory::rollBack(new AppController("/"));
    foreach( $this->appFiles as $f )
    {
        if( file_exists($f) ) @unlink($f);
    }
    $this->rollBackNum = 1;    
}

function removeBackupFiles()
{
    global $noahVersions;
    
    hasAdminRights($isAdm);
    if( !$isAdm ) LocationHistory::rollBack(new AppController("/"));
    foreach( $noahVersions as $v )
    {
        if( file_exists("backup-$v") ) $this->removeRecursively("backup-$v");
    }
    $this->rollBackNum = 1;    
}

function removeRecursively($dirOrFile)
{
    if( is_dir($dirOrFile) )
    {
        $dir = opendir($dirOrFile);
        while( ($file = readdir($dir)) !== false) 
        {
            if( !preg_match("/^\./", $file) ) $this->removeRecursively("$dirOrFile/$file");
        }
        @rmdir($dirOrFile);
    }
    else @unlink($dirOrFile);
}

function removeFirstCheck()
{
    $globalStat = new GlobalStat;
    $globalStat->defPageConf=FALSE;
    modify($globalStat);
    $this->nextAction =& new AppController("/");
}

function updates()
{
    global $gorumroll,$lll,$gorumuser, $noahsVersionCheckScript, $noahsHost, $noahVersion;
    
    hasAdminRights($isAdm);
    if( !$isAdm ) LocationHistory::rollBack(new AppController("/"));
    JavaScript::addCss(CSS_DIR . "/checkconf.css?$noahVersion");
    $globalStat = new GlobalStat;
    if( !$globalStat->reg ) 
    {
        $globalStat->reg = md5(uniqid(rand(), true));
        modify($globalStat);
    }
    $branch = $this->getBranch();
    $report[]=array(sprintf($lll["currentVersionIs"], "$globalStat->instver-$branch"), 'confok');
    $data = $this->getTransferData($globalStat);
    if( ($latestVersionInfo = $this->getVersionInfo($noahsHost, "POST", $noahsVersionCheckScript, $data))===FALSE )
    {
        $report[]=array($lll["unableToConnectNoah"], 'conferr');        
    }
    else
    {
        // sets $response and $latestVersion:
        $latestVersionInfo = explode("Version-Info:", $latestVersionInfo);
        eval($latestVersionInfo[1]);
        $report[]=array(sprintf($lll["latestVersionIs"], "$latestVersion-$branch"), 'confok');
        if( $branch=="Free" )
        {
            $report[]=array("(Note: if you previously purchased the PRO version, don't worry - your installation hasn't been degraded to the Free! It's just that we simply got rid of the PRO as a separate package (giving the Free all the extra features of the PRO) and now, we have two packages: the Free and the RSS. This is just a simple naming convention.)", 'confexpl');
        }
        if( $latestVersion!=$globalStat->instver ) 
        {
            View::assign("latestVersion", "$latestVersion-$branch");
            View::assign("updateAutomatic", $lll["updateAutomatic"]);
            View::assign("updateManualZip", $lll["updateManualZip"]);
            View::assign("updateManualTgz", $lll["updateManualTgz"]);
        }
        else $report[]=array($lll["noNeedToUpdate"], 'confok');
        $releaseNotesAddress = 'http://www.noahsclassifieds.org/documentation/changelog';
        $releaseNotes = join('', file($releaseNotesAddress . '?do=export_xhtmlbody'));
        $parts = explode("Release notes</a></h1>", $releaseNotes);
        $releaseNotes = $parts[1];
        View::assign("releaseNotes", $releaseNotes);
    }
    View::assign("branch", $branch);
    View::assign("checkTitle", $lll["checkUpdatesTitle"]);
    View::assign("report", $report);
}

function getVersionInfo($host, $method, $path, $data)
{
    if( ($fp = fsockopen($host, 80, $errno, $errstr, 20))===FALSE || $errno )
    {
        return FALSE; // unable to connect
    }
    if ($method == 'GET') {
        $path .= '?' . $data;
    }
    fputs($fp, "$method $path HTTP/1.1\r\n");
    fputs($fp, "Host: $host\r\n");
    fputs($fp,"Content-type: application/x-www-form-urlencoded\r\n");
    fputs($fp, "Content-length: " . strlen($data) . "\r\n");
    fputs($fp, "Connection: close\r\n\r\n");
    if ($method == 'POST') fputs($fp, $data);

    $buf="";
    while (!feof($fp)) $buf .= fgets($fp,128);
    fclose($fp);
    return $buf;
}

function register()
{
    global $gorumroll,$lll,$gorumuser, $noahVersion;
    
    hasAdminRights($isAdm);
    if( !$isAdm ) LocationHistory::rollBack(new AppController("/"));
    JavaScript::addCss(CSS_DIR . "/checkconf.css?$noahVersion");
    View::assign("report", array());
    $globalStat = new GlobalStat;
    if( $globalStat->registered ) 
    {
        View::assign("checkTitle", $lll["noahAlreadyRegistered"]);
        View::assign("company", $globalStat->company);
        View::assign("firstName", $globalStat->firstName);
        View::assign("lastName", $globalStat->lastName);
        View::assign("email", $globalStat->email);
        return;
    }
    if( !$globalStat->reg ) 
    {
        $globalStat->reg = md5(uniqid(rand(), true));
        modify($globalStat);
    }
    View::assign("checkTitle", $lll["registerNoahTitle"]);
}

function doRegister()
{
    global $gorumroll,$lll,$gorumuser, $noahsRegisterScript, $noahsHost, $noahVersion;
    
    hasAdminRights($isAdm);
    if( !$isAdm ) LocationHistory::rollBack(new AppController("/"));
    JavaScript::addCss(CSS_DIR . "/checkconf.css?$noahVersion");
    $globalStat = new GlobalStat;
    if( !$globalStat->reg ) 
    {
        $globalStat->reg = md5(uniqid(rand(), true));
    }
    $globalStat->company = $_POST["company"];
    $globalStat->firstName = $_POST["firstName"];
    $globalStat->lastName = $_POST["lastName"];
    $globalStat->email = $_POST["email"];
    $data = $this->getTransferData($globalStat, TRUE);
    if( ($result = $this->getVersionInfo($noahsHost, "POST", $noahsRegisterScript, $data))===FALSE )
    {
        View::assign("checkTitle", $lll["unableToConnectNoah"]);       
    }
    else
    {
        if( strstr( $result, "Registration:OK" ) ) 
        {
            View::assign("checkTitle", $lll["noahRegistrationSuccessfull"]);
            $globalStat->registered = TRUE;
        }
        else View::assign("checkTitle", $lll["noahRegistrationFalseResponse"]);
    }
    modify($globalStat);
    View::assign("report", array());
}

function getTransferData( &$globalStat, $withReg = FALSE )
{
    global $_GP, $_GA; 
    
    $settings =& new AppSettings();
    loadSQL($user=new User, "SELECT email FROM @user WHERE isAdm=1 LIMIT 1");
    $data = "id=".$globalStat->reg;
    $data .= "&ip=".urlencode($_SERVER["REMOTE_ADDR"]);
    $data .= "&name=".urlencode(Controller::getBaseUrl());
    $data .= "&php=".urlencode(phpversion());
    $data .= "&mysql=".urlencode(mysql_get_server_info());
    $data .= "&version=".urlencode($globalStat->instver);
    $data .= "&date=".urlencode($globalStat->creationtime->getDbFormat());
    $data .= "&lastUpdate=".urlencode($globalStat->lastUpdate->getDbFormat());
    $data .= "&systemEmail=".urlencode($settings->adminEmail);
    $data .= "&adminEmail=".urlencode($user->email);
    if( !empty($_GP) ) $data .= "&orderCode=".urlencode($_GP);
    if( !empty($_GA) ) $data .= "&affiliateId=".urlencode($_GA);
    $branch = $this->getBranch();
    $data .= "&branch=$branch";
    if( $withReg )
    {
        $data .= "&company=".urlencode($_POST["company"]);
        $data .= "&firstName=".urlencode($_POST["firstName"]);
        $data .= "&lastName=".urlencode($_POST["lastName"]);
        $data .= "&email=".urlencode($_POST["email"]);
    }
    return $data;
}

function getBranch()
{
    if( class_exists("rss") ) return "RSS";
    else return "Free";
}

function doUpdate()
{
    global $gorumroll,$gorumuser, $noahsUpdateScript, $noahsHost;
    
    ini_set("max_execution_time", 0);
    hasAdminRights($isAdm);
    if( !$isAdm ) LocationHistory::rollBack(new AppController("/"));
    $globalStat = new GlobalStat;
    if( !$globalStat->reg ) 
    {
        $globalStat->reg = md5(uniqid(rand(), true));
    }
    $data = "id=".$globalStat->reg;
    $data .= "&version=".urlencode($globalStat->instver);
    if( isset($_POST["automatic"]) )
    {
        if( ($result = $this->getVersionInfo($noahsHost, "POST", $noahsUpdateScript, $data))===FALSE )
        {
            Roll::setInfoText("unableToConnectNoah");       
        }
        else
        {
            $result = explode("Data-Start:", $result);
            eval($result[1]);
            if( $latestVersion!=$globalStat->instver )
            {
                $f = fopen("u.php", "w");
                if( !$f )
                {
                    Roll::setInfoText("updateFailed");
                }
                else
                {
                    fwrite($f, $updateFile);
                    fclose($f);
                    include_once(NOAH_BASE . "/u.php");
                }
            }
        }
        $this->nextAction =& new AppController("checkconf/updates");
    }
    else
    {
        if( ($fp = fsockopen($noahsHost, 80, $errno, $errstr, 20))===FALSE || $errno )
        {
            Roll::setInfoText("unableToConnectNoah");       
            $this->nextAction =& new AppController("checkconf/updates");
            return; // unable to connect
        }
        $branch = $this->getBranch();
        $source = "update-from-$globalStat->instver-$branch.".(isset($_POST["manualZip"]) ? "zip" : "tgz");
        $path = "/versioninfo/get_file.php";
        $data .= "&file=".urlencode($source);
        fputs($fp, "POST $path HTTP/1.1\r\n");
        fputs($fp, "Host: $noahsHost\r\n");
        fputs($fp, "Content-type: application/x-www-form-urlencoded\r\n");
        fputs($fp, "Content-length: " . strlen($data) . "\r\n");
        fputs($fp, "Connection: close\r\n\r\n");
        fputs($fp, $data);
        if( feof($fp) || ($size = $this->getChunkSize($fp))<=3 ) 
        {
            Roll::setInfoText("downloadFileNotExists", $source);
            $this->nextAction =& new AppController("checkconf/updates");
            return FALSE;  // not exists
        }
        while (@ob_end_clean());  // clears all output buffers
        //filenames in IE containing dots will screw up the
        //filename unless we add this
        if (strstr($_SERVER['HTTP_USER_AGENT'], "MSIE"))
           $source = preg_replace('/\./', '%2e', $source, substr_count($source, '.') - 1);
           
        // required for IE, otherwise Content-disposition is ignored
        if(ini_get('zlib.output_compression'))
        ini_set('zlib.output_compression', 'Off');
        
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false);
        header("Content-Description: File Download");
        header("Content-type: application/download");
        header("Content-Disposition: attachment; filename=\"$source\"");
        header("Content-Transfer-Encoding: binary"); 
        header("Content-Length: $size");
        while( $size>0 && !feof($fp) )
        {
            $length = min(1024, $size);
            if( $buf = fgets($fp,$length) ) echo $buf;
            else break;
            flush();
            $size-=strlen($buf);
        }
        fclose($fp);
        die();
    }
}

function getChunkSize($fp)
{
    // get header
    $header="";
    do $header.=fread($fp,1); while (!preg_match('/\\r\\n\\r\\n$/',$header));
    // check for chunked encoding
    if (preg_match('/Transfer\\-Encoding:\\s+chunked\\r\\n/',$header))
    {
        $byte = "";
        $chunk_size="";
        do {
            $chunk_size.=$byte;
            $byte=fread($fp,1);
        } while (ord($byte)!=13);      // till we match the CR
        fread($fp, 1);         // also drop off the LF
        fread($fp, 3);         // also drop off one more empty line
        $chunk_size=hexdec($chunk_size); // convert to real number
        return $chunk_size;
    }
    else
    {
        fread($fp, 3); // also drop off one more empty line
        // check for specified content length
        if (preg_match('/Content\\-Length:\\s+([0-9]*)\\r\\n/',$header,$matches)) return $matches[1];
         // not a nice way to do it (may also result in extra CRLF which trails the real content???)
        return 1000000000; //return just a big enough number
    }
}

function bytesFromSizeString($data) {
	preg_match("/(\d+)(M|K)?/", $data, $matches);
	if ( !isset($matches[2]) ) $matches[2] = "B";
	$multiplier = 1;
	switch (strtolower($matches[2])) {
		case "m": $multiplier *= 1024;
		case "k": $multiplier *= 1024;
	}
	return (int)$matches[1] * $multiplier;
}

function fetchMaxUploadSize() {
	if ( (boolean) ini_get("file_uploads") ) {
		$umf = bytesFromSizeString(ini_get("upload_max_filesize"));
		$pms = bytesFromSizeString(ini_get("post_max_size"));
		return $umf > $pms ? $umf : $pms;
	} else return 0;
}
}

?>
