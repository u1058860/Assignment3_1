<?php
defined('_NOAH') or die('Restricted access');

class OverlayController extends AppController
{

var $id;
var $content='';
var $onLoad='null';
var $onBeforeLoad='null';
var $onClose='null';
var $class='overlay';
var $triggerSelector='a.overlay';
var $ajaxFromHref=FALSE;
var $ajaxFromContent=FALSE;
var $closeOnClick=TRUE;
var $expose=FALSE;
var $postponeOnloadAction=FALSE;
var $onloadAction='';
var $speed=300;
var $top=100;
var $size=1;

/*
  $param lehet egy egyszeru string, vagy tomb, vagy egy AppController objektum. 
  Ha tomb, akkor a fenti osztalyvaltozoknak megfeleloen aszocciativ.
  Ha string, akkor lehet egy $lll label, vagy barmi mas.
  Ha AppController objektum, akkor Ajax-szal toltunk az adott oldalrol
  Ha tomb akkor:
    "content" lehet egy egyszeru string, vagy tomb, vagy egy AppController objektum.
        ha string, vagy AppController objektum, akkor lasd fent,
        ha tomb, akkor egy (osztalynev, metodus)-par es a contentet a metodus meghivasaval toltjuk ki
    "id": az overlay DIV id-je
        ha nem adjuk meg, automatikusan szamozodik: 'content_n'
        ha megadjuk, de mar hoztunk letre OverlayControllert ezzel az id-vel, ujat nem hozunk letre
    "onLoad": az overlay betoltese utan vegrehajtott JS callback,
    "class": az overlay DIV-nek adott CSS class,
    "ajaxFromHref": ha TRUE, akkor a content Ajax-szal toltodik arrol a href-rol, ami a triggerelo linkben van
    "ajaxFromContent": ha TRUE, akkor a content Ajax-szal toltodik arrol a linkrol, ami a content-ben van
    "closeOnClick": clicking outside the overlay close it. by setting this to false doesn't do it 
    "triggerSelector": a triggerelo link (vagy egyeb) kivalasztasara
    "expose": kiemeli az overlay-t a hatter elsotetisevel
    "postponeOnloadAction": erre akkor van szukseg, ha az overlay mukodesehez szukseges JS-t nem az onload-ba
                            akarjuk betenni, hanem kesobb, mondjuk valamilyen event hatasara kell hogy meghivodjon
*/
function OverlayController( $param )
{
    global $lll, $gorumroll;
    static $counter=0;
    static $objects=array();
    
    JavaScript::addInclude(GORUM_JS_DIR . "/jquery/jquery.dimensions.js");
    JavaScript::addInclude(GORUM_JS_DIR . "/jquery/jquery.overlay.js");
    JavaScript::addInclude(GORUM_JS_DIR . "/jquery/jquery.background_layers.js");
    JavaScript::addCss(CSS_DIR . "/overlay.css");
    $args = func_get_args();
    // $ajaxTarget-be gyujtjul a load fuggveny parameteret:
    $text = $ajaxTarget = "";
    if( is_string($param) )
    {
        $this->id = "overlay_".($counter++);
        $text = isset($lll[$param]) ? $lll[$param] : $param;
    }
    elseif( is_object($param) )
    {
        $this->id = "overlay_".($counter++);
        $ajaxTarget = "'" . $param->makeUrl() . "'";
    }
    else
    {
        if( isset($param["id"]) )
        {
            $this->id = $param["id"];
            if( array_key_exists($this->id, $objects) )
            {
                foreach( get_object_vars($objects[$this->id]) as $attr=>$value )
                {
                    $this->$attr =& $objects[$this->id]->$attr;
                }
                return;
            }
        }
        else $this->id = "overlay_".($counter++);
        if( isset($param["class"]) ) $this->class = $param["class"];
        if( isset($param["ajaxFromHref"]) ) $this->ajaxFromHref = $param["ajaxFromHref"];
        if( isset($param["ajaxFromContent"]) ) $this->ajaxFromContent = $param["ajaxFromContent"];
        if( isset($param["content"]) )
        {
            if( is_string($param["content"]) )
            {
                if( substr($param["content"], 0, 6)=="http://" )
                {
                    $ajaxTarget = "'$param[content]'";
                }
                elseif( $this->ajaxFromContent )
                {
                    $ctrl =& new AppController($param["content"]);
                    $ajaxTarget = "'" . $ctrl->makeUrl() . "'";
                }
                else $text = isset($lll[$param["content"]]) ? $lll[$param["content"]] : $param["content"];
            }
            elseif( is_array($param["content"]) )
            {
                $text = call_user_func($param["content"]);
            }
            elseif( is_object($param["content"]) )
            {
                if( $this->ajaxFromContent )
                {
                    $ajaxTarget = "'" . $param["content"]->makeUrl() . "'";
                }
                else
                {
                    $gorumroll->processMethod($param["content"], $this->id );
                    $tpl =& View::getView($this->id);
                    $text = $tpl->__toString();
                }
            }
        }
        if( $this->ajaxFromHref )
        {
            $ajaxTarget = "link.attr('href')";
        }
        if( isset($param["expose"]) ) $this->expose = $param["expose"];
        if( $this->expose )
        {
            JavaScript::addInclude(GORUM_JS_DIR . "/jquery/jquery.expose.js");
            $this->onBeforeLoad = "function() { 
                this.expose({
                    speed: $this->speed,
                    onClose: function() {
                        $('#_overlayImage').hide();
                        $('#$this->id').hide();
                    }
                /*insertionPoint*/
                });  
            }";
            $this->onClose = "function() { 
                $('#blanket').fadeTo($this->speed, 0, function() {
                    $('#blanket').hide();
                });				
                /*insertionPoint*/
            }";
        }
        if( $ajaxTarget ) 
        {
            $this->onLoad = "function(content, link) { 
                content.find('.ajaxOverlayContent').load($ajaxTarget, '', function(){
                    if( typeof $.fn.corner != 'undefined' )
                    {
                        content.find('div.template').corner({
                            tl: { radius: 6 }, 
                            tr: { radius: 6 }, 
                            bl: { radius: 0 }, 
                            br: { radius: 0 },
                            autoPad: false
                        }); 
                        content.find('div.forCurvyFooter').corner({
                            tl: { radius: 0 }, 
                            tr: { radius: 0 }, 
                            bl: { radius: 6 }, 
                            br: { radius: 6 },
                            autoPad: false
                        });
                    }
                    content.find('.submitfooter input').eq(1).click( function() { 
                        $.overlayClose(); 
                        return false; 
                    });
                }); 
                /*insertionPoint*/
            }";
        }
        // ha parameterben erkeznek callback JS sorok, akkor azokat a fentebb definialt callback body-k utan szurjuk be az /*insertionPoint*/ helyere:
        foreach( array("onLoad", "onBeforeLoad", "onClose") as $callback )
        {
            if( isset($param[$callback]) && $this->$callback ) $this->$callback = str_replace( "/*insertionPoint*/", $param[$callback], $this->$callback);
            elseif( isset($param[$callback]) ) $this->$callback = $param[$callback];
            elseif( $this->$callback ) $this->$callback = str_replace( "/*insertionPoint*/", "", $this->$callback);
        }
        if( isset($param["closeOnClick"]) ) $this->closeOnClick = $param["closeOnClick"];
        if( isset($param["postponeOnloadAction"]) ) $this->postponeOnloadAction = $param["postponeOnloadAction"];
        if( isset($param["speed"]) ) $this->speed = $param["speed"];
        if( isset($param["top"]) ) $this->top = $param["top"];
        if( isset($param["size"]) ) $this->size = $param["size"];
    }
    // ajaxFromHref eseten, ha content-ben atadunk valamit, azt be lehet szurni az Ajax tartalom ele:
    $this->content = "<div id='$this->id' class='$this->class' style='background-image:url(".IMAGES_DIR."/white$this->size.png);'>".
                         preg_replace("/\n|\r/", "", addcslashes($text, '"')).
                         "<div class='ajaxOverlayContent'></div> \
                     </div>";
    
    $this->onloadAction = "
        $('body').prepend(\"$this->content\");
        $('$this->triggerSelector').overlay({
            onLoad: $this->onLoad, 
            onBeforeLoad: $this->onBeforeLoad, 
            onClose: $this->onClose,
            closeOnClick: $this->closeOnClick,
            speed: $this->speed,
            top: $this->top
        });
    ";
    if( !$this->postponeOnloadAction )
    {
        JavaScript::addOnload($this->onloadAction, $this->id);
    }
    if( isset($param["id"]) && !isset($objects[$this->id]) ) $objects[$this->id] = $this;

}

// Ha nem Ajaxos az overlay, $ajaxFromHref-et parameteratadasra is hasznalhatjuk!
function generAnchor( $label, $cssClass="overlay", $ajaxFromHref="" )
{
    return GenerWidget::generAnchor($ajaxFromHref, $label, $cssClass, "", TRUE, "#$this->id" );
}

// Ha nem Ajaxos az overlay, $ajaxFromHref-et parameteratadasra is hasznalhatjuk!
function generImageAnchor( $src, $alt, $width="", $height="", $cssClass="", $ajaxFromHref="" )
{
    return GenerWidget::generImageAnchor($ajaxFromHref, $src, $alt, $width, $height, $cssClass, "", "#$this->id" );
}

function getOnloadAction() { return $this->onloadAction; }

}
?>
