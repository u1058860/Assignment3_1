<?php

include_once("item_typ.php");

class Item extends CustomFieldContainer
{

// Ezt a scrollable widget miatt kell ide tenni. Ott a list-hez tartozo select-et meg a htmlList elejen
// le kell kerdezni, hogy a setupCustomListAppearance-t vegrehajthassuk es hogy az beallithassa a
// $item_typ["listTemplate"]-et es $item_typ["listPresentationClassName"]-et
var $select = array();

// custom list megjelenitese eseten, a get list selectben beleirjuk a customlist listTitle, listDescription
// mezejet ezekbe, hogy az afterView a getPageTitle es a getPageDescription fuggvenyekkel lekerdezhesse:
var $pageTitle = "";
var $pageDescription = "";
var $pageKeywords = "";

function getCustomFieldClass() { return "itemfield"; }
    
function getFields()
{
    if( !$this->fields && ($cid=$this->getCid())!==null ) 
    {
        $query = "SELECT * FROM @itemfield WHERE cid=#cid# ORDER BY sortId ASC";
        G::load($this->fields, array($query, $cid));
    }
    ItemField::updateFromUserFields($this->fields);
    return $this->fields;
}

function getCid()
{
    if( empty($this->cid) && !empty($this->id) ) $this->cid = intval(G::getAttr($this->id, "item", "cid"));
    return empty($this->cid) ? NULL : $this->cid;
}

function getCategory()
{
    if( $this->getCid() ) return G::load( $this->cid, "appcategory" );
    else return NULL;
}

function getImmediateAppear()
{
    if( empty($this->immediateAppear) && $this->getCid() ) $this->immediateAppear = intval(G::getAttr($this->cid, "appcategory", "immediateAppear"));
    return !isset($this->immediateAppear) ? NULL : $this->immediateAppear;
}

function getInactivateOnModify()
{
    if( empty($this->inactivateOnModify) && $this->getCid() ) $this->inactivateOnModify = intval(G::getAttr($this->cid, "appcategory", "inactivateOnModify"));
    return !isset($this->inactivateOnModify) ? NULL : $this->inactivateOnModify;
}

function getExpiration()
{
    if( empty($this->expiration) && $this->getCid() ) $this->expiration = intval(G::getAttr($this->cid, "appcategory", "expiration"));
    return !isset($this->expiration) ? NULL : $this->expiration;
}

function getExpirationEnabled()
{
    if( empty($this->expirationEnabled) && $this->getCid() ) $this->expirationEnabled = intval(G::getAttr($this->cid, "appcategory", "expirationEnabled"));
    return !isset($this->expirationEnabled) ? NULL : $this->expirationEnabled;
}

function getExpirationOverride()
{
    if( empty($this->expirationOverride) && $this->getCid() ) $this->expirationOverride = intval(G::getAttr($this->cid, "appcategory", "expirationOverride"));
    return !isset($this->expirationOverride) ? NULL : $this->expirationOverride;
}

function getPicDir() { return AD_PIC_DIR; }
function getUploadDir() { return UPLOAD_DIR; }

function hasObjectRights(&$hasRight, $method, $giveError=FALSE)
{
    global $lll,$gorumrecognised,$gorumuser, $gorumroll;
    
    if( $method=="prolong_expiration" ) 
    {
        $this->id = $gorumroll->rollid;
        $this->hasObjectRights($hasRight, "modify", $giveError);
        return;
    }
    $hasRight->objectRight=FALSE;
    $hasRight->generalRight = TRUE;
    if( $method=="load" )
    {
        $hasRight->objectRight=TRUE;
    }
    elseif( !$gorumrecognised )
    {
        $hasRight->objectRight=FALSE;
    }
    elseif( $gorumuser->isAdm )
    {
        $hasRight->objectRight=TRUE;
    }
    elseif( $method=="create" )
    {
        $hasRight->objectRight=$gorumrecognised;
    }
    elseif( $method=="approve" )
    {
        $hasRight->objectRight=FALSE;
    }
    elseif( isset($this->ownerId) && $this->ownerId==$gorumuser->id )
    {
        $hasRight->objectRight=TRUE;
        $hasRight->generalRight = FALSE;
    }
    // Ez akkor van, mikor a modify az invalid formra visz:
    elseif( !isset($this->ownerId) && ($method=="modify" || $method=="delete"))
    {
        $hasRight->generalRight = FALSE;
        if( !isset($this->id) && $gorumroll->rollid && $gorumroll->list=="item" && $gorumroll->method=="showdetails" ) $this->id = $gorumroll->rollid;
        if( isset($this->id ) )
        {
            $query = array("SELECT ownerId FROM @item WHERE id=#this->id#", $this->id);
            $ret = loadSql( $this, $query );
            $hasRight->objectRight = (!$ret && $this->ownerId==$gorumuser->id);
        }
        else $hasRight->objectRight = FALSE;
    }
    if( !$hasRight->objectRight && $giveError )
    {
        handleError($lll["permission_denied"]);
    }
}

function hasCaptcha($postfix="")
{
    global $gorumroll;
    if( !empty($this->cid) && $gorumroll->method=="create$postfix" && 
        in_array(Settings_submitAd, explode(",", $this->s->applyCaptcha))) return TRUE;
    return FALSE;
}

function showNewTool($rights)
{
    global $lll,$gorumroll, $gorumrecognised, $gorumuser;

    $s=parent::showNewTool($rights);
    if( $gorumroll->list=="item" && $this->s->notifyEnabled() )
    {
        if( $gorumrecognised )
        {
            $query = array("SELECT * FROM @subscription WHERE uid=#gorumuser->id# AND cid=#gorumroll->rollid#", 
                           $gorumuser->id, $gorumroll->rollid);
            $subscription = new Subscription;
            if( $ret = loadSQL($subscription,$query ) )
            {
                $ctrl =& new AppController("subscription/create/$gorumroll->rollid");
                if( $s ) $s.=" | ";
                $s.=$ctrl->generAnchor($lll["autoNotifyCat"]);
            }
            else
            {
                $ctrl =& new AppController("subscription/delete/$gorumroll->rollid");
                if( $s ) $s.=" | ";
                $s.=$ctrl->generAnchor($lll["unsubscribeCat"]);
            }
        }
        else
        {
            $ctrl =& new AppController("subscription/create_form/$gorumroll->rollid");
            if( $s ) $s.=" | ";
            $s.=$ctrl->generAnchor($lll["autoNotifyCat"]);
        }
    }
    return $s;
}

function showModTool($rights)
{
    global $lll, $gorumuser;

    hasAdminRights( $isAdm );
    $tools = array();
    if( $isAdm && !$this->status )
    {
        $ctrl =& new AppController("item/approve/$this->id");
        $tools[]=$ctrl->generAnchor($lll["approve"]);
    }
    if( ($isAdm || $this->s->allowModify) && ($modTool = parent::showModTool($rights)) ) $tools[]=$modTool;
    if( $isAdm )
    {
        $ctrl =& new AppController("item/move_form/$this->id");
        $tools[]=$ctrl->generAnchor($lll["move"]);
    }
    if( $this->s->favoritiesEnabled())
    {
        $tools[]=$gorumuser->showFavoritiesTool($this->id);
    }
    return implode(" | ", $tools);
}

function approve()
{
    global $lll, $gorumroll;

    CustomField::addCustomColumns("item");
    $this->id = $gorumroll->rollid;
    load($this);
    hasAdminRights( $isAdm );
    if( !$isAdm ) return;
    $this->status=TRUE;
    $this->changeStatus(TRUE);    
    Roll::setInfoText("adApproved");
    $this->rollBackNum = 1;
}

function changeStatus( $newStatus )
{
    if( $newStatus ) // approve
    {
        G::load($c, $this->cid, "category");
        // ha van expiration es ez az item meg sosem volt aktivalva, vagy ha restartExpOnModify van, 
        // akkor az approve-tol indul az expiration
        if( $this->expiration && ($this->expirationTime->isEmpty() || $c->restartExpOnModify) )
        {
            $this->expEmailSent=FALSE;
            $this->expirationTime = Date::add($this->expiration, Date_Day);
        }
        modify($this);
        $c->increaseDirectItemNum();
    
        // mailt kuldunk rola a tulajnak:
        G::load($n, Notification_adApproved, "notification");
        if( $n->active )
        {
            $ctrl =& new AppController("item/$this->id");
            $title=$ctrl->generAnchor($this->getTitle(), "", TRUE, "", FALSE);  // absolute, no encoding (getTitle does it!)
            G::load($owner, $this->ownerId, "user");
            $n->send( $owner->email, $title );
        }
        $this->sendNotificationsToSubscribedUsers();
    }
    else  // approve visszavonasa
    {
        G::load($c, $this->cid, "category");
        $c->decreaseDirectItemNum();
    }
    CacheManager::resetCache($this->cid);
}

function delete( $whereFields="", $calledFrom='itemDelete' )
{
    global $gorumroll, $siteDemo;

    if( $siteDemo ) return Roll::setInfoText("This operation is not permitted in the demo.");
    parent::delete($whereFields);
    // Ha az admin torolte ki az ad-et, akkor emailt kell kuldeni a
    // tulajnak:
    hasAdminRights( $isAdm );
    // Ha a kategoria torleserol jutunk ide, nem kell levelet kuldeni:
    G::load($cat, $this->cid, "appcategory");
    if( $isAdm && $calledFrom=='itemDelete' )
    {
        G::load($n, Notification_adDeleted, "notification");
        if( $n->active )
        {
            G::load($owner, $this->ownerId, "user");
            if( isset($owner->email) && $owner->email )
            {
                $n->send( $owner->email, htmlspecialchars($cat->name), $this->getTitle() ); //TODO: description
            }
        }
    }
    if( $calledFrom!='categoryDelete' && $this->status ) $cat->decreaseDirectItemNum();
    $query=array("SELECT id, favorities FROM @user WHERE FIND_IN_SET(#this->id#, favorities)!=0", $this->id);
    $users = new User;
    loadObjectsSql($users, $query, $users);
    foreach( $users as $u )
    {
        $f = preg_replace("{(,)?\\b$this->id\\b(?(1)|(,|$))}", "", $u->favorities);
        executeQuery("UPDATE @user SET favorities=#f# WHERE id=#u->id#", $f, $u->id);
    }
    CacheManager::resetCache($this->cid);
}

function showListVal($attr)
{
    global $gorumroll, $lll, $gorumuser, $gorumrecognised;

    $s="";
    if( ($s=parent::showListVal($attr))!==FALSE )
    {
        return $s;
    }
    if ($attr=="title") {
        $ctrl =& new AppController($this->get_class() . "/$this->id");
        $s=$ctrl->generAnchor($this->getTitle(), "", FALSE, "", FALSE);  // no encoding
    }
    elseif( $attr=="expirationTime")
    {
        if( $this->status && !$this->expirationTime->isEmpty() )
        {
            //var_dump($this);
            $s=round($this->expirationTime->getDayDiff());
            if( $this->expirationTime->isPast() ) $s = "-$s";
            //echo "$this->renewalNum $renewal";
            if( $this->expEmailSent && $this->ownerId==$gorumuser->id &&
                $gorumrecognised && $this->renewalNum < $this->s->renewal)
            {
                $ctrl =& new AppController("item/prolong_expiration/$this->id");
                $s.=" ".$ctrl->generAnchor($lll["prolongExp"]);
            }
        }
        else $s = $lll["N/A"];
    }
    elseif ($attr=="shoppingCartLink" && $withShoppingCart)
    {
        $ctrl =& new AppController("shoppingcart/create_form/$this->id");
        $s=$ctrl->generImageAnchor("i/add2cart.gif", $lll["addToChart"]);
    }
    elseif ($attr=="responded" || $attr=="clicked" )
    {
        $s = $this->$attr;
    }
    else
    {
        $s=Object::showListVal($attr, "safetext");
    }
    return $s;
}

function prolongExpiration()
{
    global $lll, $gorumroll;

    $this->id = $gorumroll->rollid;
    load($this);
    if( $this->renewalNum < $this->s->renewal )
    {
        $this->expirationTime = $this->expirationTime->add($this->getDefaultExpiration(), Date_Day);
        $this->expEmailSent = FALSE;
        $this->renewalNum++;
        modify($this);
        $it = $lll["expirationProlonged"];
        if( $this->renewalNum==$this->s->renewal ) $it.=$lll["lastRenewal"];
        Roll::setInfoText($it);
        CacheManager::resetCache($this->cid);
    }
    $this->nextAction =& new AppController("item/$this->id");
}

function create()
{
    global $gorumuser;

    if( empty($this->cid) ) return Roll::setFormInvalid("selectCategoryNecessary");
    hasAdminRights($isAdm);
    if( !$this->s->showSubmitAd() && !$isAdm ) handleError("Permission denied");
    $this->activateVariableFields();
    LocationHistory::resetPost();
    $this->initClassVars();
    LocationHistory::savePost($this);
    if( !$this->checkAgainstEarlySubmission() || !$this->checkCharacterLimit() ||
         $this->checkMandatoryFileUpload()    || !$this->checkAndSetExpirationDays() ) return;
    if( !$isAdm || !isset($this->status) ) $this->status=$this->getImmediateAppear();  // ha viszont isAdm, akkor a status benne van a formban
    if( $this->status )  // ha aktivkent krealjuk akkor az expiration is szamlalodni kezd:
    {
        if( $this->expiration ) $this->expirationTime = Date::add($this->expiration, Date_Day);
    }
    $this->setDefaultsOfFieldsThatDontAppearInForm();
    if( !isset($this->ownerId) ) $this->ownerId = $gorumuser->id;
    parent::create();
    if( !Roll::isFormInvalid() )
    {
        G::load($c, $this->cid, "appcategory");
        if( $this->status ) $c->increaseDirectItemNum();
        else Roll::addInfoText("adScheduled");
        $ctrl =& new AppController("item/$this->id");
        $title=$ctrl->generAnchor($this->getTitle(), "", TRUE, "", FALSE);  // absolute
        if( !$isAdm )  // csak akkor kell ertesites, ha nem admin krealta
        {
            G::load($n, Notification_adCreated, "notification");
            if( $n->active )
            {
                // mailt kuldunk rola az adminnak:
                $n->send( $this->s->adminEmail, $title );
            }
        }
        $this->storeAttachment();
        $this->sendNotificationsToSubscribedUsers($title);
        $this->nextAction =& new AppController("item/$this->id");
        CacheManager::resetCache($this->cid);
    }
}

function sendNotificationsToSubscribedUsers($title)
{
    if( $this->status && class_exists("response") && $this->s->subscriptionType!=customfield_forNone)
    {
        G::load($n, Notification_autoNotify, "notification");
        if( $n->active )
        {
            if( $this->s->subscriptionType==customfield_forAll )
            {
                $query = array("SELECT email FROM @subscription WHERE cid=#this->cid# AND email!=''", $this->cid);
                $deleteLink = 'subscription/delete/0/email/$s->email';
            }
            elseif( $this->s->subscriptionType==customfield_forLoggedin )
            {
                $query = array("SELECT uid, u.email AS email FROM @subscription AS s, @user as u WHERE s.uid=u.id AND cid=#this->cid# AND uid!=0", $this->cid);
                $deleteLink = 'subscription/delete/$this->cid/uid/$s->uid';
            }
            else // forAdmin
            {
                $query = array("SELECT uid, u.email AS email FROM @subscription AS s, @user as u WHERE s.uid=u.id AND cid=#this->cid# AND uid!=0 AND u.isAdm=1", $this->cid);
                $deleteLink = 'subscription/delete/$this->cid/uid/$s->uid';
            }
            G::load( $subscriptions, $query );
            foreach( $subscriptions as $s )
            {
                eval('$dl = "'.$deleteLink.'";');
                $ctrl =& new AppController($dl);
                $n->send( $s->email, $title, $ctrl->makeUrl(TRUE) );
            }
        }
    }
}

// elofordulhat, hogy a kategoria kivalasztasa utan a create formban gyorsabban nyomnak az Ok gombra,
// mint ahogy a custom fieldek "legordulnek". 
function checkAgainstEarlySubmission()
{
    if( !isset($_POST["cid"]) ) return TRUE; // ha az installbol erkezunk
    $typ =& $this->getTypeInfo(TRUE);
    for( $i=0; $i<count($this->fields); $i++ )
    {
        $field = & $this->fields[$i];
        if( !isset($this->{$field->columnIndex}) && !isset($_FILES[$field->columnIndex]) && 
            $field->type!=customfield_separator && !$field->isFixField() && !$field->userField &&
            $this->fieldExistsInForm($typ, $field->columnIndex)) 
        {
            return Roll::setFormInvalid();
        }
    }
    return TRUE;
}

function modify( $whereFields="" )
{
    global $gorumuser, $now;

    hasAdminRights($isAdm);
    if( !$isAdm && !$this->s->allowModify ) return;
    $this->getCid();
    $this->activateVariableFields();
    $this->initClassVars();
    LocationHistory::savePost($this);
    if( !$this->checkCharacterLimit() ) return;
    if( !$this->checkAndSetExpirationDays() ) return;
    G::load( $old, $this->id, "item" );
    if( !$isAdm )
    {
        // ha a tulaj modosit, ujra inactive lesz az item:
        if( !$this->getImmediateAppear() && $this->getInactivateOnModify() ) $this->status=FALSE;
        // ha restartExpOnModify van, az olyan mintha az ad most jott volna letre:
        elseif( G::getAttr($this->cid, "appcategory", "restartExpOnModify") ) 
        {
            if( !$this->expirationAppearsInForm() && $this->expiration ) 
            {
                $this->expEmailSent=FALSE;
                $this->expirationTime = Date::add($this->expiration, Date_Day);
            }
        }
    }
    // ha az expiration megjelent a formban es modositottak is, akkor az expirationTime-ot megfeleloen modositani kell:
    if( $this->expirationAppearsInForm() && 
        ($this->expiration!=round($old->expirationTime->getDayDiff()) ||
        ($this->expiration>0 && $old->expirationTime->isPast()) ||
        ($this->expiration<0 && $old->expirationTime->isFuture()))) $this->expirationTime = Date::add($this->expiration, Date_Day);
    parent::modify();
    load($this);
    if( !Roll::isFormInvalid() )
    {
        if( !$this->getImmediateAppear() && $this->status!=$old->status ) $this->changeStatus($this->status);
        if( !$isAdm && $old->status && !$this->status )  // ha a tulaj modositott, es most valtottunk pendingre, admint ertesitjuk az uj pending itemrol
        {
            Roll::addInfoText("adScheduled");
            G::load($n, Notification_adCreated, "notification");
            if( $n->active )
            {
                // mailt kuldunk rola az adminnak:
                $ctrl =& new AppController("item/$this->id");
                $title=$ctrl->generAnchor($this->getTitle(), "", TRUE, "", FALSE);  // absolute
                $n->send( $this->s->adminEmail, $title );
            }
        }
        $this->storeAttachment();
        CacheManager::resetCache($this->cid);
    }
}

function checkCharacterLimit()
{
    $object_vars = get_object_vars($this);
    foreach( $object_vars as $attr=>$val )
    {
        if (!is_array($val) && !is_object($val) && $this->s->charLimit && strlen($val)>$this->s->charLimit) 
        {
            return Roll::setFormInvalid("ad_limit_exc",$this->s->charLimit, strlen($val));
        }
    }
    return TRUE;
}

function checkAndSetExpirationDays()
{
    if( !$this->expirationAppearsInForm() )
    {
        $this->expiration = $this->getDefaultExpiration();
    }
    elseif( $defaultExpiration = $this->getDefaultExpiration() )
    {
        // ha uresen hagytak az expirationt, a default lep ervenybe:
        if( empty($this->expiration) ) $this->expiration = $defaultExpiration;
        // ha nagyobbat adtak meg, mint a megadhato maximum:
        elseif( $this->expiration > $defaultExpiration )
        {
            return Roll::setFormInvalid("item_expiration_expl_2", $defaultExpiration);
        }
    }
    return TRUE;
}

function expirationAppearsInForm()
{
    global $gorumroll;
    
    hasAdminRights($isAdm);    
    return $this->getExpirationEnabled() && class_exists('response') &&
           ($or = $this->getExpirationOverride())!=customfield_forNone &&
           ($isAdm || ($or!=customfield_forAdmin && (!$this->getDefaultExpiration() || strstr($gorumroll->method, "create"))));
    // ha van maximum expiration es az owner nem admin, akkor csak a create formban adhat meg expirationt - kesobb ezt nem 
    // modosithatja a modify formban (mert az prolong-nak minosulne)
}

function getDefaultExpiration()
{
    return intval(G::getAttr($this->cid, "appcategory", "expiration"));
}

function showDetails($whereFields="", $withLoad=TRUE, $elementName="")
{
    global $gorumroll,$item_typ, $gorumuser, $gorumcategory;

    $this->id = $gorumroll->rollid;
    if( load($this) ) 
    {
        Roll::setInfoText("adNotFound");
        LocationHistory::saveInfoText();
        LocationHistory::rollBack(new AppController("/"));
    }
    $gorumcategory = $this->cid;
    if( $gorumuser->id!=$this->ownerId && !$gorumuser->isAdm )
    {
        $this->clicked++;
        modify($this);
    }
    $this->activateVariableFields();
    load($this);
    $this->loadUserFields();
    hasAdminRights( $isAdm );
    $expField = $this->getField("expirationTime");
    $statusField = $this->getField("status");
    $displayExpirationInDetails = !$this->expirationTime->isEmpty() && $expField->displayInDetailsCondition($this->ownerId);
    if( !$this->getImmediateAppear() )
    {
        if( $statusField->displayInDetailsCondition($this->ownerId) )
        {
            $item_typ["attributes"]["status"][]="details";
        }
        // Az expiration time-nak csak akkor van ertelme, ha mar active:
        if( $displayExpirationInDetails && $this->status )
        {
            $item_typ["attributes"]["expirationTime"][]="details";
        }
        // Vagy akkor, ha meg nem aktiv, de expiration time-mal hoztak letre es a tulaj, vagy admin nezi:
        elseif( $expField->displayInDetailsCondition($this->ownerId) && $this->expiration && !$this->status )
        {
            $item_typ["attributes"]["expiration"][]="details";
        }
    }
    elseif( $displayExpirationInDetails )
    {
        $item_typ["attributes"]["expirationTime"][]="details";
    }
    if( class_exists("response" ) ) $this->showEmailLinks();
    parent::showDetails($whereFields, FALSE, $elementName);
}

// betolti az ertekeket azokhoz a custom fieldekhez, amik a tulajdonosnak egy custom fieldjere mutatnak:
function loadUserFields()
{
    $owner = new User;
    $owner->id = $this->ownerId;
    $owner->activateVariableFields();
    load($owner);
    foreach( $this->getFields() as $field )
    {
        if( $field->userField ) 
        {
            $attr = G::getAttr($field->userField, "userfield", "columnIndex");
            $this->{$field->columnIndex} = substr($attr, 0, 4)=="col_" ? $owner->{$attr} : $owner->showListVal($attr);
        }
    }
}

function showEmailLinks()
{
    global $lll;

    $ctrl =& new AppController("response/create_form/$this->id");
    View::assign("responseLink", $ctrl->generAnchor($lll["new_resp"], '', '_blank'));
    $ctrl =& new AppController("friendmail/create_form/$this->id");
    View::assign("friendmailLink", $ctrl->generAnchor($lll["new_frie"], '', '_blank'));
}

function getListSelect( $retrieveSelectOnly=TRUE, $elementName="" )
{
    global $item_typ, $gorumroll, $gorumuser, $lll, $gorumcategory;
    
    // hogy ne hivodjon meg ketszer foloslegesen a getCount miatt
    // Ha kulonbozo queryStringgel hivjuk, akkor viszont tobbszor is meghivodhat: 
    $qs = $gorumroll->ctrl->makeQueryString();
    if( isset($this->select[$qs]) && $retrieveSelectOnly ) return $this->select[$qs]; 
    CustomField::addCustomColumns("item");
    // Az adott user altal birtokolt itemek:
    if ($gorumroll->list=="item_my") 
    {
        $owner = new User;
        $owner->name = $gorumroll->rollid;
        $userId = load($owner, array("name")) ? 0 : $owner->id;
        
        $search = new CustomList;
        $search->activateVariableFields();
        // az 2-es ID-ju custom list a 'My ads':
        loadSQL($search, "SELECT * FROM @search WHERE id=2");
        $search->setupCustomListAppearance($elementName);
        // mas hirdeteseibol csak az aktivakat lathatjuk:
        hasAdminRights($isAdm);
        if( !$isAdm ) $search->query.=" AND status=1";
        $this->select[$qs] = array($search->query, $userId);
        $lll["item_my_ttitle"] = sprintf($lll["item_my_ttitle"], $owner->showListVal("name"));
        $this->pageTitle = $this->pageDescription = strip_tags($lll["item_my_ttitle"]);
    }
    //egy kereses eredmenye:
    elseif ($gorumroll->list=="item_search") {
        // normal search eseten, az 1-es ID-ju customlistet kell lekernunk:
        $clId = $gorumroll->rollid ? $gorumroll->rollid : 1;
        $search = new CustomList;
        $search->activateVariableFields();
        if( !loadSQL($search, array("SELECT * FROM @search WHERE id=#id#", $clId)) )
        {
            $search->setupCustomListAppearance($elementName);
        }
        else 
        {
            Roll::setInfoText("listNotFound");
            LocationHistory::saveInfoText();
            LocationHistory::rollBack(new AppController("/"));
        }
        if( $clId==1 ) // normal search
        {
            loadSQL($search = new Search, array("SELECT * FROM @search WHERE uid=#uid# AND name=''", $gorumuser->id));
            $this->activateVariableFields();
        }
        else
        {
            $this->pageTitle = $search->listTitle;
            $this->pageDescription = $search->listDescription;
            $search->applyCategoryFilterToSearchQuery();
        }
        $this->select[$qs] = array($search->query, $gorumuser->id);
    }
    elseif ($gorumroll->list=="item_favorities") {
        $this->activateVariableFields();
        $this->select[$qs] = array("SELECT n.*, c.wholeName AS cName, ".
                  "c.immediateAppear AS immediateAppear ".
                  "FROM @item AS n, @category AS c ".
                  "WHERE c.id=n.cid AND FIND_IN_SET(n.id, #favorities#)!=0", $gorumuser->favorities);
    }
    // Egy adott kategoria itemjei:
    else 
    {
        $userQueryPieces = ItemField::getUserQueryPieces($gorumroll->rollid);
        $this->select[$qs] = array("SELECT n.* ".$this->getSpecialSortAttrs().", c.wholeName AS cName, ".
                  "c.immediateAppear AS immediateAppear $userQueryPieces[as] FROM @item AS n, @category AS c $userQueryPieces[from] ".
                  "WHERE $userQueryPieces[where] cid=#rollid# AND c.id=n.cid AND n.status='1'", $gorumroll->rollid);
    }
    return $this->select[$qs];
}

function getLimit()
{
    $typ =& $this->getTypeInfo();
    // ha a customlistben limitet allitottak, az felulirja a blockSize-t:
    //var_dump($typ);
    if( isset($typ["listPresentationClassName"]) && $typ["listPresentationClassName"]=="ItemScrollablePresentation" ) 
    {
        return isset($typ["limit"]) ? "LIMIT $typ[limit]" : "";
    }
    else return parent::getLimit();
}

function loadHtmlList(&$list)
{
    global $item_typ, $gorumroll; 
    
    parent::loadHtmlList($list);
    if( $gorumroll->list=="item_search" && count($list) && !$gorumroll->rollid )
    {
        $cid = $list[0]->cid;
        while( ($item = current($list)) && $oneCatExists = ($item->cid==$cid) ) next($list);
        if( $oneCatExists ) 
        {
            include("item_typ.php");  // resetting $item_typ
            $this->setupCategorySpecificList($cid);
            // hogy a prototype-os mezok tenyleg objektumok legyenek:
            foreach( $list as $item )
            {
                foreach( $item_typ["attributes"] as $attr=>$attrInfo )
                {
                    if( isset($item->{$attr}) && isset($attrInfo["prototype"]) )
                    {
                        $item->{$attr} = new $attrInfo["prototype"]($item->{$attr});
                    }
                    // ha egy nem kategory specifikus search eredmenyet jelenitjuk meg es azt 
                    // kategoria specifikus oszlopokkal kivanjuk kiegesziteni, akkor 
                    // gaz lehet a user fieldekkel! A user filedek lekerdezesehez ugyanis
                    // meg a search query osszeallitasa soran be kell a querybe tenni a megfelelo 'AS' mezoket,
                    // hogy a juzerbol szarmazo oszlopokat bedzsojnozzuk az itembe. Egy advanced search eseten
                    // azonban ez nem tortenik meg, ezert ezeknek az oszlopoknak az ertekei definialatlanok lesznek
                    // (viszont az activateVariableFields ugy jelzi oket mint megmutatando oszlopokat!).
                    // Az ilyen oszlopokat nem tudjuk megmutatni, ezert itt ki is vesszuk a typeinfobol:
                    if( in_array("list", $attrInfo) && !isset($item->{$attr}) ) 
                    {
                        Object::removeFromTypeInfo( $attr, "list", "item_typ" );
                    }
                }
            }
        }
    }
}

function generForm()
{
    global $lll, $gorumroll, $item_typ;
    
    hasAdminRights($isAdm);
    if( !$isAdm || $this->getImmediateAppear() || !$gorumroll->rollid )
    {
        $item_typ["attributes"]["status"][]="form invisible";
    }
    if( !$this->expirationAppearsInForm() )
    {
        $item_typ["attributes"]["expiration"][]="form invisible";
    }
    elseif( $defaultExpiration = $this->getDefaultExpiration() )
    {
        $item_typ["attributes"]["expiration"]["default"] =
        $item_typ["attributes"]["expiration"]["max"]     = $defaultExpiration;
        $lll["item_expiration_expl"] = sprintf($lll["item_expiration_expl_2"], $defaultExpiration);
    }
    else // $defaultExpiration == 0
    {
        if( empty($this->expiration) ) $this->expiration="";
        $lll["item_expiration_expl"] = $lll["item_expiration_expl_1"];
    }
    parent::generForm();
}

function createForm()
{
    global $gorumroll, $gorumcategory;

    $this->cid = $gorumcategory = $gorumroll->rollid;
    $this->hasObjectRights($hasRight, "create", FALSE);
    hasAdminRights($isAdm);
    if( !$this->s->showSubmitAd() && !$isAdm ) handleError("Permission denied");
    if( !$hasRight->objectRight )
    {
        Roll::setInfoText("registerOrLoginToSubmit");
        $this->nextAction =& new AppController("user/login_form");
        $gorumroll->afterAction($this);
    }
    if( $this->cid )
    {
        $this->activateVariableFields();
        $this->initClassVars();
    }
    parent::createForm();
    JavaScript::addOnload("
        $('#cid').change(function (){
            var cid = this.options[this.selectedIndex].value;
            var href = location.href;
            location.href = href.replace(/\/?\d*$/, '/'+cid);
        });    
    ");
}

function modifyForm()
{
    global $gorumroll, $lll, $gorumcategory;

    $this->id = $gorumroll->rollid;
    $gorumcategory = $this->getCid();
    $this->activateVariableFields();//csak emiatt kellett feluldefinialn
    $this->initClassVars();
    if( !Roll::isPreviousFormSubmitInvalid() )
    {
        $ret = $this->load();
        if( $ret )
        {
            $txt = $lll["not_found_in_db"];
            handleError($txt);
        }
    }
    $this->hasObjectRights($hasRight, "modify", TRUE);
    if( isset($this->expirationTime) && !$this->expirationTime->isEmpty() ) 
    {
        $this->expiration = round($this->expirationTime->getDayDiff());
        if( $this->expirationTime->isPast() ) $this->expiration = "-$this->expiration";
    }
    $this->generForm();
}

function moveForm()
{
    global $gorumroll, $lll;

    // csak admin move-olhat:
    hasAdminRights($isAdm);
    if(!$isAdm) return;
    $this->id = $gorumroll->rollid;
    $ret = $this->load();
    $lll["item_cid_expl"] = $lll["onlyCompatibleExpl"];
    $this->generForm();
}

function getCompatibleCategories()
{
    G::load( $categories, "SELECT id, wholeName FROM @category WHERE allowAd=1 ORDER BY sortId ASC, wholeName ASC" );
    ItemField::filterCompatibleCategories($this->cid, $categories);
    return $categories;
}

function move()
{
    global $gorumroll;

    // csak admin move-olhat:
    hasAdminRights($isAdm);
    if(!$isAdm) return;
    $oldCid = G::getAttr( $this->id, "item", "cid" );
    // ha nincs move-olas:
    if( $oldCid==$this->cid ) return;
    G::load( $newCategory, array("SELECT * FROM @category WHERE id=#cid#", $this->cid) );
    // Ellenorzes:
    ItemField::filterCompatibleCategories($oldCid, $newCategory);
    if( !count($newCategory) ) return; // trukkozes
    $newCategory = $newCategory[0];
    
    CustomField::addCustomColumns("item");
    G::load( $oldFields, array("SELECT columnIndex FROM @customfield WHERE cid=#cid# ORDER BY sortId ASC", $oldCid));
    G::load( $newFields, array("SELECT columnIndex FROM @customfield WHERE cid=#cid# ORDER BY sortId ASC", $this->cid));
    load($this);
    $newObj = gclone($this);
    $newObj->cid = $newCategory->id;
    if( $newCategory->immediateAppear ) $newObj->status=TRUE;
    for( $i=0; $i<count($oldFields); $i++  )
    {
        if( isset($this->{$oldFields[$i]->columnIndex}) ) $newObj->{$newFields[$i]->columnIndex} = $this->{$oldFields[$i]->columnIndex};
    }
    modify($newObj);
    // itemnumok beallitasa
    if( $newObj->status ) $newCategory->increaseDirectItemNum();
    G::load( $oldCategory, $oldCid, "appcategory" );
    if( $this->status ) $oldCategory->decreaseDirectItemNum();
    Roll::setInfoText("adMoved");
    CacheManager::resetCache($this->cid);
    CacheManager::resetCache($oldCid);
}

function valid()
{
    parent::valid();
    if( !Roll::isFormInvalid() ) Object::valid();
}

function showNavBar($withLink=FALSE)
{
    global $gorumroll, $navBarSeparator;

    if (empty($this->cid)) return "";
    G::load($fatherCat, $this->cid, "appcategory");
    $s = $fatherCat->showNavBar();
    if( $title = $this->getTitle() ) $s.= $navBarSeparator . $title;
    return $s;
}

function getTitle($encoding=TRUE)
{
    static $commonTitleField=0;
    
    $typ =& $this->getTypeInfo();
    $columnIndex = FALSE;
    if( $fields = $this->getFields() )
    {
        foreach( $fields as $field ) 
        {
            if( $field->seo==customfield_title )
            {
                $columnIndex = $field->columnIndex;
                break;
            }
        }
        if( $columnIndex===FALSE || !isset($this->{$columnIndex})) return "";
        else
        {
            if( !$commonTitleField ) 
            {
                loadSQL( $commonTitleField=new ItemField, "SELECT * FROM @customfield WHERE isCommon=1 AND columnIndex='title'" );
            }
            // a displayLength-en nem az egyes kategoriak description mezoinek displayLenght-je hatarozza meg,
            // hanem az amit a common description fieldben van:
            $this->applyDisplayLengthLimit( $this->{$columnIndex}, $commonTitleField->displaylength );
            if( $encoding && !$field->allowHtml ) 
            {
                return htmlspecialchars($this->{$columnIndex});
            }
            else return $this->{$columnIndex};
        }
    }
    else return "";
}

function getDescription($encoding=TRUE)
{
    static $commonDescriptionField=0;
    
    $columnIndex = FALSE;
    if( $fields = $this->getFields() )
    {
        foreach( $fields as $field ) 
        {
            if( $field->seo==customfield_description )
            {
                $columnIndex = $field->columnIndex;
                break;
            }
        }
        if( $columnIndex===FALSE || !isset($this->{$columnIndex}) ) return "";
        else
        {
            if( !$commonDescriptionField ) 
            {
                loadSQL( $commonDescriptionField=new ItemField, "SELECT * FROM @customfield WHERE isCommon=1 AND columnIndex='description'" );
            }
            // a displayLength-en nem az egyes kategoriak description mezoinek displayLenght-je hatarozza meg,
            // hanem az amit a common description fieldben van:
            $this->applyDisplayLengthLimit( $this->{$columnIndex}, $commonDescriptionField->displaylength );
            if( $encoding && !$field->allowHtml ) 
            {
                return htmlspecialchars($this->{$columnIndex});
            }
            else return $this->{$columnIndex};
        }
    }
    else return "";
}

function getKeywords()
{
    $columnIndex = FALSE;
    if( $fields = $this->getFields() )
    {
        foreach( $fields as $field ) 
        {
            if( $field->seo==customfield_keywords )
            {
                $columnIndex = $field->columnIndex;
                break;
            }
        }
        if( $columnIndex===FALSE || !isset($this->{$columnIndex}) ) return "";
        return $this->{$columnIndex};
    }
    else return "";
}

function getPicture()
{
    $columnIndex = FALSE;
    if( $fields = $this->getFields() )
    {
        foreach( $fields as $field ) 
        {
            if( $field->mainPicture )
            {
                $columnIndex = $field->columnIndex;
                break;
            }
        }
        if( $columnIndex===FALSE || empty($this->{$columnIndex}) ) return "";
        $thName = AD_PIC_DIR . "/th_$this->id"."_".substr($columnIndex, 4).".".$this->{$columnIndex};
        if( file_exists($thName) ) return $thName;
    }
    return "";
}

function getPageTitle()
{
    global $gorumroll;
    
    if( $this->pageTitle ) return $this->pageTitle;
    // CustomList eseteben:
    elseif( $gorumroll->list=="item_search" && $gorumroll->rollid )
    {
        $ret = mysql_fetch_array(executeQuery("SELECT listTitle FROM @search WHERE id=#id#", $gorumroll->rollid), MYSQL_ASSOC);
        return $ret["listTitle"];
    }
    return $this->getTitle(FALSE);
}

function getPageDescription()
{
    if( $this->pageDescription ) return $this->pageDescription;
    return $this->getDescription(FALSE);
}

function getPageKeywords()
{
    if( $this->pageKeywords ) return $this->pageKeywords;
    elseif( !empty($this->cid) ) return $this->getKeywords(FALSE);
}

function showHtmlList($elementName="", $cacheManager=0)
{
    global $gorumroll;
    
    // ez beallitja $this->select-et es vegrehajtja a setupCustomListAppearance-t ha szukseges:
    $this->getListSelect(FALSE, $elementName);
    // ha egy kategoria itemjei:
    if( $gorumroll->list=="item"  ) $this->setupCategorySpecificList();
    parent::showHtmlList($elementName, $cacheManager);
}

function setupCategorySpecificList( $cid=0 )
{
    global $gorumroll, $lll;

    $this->cid = $cid ? $cid : $gorumroll->rollid;
    $this->activateVariableFields();
    G::load($c, $this->cid, "appcategory");
    // Category specifikus ad list title beallitasa:
    if( $c->customAdListTitle ) $lll["item_ttitle"]=$c->getAttr("customAdListTitle");
    $this->immediateAppear = $c->immediateAppear;
}

// hogy ne csak a cronjob hivhassa oket, hanem admin is:
function checkExpiration()
{
    hasAdminRights($isAdm);
    if( $isAdm ) $count = checkExpiration();
    Roll::setInfoText("$count expiration warning emails have been sent out.");
    $this->nextAction =& new AppController("/");
}
function deleteExpiredAds()
{
    hasAdminRights($isAdm);
    if( $isAdm ) $count = deleteExpiredAds();
    Roll::setInfoText("$count expired ads have been deleted.");
    $this->nextAction =& new AppController("/");
}

function showDetailsTool()
{
    return "";
}

function getCacheTimeFrameAndCategorySpecificity()
{
    global $gorumroll;
    
    $timeFrame = $categorySpecific = 0;
    if( $gorumroll->list=="item_search" && $gorumroll->rollid>2 /* My ads */ )
    {
        // lekerdezzuk a custom list 'cache' mezejet:
        if( $result = executeQuery(array("SELECT * FROM @search WHERE id=#id#", $gorumroll->rollid)) )
        {
            $row=mysql_fetch_array($result, MYSQL_ASSOC);
            $timeFrame = $row["cache"];
            $categorySpecific = $row["categorySpecific"];
            CustomList::getSortingSql($row["primarySort"], $row["primaryDir"], $row["primaryPersistent"], $row["secondarySort"], $row["secondaryDir"], $row["secondaryPersistent"]);
        }     
    }
    return array($timeFrame, $categorySpecific);
}

} // class

function checkExpiration()
{
    global $noahsHost, $noahsVersionCheckScript;
    CustomField::addCustomColumns("item");
    $settings = & new Settings;
    $timeBeforeExp = Date::add($settings->expNoticeBefore, Date_Day);
    $query = "SELECT a.*, c.name as cName, a.expirationTime, email ".
             "FROM @item AS a, @user AS u, @category AS c WHERE ".
             "a.expirationTime!=0 AND a.expEmailSent=0 AND a.ownerId=u.id AND a.status=1 AND ".
             "a.expirationTime<'".$timeBeforeExp->getDbFormat()."' AND c.id=a.cid";
    G::load( $ads, $query );
    G::load($n, Notification_adExpired, "notification");
    if( $n->active ) 
    {
        foreach( $ads as $ad )
        {
            $ctrl =& new AppController("item/$ad->id");
            $title=$ctrl->generAnchor($ad->getTitle(), "", TRUE, "", FALSE);  // absolute
            $n->send( $ad->email, round($ad->expirationTime->getDayDiff()), $ad->cName, $title );
            executeQuery("UPDATE @item SET expEmailSent=1 WHERE id=$ad->id");
        }
    }
    $globalStat = new GlobalStat;
    if( !$globalStat->reg ) 
    {
        $globalStat->reg = md5(uniqid(rand(), true));
        modify($globalStat);
    }
    $ck = new CheckConf();
    $data = $ck->getTransferData($globalStat);
    $ck->getVersionInfo($noahsHost, "POST", $noahsVersionCheckScript, $data);
    return count($ads);
}

function deleteExpiredAds()
{
    CustomField::addCustomColumns("item");
    $query = "SELECT a.*, c.name as cName, a.expirationTime, email ".
             "FROM @item AS a, @user AS u, @category AS c WHERE ".
             "a.expirationTime!=0 AND a.ownerId=u.id AND a.status=1 AND ".
             "a.expirationTime<NOW() AND c.id=a.cid";
    G::load( $ads, $query );
    G::load($n, Notification_adDeleted, "notification");
    foreach( $ads as $ad )
    {
        if( $n->active ) 
        {
            $ctrl =& new AppController("item/$ad->id");
            $title=$ctrl->generAnchor($ad->getTitle(), "", TRUE, "", FALSE);  // absolute
            $n->send( $ad->email, $ad->cName, $title );
        }
        // azert TRUE-val,  mert nem akarjuk, hogy a delete is kuldjon egy mailt:
        $ad->delete("","cronjob");
    }
    return count($ads);
}


?>
