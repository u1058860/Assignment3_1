<?php
defined('_NOAH') or die('Restricted access');
include(NOAH_APP . "/item_detailspresentation.php");
include(NOAH_APP . "/staticpage.php");
?>
