<?php
// lang_de_php 22.11.2008
// German translation: JOOM!WEB Webservice Olaf Dryja 
// Email: info@joomweb.de
// Website: http://joomweb.de

// Content begins:

// Added in 3.1.3:
$lll["category_showDescription"]="Display description";
$lll["category_showDescription_expl"]="There may be cases when you don't want to display the description of a category, but still want that the DESCRIPTION meta tag of the category listing page is populated.";
$lll["category_inactivateOnModify"]="Inactivate on modify";
$lll["category_inactivateOnModify_expl"]="Whether an approved ad becomes pending again if the owner of the ad modifies it.";
$lll["clonecat_create_form"]="Clone category";
$lll["clonecat_amount"]="Number of clones";
$lll["clonecat_amount_expl"]="Creating many clones - especially if you clone the sub categories and pictures, too - can take quite a long time and you should not close the browser during that!";
$lll["clonecat_name"]="Clone with name";
$lll["clonecat_name_expl"]="If you are creating more than one clones, you can apply numbering in their names if you insert '%d' here. E.g. 'Cars-%d' will result in the following clones: Cars-1, Cars2, Cars-3, etc.";
$lll["clonecat_recursive"]="Clone sub categories, too";
$lll["clonecat_withPictures"]="Clone the category pictures, too";
$lll["categoriesCloned"]="The categories have been successfully cloned.";


// Added in 3.1.2:
$lll["commonFieldAlreadyExists"]="A common field with this name and type already exists. Please, choose an other name!";


// Added in 3.1.0:
$lll["checkUpdatesDescription"]="Check out if a newer version of Noah's Classifieds has been released. You can even perform the update immediately, or download the update package with a single click!";
$lll["checkconfDescription"]="Click here any time to verify if the program has been set up correctly. In case of any problems being detected, the Check page gives useful hints how to solve them.";
$lll["rssDescription"]="Set up the properties of the RSS feed the program generates.";
$lll["settings_langDir_expl"]="If you enable more languages - some with left to right direction and some with right to left, you should rather specify the direction in the lang file itself! E.g. if you have an Arabian language file, you can put a line like this in it, in order to override this setting in case of the Arabian language:<br><br>$langDir='rtl';<br><br>Use 'rtl' for 'right to left' and 'ltr' for 'left to right'!";
$lll["customfield_default_multiple_expl"]="This must be a comma separated list of possible values. E.g. one,two,three";
$lll["customfield_values_expl"]="This must be a comma separated list of possible values. E.g. one,two,three";
$lll["itemfield_ttitle_global"]="Common custom fields";
$lll["searchable_0"]="none";
$lll["searchable_1"]="all";
$lll["customlist_displayedFor_1"]="all";
$lll["searchable_2"]="logged in users only";
$lll["customlist_displayedFor_2"]="logged in users only";
$lll["searchable_4"]="admin only";
$lll["customlist_displayedFor_4"]="admin only";
$lll["customfield_isCommon"]="Scope of the field";
$lll["customfield_isCommon_colhead"]="Scope";
$lll["common"]="Common";
$lll["unique"]="Unique";
$lll["customfield_isCommon_expl"]="If you set the scope to common, the field will exist in every categories. E.g.: if you have a web shop, whatever categories you set up, a 'Price' field must probably belong to all of them, so the 'Price' is best to define as a common field. If you create a common field, or change a unique field to common, it will suddenly appear in all categories - not just there where you created it. If you delete a common field, it will dissappear from all the categories at once.<br><br>Even if a field is common, it can be differently set up in different categories. E.g. you can set it to appear on the ad details page in one category, but hide it in an other category. Only the 'Name' and the 'Type' properties have to be really equal in all categories.<br><br>You can even set up your classifieds program so that all the fields are common! In some cases, it can make a good sense: e.g. if you have cars and only cars in every categories, probably all the categories have just the same list of custom fileds. The strength of the common fields will really show up in defining custom ad lists! E.g. the 'Recent ads' list can contain ads from many different categories, but if you have common fields, you need not be restricted to show only the 'Title', 'Description', and 'Category' columns in the list any more - you can choose any common field to be a column in the list!";
$lll["customfield_isCommon_0"]="Unique to this category";
$lll["customfield_isCommon_1"]="Common to all the categories";
$lll["userfield_create_completed"]="The custom field has been successfully created.";
$lll["itemfield_create_completed"]="The custom field has been successfully created.";
$lll["itemfield_columnIndex"]="Column index";
$lll["NotificationsDescription"]="Manage the list of notifications here - the emails the program sends out automatically on certain actions.";
$lll["category_restartExpOnModify"]="Restart expiration on modify";
$lll["category_restartExpOnModify_expl"]="You can use this as an alternative of the ad prolonging. If checked and the owner modifies his or her ad (and admin approves it if moderation has been enabled), the ad expiration will start again.";
$lll["controlPanel"]="Control panel";
$lll["controlpanel_ttitle"]="";
$lll["customlist_ttitle"]="Custom lists";
$lll["customlist"]="Custom list";
$lll["customlist_listTitle"]="Title";
$lll["customlist_listDescription"]="Description";
$lll["customlist_listDescription_expl"]="Some notes that can better describe what this custom list is all about. Only visible for admin.";
$lll["customlist_create_form"]="Create custom list";
$lll["customlist_modify_form"]="Modify custom list";
$lll["customlist_newitem"]="Add new custom list";
$lll["checkCustomLists"]="Whenever you delete a custom field, check all the custom lists where a search condition has been supplied by clicking on their Title, because they may become invalid if they referred to the just deleted custom field in their condition!";
$lll["listDisplayProperties"]="List display properties";
$lll["customlist_primarySort"]="Primary sort by";
$lll["customlist_primaryDir"]="Primary sort direction";
$lll["customlist_secondaryDir_DESC"]="Descending";
$lll["customlist_primaryDir_DESC"]="Descending";
$lll["customlist_secondaryDir_ASC"]="Ascending";
$lll["customlist_primaryDir_ASC"]="Ascending";
$lll["customlist_primaryPersistent"]="Primary sort is persistent";
$lll["customlist_primaryPersistent_expl"]="If you leave this unchecked, the users can override the initial sorting of the list by clicking on the sorting icons in the list column headers. If you check this, however, you can force specific ads to always appear say on the top of the list however the users sort the list.<br><br>E.g. if you have a custom field called 'Sponsoring level' with values say 'Gold', 'Silver', 'Bronze' and 'None', you can create a custom list with a persistent sorting by 'Sponsoring level' descending. The Gold ads will always appear on the top of the list then and the non-sponsored ads on the bottom of the list.";
$lll["customlist_secondarySort"]="Secondary sort by";
$lll["customlist_secondaryDir"]="Secondary sort direction";
$lll["customlist_secondaryPersistent"]="Secondary sort is persistent";
$lll["customlist_limit"]="Limit";
// Changed in version 3.1.2. Old text:
//$lll["customlist_limit_expl"]="You can limit the number of ads the list contains. Leave it blank for no limit. E.g. 10 means, the list will display only the first 10 ads in the given sorting order from all the matching ads.";
// New text:
$lll["customlist_limit_expl"]="You can limit the number of ads the list contains. Leave it blank for no limit. E.g. 10 means, the list will display only the first 10 ads in the given sorting order from all the matching ads. If you display this list as a scrollable widget, it is always a good idea to set a reasonable, not too high limit, so that the pages with widgets load faster and have less resource consumption both on the cient and on the server side!";
$lll["customlist_columns"]="Select columns to display";
$lll["customlist_columns_expl"]="If you select more than one, you can re-arrange them by drag-and-drop! 
The columns will be displayed in the order you specify here.<br><br>
So that a column is really displayed in a list, note that it is not enough that you add it here! 
The user who displays the list must have also permission to see that column! 
The visibility of a column can be set from two places depending on the scope of the given field:<br><br>
&nbsp;&nbsp;1. If you want to set the visibility of a column that is in a non-category specific list, 
you can do it from the 'Common custom fields' list (open the modify form and edit the 'Show in lists for' property),<br><br>
&nbsp;&nbsp;2. If you want to set the visibility of a column that is in a category specific list, 
you can do it from the 'List of custom fields of this category' list (open the modify form and edit the 'Show in lists for' property)";
$lll["customlist_displayedFor"]="Display list for";
$lll["customlist_displayedFor_expl"]="Whatever you select here, admin will always be able to view the list by clicking on its Title in the 'List of custom lists'!";
$lll["customlist_pages"]="Display on these pages";
$lll["customlist_pages_expl"]="You can specify a page with its link. E.g. '/item/1' is the details page of ad with ID 1. Use '/' to denote the start page. You can list more pages - one in every line. You can use the '*' wildcard to match more than one pages - e.g.: '/list/*' means all the category listing pages, '/item/*' means all the ad details pages. You can exclude pages by adding the '!' prefix. A more complex example: <br><br>/user/login_form<br>/item/create_form<br>/list/*<br>!/list/1<br>!/list/2<br>/item/4<br>/item/5<br><br>The above says \"display the list on the login page, on the ad submit page, on every category listing pages except of the category with ID 1 and 2, and on the details pages of ads with ID 4 and 5!\"<br><br>This feature doesn't work in the free version!";
$lll["customlist_categorySpecific"]="Content depends on the current category";
// Changed in version 3.1.2. Old text:
//$lll["customlist_categorySpecific_expl"]="If you check this and the custom list is just displayed on a page that is in a \"categy context\" (e.g. on a category listing page or ad details page), the custom list will only include the ads of the given category. This is usefulfif you have a custom list called say 'Featured list' and you want to make this list to be context sensitive - so that when a user is just under the Cars category, it displays the featured cars and when the user is just under the 'Dating' category, it contains the featured dating ads.";
// New text:
$lll["customlist_categorySpecific_expl"]="If you check this and the custom list is just displayed on a page that is in a \"category context\" (e.g. on a category listing page or ad details page), the custom list will only include the ads of the given category. <br><br>This is useful if you have a custom list called say 'Featured list' and you want to make this list to be context sensitive - so that when a user is just under the Cars category, it displays the featured cars and when the user is just under the 'Dating' category, it contains the featured dating ads.";
$lll["customlist_recursive"]="and includes ads from the current category AND any of its subcategories";
$lll["customlist_listStyle"]="List style";
$lll["customlist_listStyle_0"]="Normal list";
$lll["customlist_listStyle_1"]="Scrollable widget";
$lll["customlist_listStyle_expl"]="Visit the demo installation http://noahsclassifieds.org/v8rss/ to see how the 'Scrollable widget' style looks like!";
$lll["customlist_positionScrollable"]="Position";
$lll["customlist_positionNormal"]="Position";
$lll["customlist_positionScrollable_expl"]="The place where the list appears on the page";
$lll["customlist_positionNormal_expl"]="The place where the list appears on the page";
$lll["customlist_positionScrollable_0"]="Above the content";
$lll["customlist_positionNormal_0"]="Above the content";
$lll["customlist_positionScrollable_1"]="Below the content";
$lll["customlist_positionNormal_1"]="Below the content";
$lll["customlist_positionScrollable_4"]="On the left side of the page";
$lll["customlist_positionScrollable_5"]="On the right side of the page";
$lll["customlist_positionScrollable_2"]="On the top of the page";
$lll["customlist_positionScrollable_3"]="On the bottom of the page";
$lll["customlist_displayInMenu"]="Assign menu point in menu";
$lll["customlist_displayInMenu_expl"]="If you don't want that the list is displayed on some of the existing pages, you can assign a menu point to it, so that the users access the list on its separate page. E.g.: the good old 'Recent ads', 'Popular ads', 'Pending ads' and 'Approved ads' menu points are from now on just links to the corresponding custom lists!";
$lll["customlist_displayInMenu_0"]="None";
$lll["customlist_displayInMenu_1"]="Login menu";
$lll["customlist_displayInMenu_2"]="User menu";
$lll["customlist_displayInMenu_3"]="Admin menu";
$lll["customlist_displayInMenu_4"]="Category menu";
$lll["randomOrder"]="-- Random order --";
$lll["noDefaultSort"]="-- No sorting --";
$lll["selectField"]="-- Select field --";
$lll["currentUser"]="-- Current user --";
$lll["customlist_ownerName_expl"]="If you select 'Current user', the list will always only contain the ads of the currently logged in user. E.g. this has been used in the setup of the 'My ads' custom list!";
$lll["customlist_loop"]="Loop ads";
$lll["customlist_loop_expl"]="Whether scrolling starts over when last item is exceeded";
$lll["customlist_autoScroll"]="Auto scroll in every (seconds)";
$lll["customlist_autoScroll_expl"]="Use 0 to disable auto scroll";
$lll["customlist_cache"]="Cache list content and renew the cache in every (minutes)";
$lll["customlist_cache_expl"]="So that pages that display custom lists can be faster, it is possible to cache the content of the list on the server. Use 0 to disable caching!";


// Installation:
$lll["mysql_found"]="MySQL wurde gefunden.";
$lll["need_pw"]="MySQL benötigt ein Benutzer Passwort %s.";
$lll["incorr_pw"]="Das MySQL Passwort für %s ist nicht korrekt.";
$lll["mysql_not_found"]="MySQL wurde nicht gefunden! Bitte passen Sie die Parameter entsprechend Ihrer MySQL Konfiguration an!";
$lll["db_installed"]="Die Datenbank wurde installiert: %s";
$lll["cantcreatedb"]="Die Datenbank kann nicht erreicht oder erstellt werden. Der Benutzer %s hat keine Berechtigung zum erstellen einer Datenbank oder kann diese nicht erreichen. Ändern Sie Ihre Eingaben für den Namen oder ändern Sie die Benutzer-Rechte!";
$lll["cantconnectdb"]="Kann die Datenbank nicht erreichen. Entweder Sie existiert nicht oder Sie haben keine Rechte dafür. Erstellen Sie erst bitte diese Datenbank.";
$lll["inst_create_table_err"]="Fehler! Es konnten keine Tabellen erstellt werden, %s ist bereits installiert?";
$lll["db_created"]="Die Datenbank %s wurde erstellt.";
$lll["tables_installed"]="Die Datenbank Tabellen wurden installiert.";
$lll["fill_table_err"]="Fehler! Es konnten keine Einträge in die Tabellen geschrieben werden.";
$lll["tables_filled"]="Die Datenbank Tabellen wurden mit den Grunddaten ausgefüllt.";
$lll["inst_click"]="Klicken Sie hier für den Zugang zu %s.";
$lll["createTableFailed"]="Tabellen-Erstellung fehlerhaft";
$lll["install"]="Installieren";
$lll["clickToInstall"]="Klicken Sie auf 'Installieren' für die Installation von %s!";
$lll["admin_ok"]="Der Administrator Benutzer wurde erstellt, der Benutzername ist: admin, das Passwort lautet: admin.";
$lll["create_file_ok"]="Die Konfiguration wurde erfolgreich erstellt.";
$lll["create_file_nok"]="Die Konfigurationsdatei muss manuell erstellt werden.";
$lll["inst_params"]="Die MySQL Datenbank wurde mit folgenden Parametern erstellt:";
$lll["edit_params"]="Parameter bearbeiten";
$lll["acceptTerms"] = "Ich habe die Bedingungen gelesen und akzeptiere diese: <input type='checkbox' id='accept' name='Akzeptieren'>";
$lll["youMustAcceptTerms"] = "Sie müssen die Bedingungen erst akzeptieren um weiter machen zu können!";
$lll["dbHostName"]=$lll["hostName"]="Hostname";
$lll["mysqluser"]="MySQL Benutzername";
$lll["dbDbName"]=$lll["dbName"]="Datenbankname";
$lll["dbSocket"]="Sockel";
$lll["formtitle"]="MySQL Einstellungen";
$lll["password"]="PassworT";
$lll["dbPort"]="Port";
$lll["cookieok"]="Cookies sind aktiviert.";
$lll["cookienok"]="Aktivieren Sie Cookies und starten Sie den Installationsprozess erneut!";
$lll["conf_file_write_err"]="Kann die Konfigurationsdatei nicht zum schreiben öffen";
$lll["compare_conf"]="Erstellen Sie eine Datei 'config.php' mit Ihrem bevorzugten Editor in dem Verzeichnis 'app' Ihrer Grunddateien. Kopieren Sie den folgenden Code in die Datei! Beachten Sie bitte, dass Sie keinen Zeilenumbruch nach dem letzten Eintrag machen!";
$lll["afterwrconf"]="<u>Nach dem</u> schreiben der Konfigurationsdatei klicken Sie auf den Link zum fortsetzen!";
$lll["move_inst_file"]="Bitte löschen Sie die Datei install.php aus Ihrem Grundverzeichnis!";
$lll["inst_ch_pw"]="Die Administrator Einstellungen - Benutzername: admin, Passwort: admin, und vergessen Sie nicht das Passwort unbedingt zu ändern!";
$lll["create_file_nok_ext"]="Der Server hat keine Rechte zum erstellen einer Konfigurationsdatei. Sie haben zwei Möglichkeiten:<br>\n#1: Erstellen Sie eine leere Datei im Verzeichnis 'app' mit dem Namen 'config.php', und geben den Server die Schreibrechte für diese Datei. Unter Unix Systemen:<br> die Datei app/config.php auswählen;Chmod 777 für die Datei app/config.php wählen<br>und klicken Sie im Browser auf neu laden bzw. aktualisieren.<br>#2: Sie klicken auf Installieren und erstellen die '/app/config.php' manuell mit Ihrem bevorzugten Editor als leere Datei und kopieren die Code Ausgabe der Installation in diese Datei.";
// Changed in version 3.1.3. Old text:
//$lll["versionTooLow"]="Required minimum MySql version is %s. The current one is %s. Required minimum MySql version is %s. The current one is %s.";
// New text:
$lll["versionTooLow"]="Required minimum MySql version is %s. The current one is %s. Required minimum Php version is %s. The current one is %s.";
// Registrierung:
$lll["registerNoah"]="Registrieren";
$lll["notRegistered"]="Nicht registriert"; 
$lll["registerNoahTitle"]="Registrieren von Noah's Kleinanzeigen"; 
$lll["noahAlreadyRegistered"]="Das Produkt wurde bereits installiert!"; 
$lll["noahRegistrationFalseResponse"]="Die Registrierdaten konnten nicht an den Noah's Server gesendet werden. Bitte versuchen Sie es später wieder!"; 
$lll["noahRegistrationSuccessfull"]="Vielen Dank. Das Produkt ist nun registriert!"; 
// Aktualisierung:
$lll["download"]="Download";
$lll["u_maintitle"]="Noah's Kleinanzeigen Aktualisierungs-Prozess";
$lll["secure_copy"]="Es wird empfohlen vor dem Aktualisieren eine Sicherung der alten Version einschließlich der Datenbank anzulegen.<br>Kopieren Sie dazu die Programm Dateien in einen separaten Ordner und erstellen Sie eine Datenbank Sicherung!<br>Klicken Sie auf 'OK' zu fortfahren des Aktualisierungs-Prozesses oder brechen Sie diesen Prozess erst einmal ab!";
$lll["ready_to_update"]="Sind Sie bereit zum aktualisieren der Datenbank %s zur Version %s?<br>";
$lll["invalid_version"]="Die angegebene Version ist ungültig: %s";
$lll["updateSuccessful"]="Die Aktualisierung ist komplett abgeschlossen.<br>Tipp: Als Administrator, klicken Sie im Menü auf 'Überprüfen', um den Status von Kleinanzeigen zu analysieren!";
$lll["updating"]="Aktualisierung von Version %s zu Version %s...";
$lll["already_installed"]="Die letzte Software Version %s ist bereits installiert.";
$lll["picturesDirMustbeWritable"]="Die '%s' Verzeichnisse müssen durch das Programm beschreibbar sein damit eine Aktualisierung durchgeführt werden kann! Aktualisierung fehlerhaft.";
$lll["updateAutomatic"]="Aktualisierung";
$lll["updateManualZip"]="Download ZIP";
$lll["updateManualTgz"]="Download TGZ";
$lll["downloadFileNotExists"]="Download Datei '%s' existiert nicht.";
$lll["updateFailed"]="Aktualisierung fehlerhaft, das Programm besitzt keine Rechte zum Schreiben in dem Programmverzeichnis.";
$lll["currentVersionIs"]="Die derzeitige Version ist: %s";
$lll["latestVersionIs"]="Die neuste Version ist: %s";
$lll["noNeedToUpdate"]="Es ist keine Aktualisierung nötig.";
$lll["checkUpdates"]="Aktualisierungen"; 
$lll["checkUpdatesTitle"]="Überprüfe die Noah's Kleinanzeigen Webseite auf vorhandene Aktualisierungen"; 
$lll["nopermission"]="Das Programm hat keine Schreibrechte für folgende Verzeichnisse: %s<br>Sie müssen folgende Unix Kommandos ausführen (In Unix Systemen natürlich):<br><i>chmod 777 &lt;Verzeichnisname ersetzen&gt;</i>";
$lll["nopermission_expl"]="Während der Ausführung hat Noah's Kleinanzeigen Dateien in verschiedenen Unterverzeichnissen gespeichert, in der Reihenfolge zum hoch laden von Bildern, Log Fehler oder Erstellung von Dateien. Stellen Sie sicher, dass das Programm entsprechende Rechte dazu hat.)";
$lll["backToIndex"]="Zurück zu den Kleinanzeigen.";
$lll["onlyFrom1.3"]="Sie haben eine Version die älter als 1.3 ist. Das Aktualisierungsscript arbeiten nur ab der Version 1.3!";
$lll["cantGetVersionInfo"]="Habe keine Versions Informationen. Die Aktualisierung ist fehlerhaft.";
// Konfiguration überprüfen:
$lll["checkMailtestTitle"]="Absenden einer Test E-Mail..."; 
$lll["triggerMailTest"]="Klicken Sie hier, um eine Test E-Mail abzusenden."; 
$lll["unableToConnectNoah"]="Es gab keinen Kontakt zum Noah's Server. Bitte versuchen Sie es später wieder!"; 
$lll["itemNumbersRecalculated"]="Die Nummern der Inhalte wurden erfolgreich neu erstellt"; 
$lll["dbPrefixExplanation"]="Für die Installation von Noah's Kleinanzeigen ist es erforderlich, wenn diese Anwendung auf eine Datenbank mit anderen Anwendungen installiert werden soll, den Datenbank Präfix entsprechend zu verändern. z.B.: 'noah_'";
$lll["dbPrefix"]="Tabellen Präfix";
$lll["checkconf"]="Überprüfen";
$lll["mailok"]="Eine Test E-Mail wurde erfolgreich versendet. Sie müssten bald eine Test E-Mail %s";
$lll["mailerr"]="Der folgende Fehler ist während der Absendung aufgetreten:<br>%s";
$lll["here1"]="Klicken Sie hier";
$lll["confpreerr"]="Es gibt einige Zeichen vor &lt;? in der Konfigurationsdatei! Bitte löschen Sie diese Zeichen (Zeilenumbrüche und Leerzeichen)!";
$lll["confposterr"]="Es gibt einige Zeichen nach ?&gt; Konfigurationsdatei! Bitte löschen Sie diese Zeichen (Zeilenumbrüche und Leerzeichen)!";
$lll["conffileok"]="Die Konfigurationsdatei schein in Ordnung zu sein.";
$lll["congrat"]="Gratulation! Sie haben erfolgreich die Installation von Noah's Kleinanzeigen abgeschlossen!";
$lll["confcheck"]="System Konfiguration überprüfen...";
$lll["confdisapp"]="Wenn Sie zu Beginn der Arbeit mit der Software wünschen, dass diese Seite verschwindet";
$lll["confclicheck"]="Sie können diese Konfigurations - Überprüfungsseite jederzeit über den Link 'Überprüfen' im Menü aufrufen.";
$lll["chadmemail"]="Ihre derzeitige E-Mail Adresse ist  admin@admin.admin. Bitte geben Sie hier eine korrekte Adresse unter dem Link 'Mein Profil' im Menü an!";
$lll["chsyspass"]="Ihre System E-Mail Adresse wurde noch nicht eingegeben. Bitte geben Sie hier eine korrekte Adresse unter dem Link 'Einstellungen' im Menü an!";
$lll["chsyspass_expl"]="Das Programm kann keine Benachrichtigungs E-Mail versenden ohne einer gültigen System E-Mail Adresse und den ausgefüllten Feldern 'Von' und 'Antwort zu' der Benachrichtungs E-Mail.";
$lll["chadmpass"]="Das Standard Passwort des Administrators ist nicht verändert worden! Bitte klicken Sie dazu auf 'Mein Profil' im Menü um das zu ändern!";
$lll["settings_adminEmail"]="System E-Mail";
$lll["settings_adminEmail_expl"]="Diese wird vom Programm in das E-Mail Feld 'Von:' eingetragen. Wenn Sie diese Feld leer lassen, kann das Programm keine Benachrichtigungs E-Mail versenden!";
$lll["nogd"]="Warnung: Ihre Server hat keine GD Bibliothek installiert.";
$lll["nogd_expl"]="(Diese Bibliothek wird zur Veränderung von Bilddateien benötigt, so kann es also Sinnvoll sein diese auf den Server zu installieren. Ihr Programm ermöglicht die Miniaturbilderstellung von Originalbildern. Ohne die Programmunterstützung können keine Miniaturbilder erstellt werden, da dann auf diesen Weg der Browser 'on-the-fly' die Bilder schrumpfen muss, was viel Zeit in Anspruch nimmt. Diese Methode arbeitet, aber ist bei weitem nicht so wirksam, weil immer große Bilder geladen werden müssen. )";
$lll["instFileRemove"]="Um das Programm zu starten müssen Sie die Installationsdatei entfernen (%s).<br><a href='%s'>Klicken Sie hier um den Inhalt zu entfernen!</a><span class='confexpl'> (Falls diese Nachricht nach dem anklicken nicht verschwindet, hat das Programm keine Berechtigung Dateien zu entfernen. In diesem Fall müssen Sie die Datei manuell entfernen!)</span>";
$lll["appFileRemoveExpl"]="Von Version 2.3.0, werde die meisten php Dateien im Installationsverzeichnis durch eine 'htaccess' Datei vor dem Zugriff in den Unterverzeichnissen geschützt.
                           Das Root-Verzeichnis beinhaltet nur die 'index.php' und 'initdir.php'.";
$lll["appFileRemove"]="Wenn Sie das Programm starten möchten, löschen Sie unnötige Dateien aus dem Installation Verzeichnis: <span class='confexpl'>%s.</span><br><br><a href='%s'>Klicken Sie hier zum entfernen!</a><span class='confexpl'> (Falls diese Nachricht nach dem anklicken nicht verschwindet, hat das Programm keine Berechtigung Dateien zu entfernen. In diesem Fall müssen Sie die Datei manuell entfernen!)</span>";
$lll["backupFileRemoveExpl"]="Aus Gründen der Sicherheit, sollten die Sicherung Verzeichnisse, die durch die automatische Aktualisierung angelegt werden, müssen gelöscht werden. Sollten Sie diese noch benötigen, speichern Sie diese in einem anderen Verzeichnis Ihres Web-Root's!";
$lll["backupFileRemove"]="Wenn Sie das Programm starten möchten, löschen Sie folgende Sicherungs Verzeichnisse aus Ihrem Root-Verzeichnis: <span class='confexpl'>%s.</span><br><br><a href='%s'>Klicken Sie hier zum entfernen!</a><span class='confexpl'> (Falls diese Nachricht nach dem anklicken nicht verschwindet, hat das Programm keine Berechtigung Dateien zu entfernen. In diesem Fall müssen Sie die Datei manuell entfernen!)</span>";
$lll["systemConfCheck"]="System Konfiguration wurde erfolgreich geprüft...";
$lll["niceURLFeature"]="Suchmaschinefreundliche URL's:";
$lll["niceURLFeature_1"]="Noah's Kleinanzeigen unterstützt suchmaschinenfreundliche URL's. Dies bedeutet zum Beispiel, dass der Link von einer Anzeigen-Info-Seite wie folgt aussehen kann:";
$lll["niceURLFeature_2"]="statt der aktuellen Lösung:";
$lll["niceURLFeature_3"]="Neben dem Effekt das die URL schöner aussieht ist Sie auch Suchmaschinenfreundlicher.";
$lll["niceURLFeature_4"]="Die suchmaschinenfreundlichen URL's arbeiten mit dem Apache Modul %s, dieses muss installiert und aktiviert sein. Konnte nicht erkenn od diese Modul installiert ist (PHP ist wahrscheinlich als CGI installiert).";
$lll["niceURLFeature_5"]="Wenn %s bereits installiert ist, sollte Sie eine Datei im Installationsverzeichnis mit dem Namen %s und setzen Sie den folgen Text ein, um suchmaschinenfreundlich URL's zu erhalten:";
$lll["niceURLFeature_6"]="Wenn danach die suchmaschinenfreundlichen URL's noch immer nicht funktionieren, sollte Sie in der Apache Konfiguration Datei nachschauen:";
$lll["niceURLFeature_7"]="%s ob das Schreiben auf den Kleinanzeigen Web-Root Verzeichnis erlaubt ist,";
$lll["niceURLFeature_8"]="%s ob es für den Kleinanzeigen Web-Root aktiviert ist,";
$lll["niceURLFeature_9"]="Die suchmaschinenfreundlichen URL's funktionieren nur mit dem Apache Modul %s. Dies muss installiert und aktiviert sein. es ist nicht korrekt installiert oder aktiviert.";
// Produkt Registrierung:
$lll["reg_companyName"]="Firmenname";
$lll["reg_firstName"]="Vorname";
$lll["reg_lastName"]="Nachname";
$lll["reg_email"]="E-Mail";
$lll["reg_submit"]="Absenden";
// RSS feed:
$lll["rss"]="RSS";
$lll["rss_modify_form"]="RSS Feed bearbeiten";
$lll["rss_language"]="Sprache";
$lll["rss_link"]="Link";
$lll["rss_link_expl"]="Die URL von der Kleinanzeigen Seite ist - z.B.: http://yoursete.com/classifieds";
$lll["rss_descField"]="Beschreibung";
$lll["rss_descField_expl"]="Der Index für das variablen Feld, dient als Beschreibung für den RSS Feed. In der Standard Kleinanzeigen Installation, ist dies das erste Feld. Falls Sie noch nicht über ein solches Feld verfügen, setzen Sie dies auf '0', es werden keine Beschreibungen zu den Anzeigen in den RSS Feed übernommen.";
//Globale Einstellungen
$lll["settings"]="Einstellungen";
$lll["settings_modify_form"]="Einstellungen bearbeiten";
$lll["settings_expNoticeBefore"]="Anzahl der Tage, ab wann der Benutzer über den Ablauf seiner Anzeige informiert werden soll";
$lll["settings_charLimit"]="Anzahl der Zeichen die ein Beitrag enthalten darf";
$lll["settings_charLimit_expl"]="'0' ist ohne jedes Limit.";
$lll["settings_blockSize"]="Anzahl der Anzeigen pro Seite";
$lll["settings_maxPicSize"]="Maximale Bildgröße in Pixel";
$lll["settings_maxPicWidth"]="Maximale Bildbreite in Pixel";
$lll["settings_maxPicHeight"]="Maximale Bildhöhe in Pixel";
$lll["settings_maxPicSize_expl"]=$lll["settings_maxPicWidth_expl"]=$lll["settings_maxPicHeight_expl"]="'0' ist ohne jedes Limit.";
$lll["settings_adminFromName"]="Systemname";
$lll["settings_adminFromName_expl"]="Dieser Name wird in dem 'Von:' Feld der Programm E-Mail Benachrichtigung eingetragen.";
$lll["settings_versionFooter"]="Versionshinweis";
$lll["settings_titlePrefix"]="Titel Präfix"; 
$lll["settings_dateFormat"]="Datum umformatieren"; 
$lll["settings_dateFormat_expl"]="Für weitere Informationen zu den Datumsformaten finden Sie unter, <a href='http://php.net/manual/en/function.date.php' target='_blank'>PHP NET - Datumsfunktionen</a>"; 
$lll["settings_enableFavorities"]="Aktivieren von 'Zu den Favoriten hinzufügen' Features für"; 
$lll["settings_enableFavorities_expl"]="Diese Einstellungen hat keine Auswirkung auf die Evaluation Version"; 
$lll["settings_updateCheckInterval"]="Überprüfung auf Noah's Aktualisierungs-Perioden"; 
$lll["settings_updateCheckInterval_expl"]="Das Programm überprüft automatisch nach neuen Aktualisierungen und 
                                              zeigt dies auf der Aktualisierungsseite des Administrators. Legen Sie hier die Einstellungen für den Aktualisierungszyklus fest.
                                              Wenn Sie dieses Feature deaktivieren wollen setzen Sie den Wert auf 0!"; 
$lll["mailProperties"]="E-Mail Eigenschaften"; 
$lll["themeProperties"]="Themen Unterstützung"; 
$lll["settings_defaultTheme"]="Standard Thema"; 
$lll["settings_allowedThemes"]="Erlaubt das auswählen von Themen"; 
$lll["settings_allowedThemes_expl"]="Wenn Sie ein neues Unterverzeichnis erstellen unter 'themes', für Ihre eigen Themen - z.B. 'mein_neues_thema', erfolgt automatisch ein neuer Eintrag in der Themenliste 'Mein neues Thema'!"; 
$lll["settings_allowSelectTheme"]="Benutzer können Themen verändern"; 
$lll["settings_allowSelectTheme_expl"]="Wenn dieses aktiviert ist, wird ein Drop-Down Auswahl-Menü auf der Seite angezeigt, zum ändern des Seiten Themas."; 
$lll["languageProperties"]="Sprachunterstützung"; 
$lll["settings_defaultLanguage"]="Standardsprache"; 
$lll["settings_allowedLanguages"]="Auswahl von Sprachen erlauben"; 
$lll["settings_allowSelectLanguage"]="Benutzer können die Sprache ändern"; 
$lll["settings_allowSelectLanguage_expl"]="Wenn dieses aktiviert ist, wird ein Drop-Down Auswahl-Menü auf der Seite angezeigt, zum ändern der Seiten Sprache."; 
$lll["settings_smtpServer"]="SMTP Servername"; 
$lll["settings_smtpServer_expl"]="Verwenden Sie diese Felder, wenn Sie wollen, dass das Programm die Benachrichtigungs-E-Mails über einen SMTP-Server sendet. Andernfalls, wird die PHP-Mail-Funktion verwendet."; 
$lll["settings_smtpUser"]="SMTP Benutzername"; 
$lll["settings_smtpPass"]="SMTP Passwort"; 
$lll["settings_fallBackNative"]="Gehen Sie zurück zum nativen E-Mail Dienst falls SMTP nicht funktioniert"; 
$lll["settings_titlePrefix_expl"]="Dieser Text wird vor jedem Titel in der Titelleiste des Browsers angezeigt. z.B.: Geben sie den Namen der Webseite ein."; 
$lll["seoProperties"]="Suchmaschinen Optimierung"; 
$lll["settings_mainTitle"]="Titel Tag"; 
$lll["settings_mainTitle_expl"]="Der Inhalt des TITELS, der BESCHREIBUNG und der KENNWÖRTER hängt in der Regel mit der Kategorie Liste oder 
                                 der angezeigten Anzeigenseite zusammen, dass heißt Sie können die nach Kategorie und Benutzer 
                                 sowie angezeigte Anzeige definieren. Diese drei Felder, enthalten die Standardwerte, wenn die Seiten 
                                 nicht in einer Kategorie sind oder Kontext stehen (.B. wie die Startseite selbst)"; 
$lll["settings_mainDescription"]="Meta Tag Beschreibung"; 
$lll["settings_mainKeywords"]="Meta Tag Kennwörter"; 
$lll["settings_helpLink"]="'Hilfe' Link Ziel";
$lll["settings_helpLink_expl"]="Die volle URL zur Hilfe. Mit dieser Eingabe können Sie eine benutzerdefinierte Hilfeseite aufrufen. z.B.: http://yoursite/classifieds_dir/customhelp.html";
$lll["settings_maxMediaSize"]="Maximale Dateigröße für Medien Dateien zum hoch laden";
$lll["settings_maxMediaSize_expl"]="'0' ist ohne ein Limit.<br><br>Anmerkung: Jedoch gibt es hier zwei Einstellungen für die maximale Größe zum hochladen von Dateien. Einmal 'upload_max_filesize' und 'post_max_size'. Sie kann entweder in der 'php.ini'-Datei, oder in der 'httpd.conf', oder in der '. htaccess' -Datei pro Verzeichnis eingestellt werden. Der Standardwert beträgt 2MB. Sie können die Werte in der 'htaccess' Datei bis 50MB, mit :<br><br>php_value upload_max_filesize \"50M\"<br>php_value post_max_size \"50M\" festlegen. ";
$lll["settings_subscriptionType"]="Aktiveren der automatischen Benachrichtigung für";
$lll["settings_subscriptionType_expl"]="Benutzer können sich anmelden für eine automatische Benachrichtigungen, wenn neue Anzeigen in einer Kategorie der Wahl eingestellt werden.<br><br>Diese Feature ist nicht in der Evaluation Version vorhanden!";
$lll["settings_menuPoints_expl"]="Wenn 'Anzeige absenden' nicht markiert ist, ist der Menüpunkt nur für den Administrator sichtbar (Nur der Administrator kann Anzeigen absenden). Sie können dies auch deaktivieren oder reorganisieren, in dem Sie einfach den entsprechenden Bereich in der 'layout.tpl.php' verschieben oder entfernen!";
$lll["settings_menuPoints"]="Menüpunkte";
$lll["settings_menuPoints_".Settings_showLogout]="Abmelden";
$lll["settings_menuPoints_".Settings_showLogin]="Anmelden";
$lll["settings_menuPoints_".Settings_showRegister]=$lll["registerNoah"];
$lll["settings_menuPoints_".Settings_showMyProfile]="Mein Profil anzeigen";
$lll["settings_menuPoints_".Settings_showMyAds]="Meine Anzeigen";
$lll["settings_menuPoints_".Settings_showSubmitAd]="Anzeige absenden";
$lll["settings_menuPoints_".Settings_showRecentAds]="Neue Anzeige";
$lll["settings_menuPoints_".Settings_showMostPopularAds]="Populäre Anzeigen";
$lll["settings_menuPoints_".Settings_showSearch]="Suche";
$lll["settings_menuPoints_".Settings_showHome]="Startseite";
$lll["settings_menuPoints_".Settings_displayHelp]="Hilfe";
$lll["menuPointsSep"]="Layout-Anpassung";
$lll["expirationProperties"]="Ablauf Eigenschaften";
$lll["imageProperties"]="Beschränkung für das Bilder hoch laden";
$lll["otherProperties"]="Andere Einstellungen";
$lll["adDisplayProperties"]="Anzeigen Anzeige-Einstellungen";
$lll["settings_renewal"]="Anzahl der Verlängerungen von Benutzer Anzeigen oder abgelaufen Anzeigen";
$lll["settings_allowModify"]="Der Benutzer darf seine Anzeigen verändern";
$lll["settings_extraHead"]="Zusätzliche HEAD Inhalte";
$lll["settings_extraHead_expl"]="Mit diesem, können Sie benutzerdefinierte HTML-Rechte vor dem schließenden HEAD-Tag der Seiten hinzufügen. Dies ist normalerweise ein guter Platz, um zusätzliche Style-Sheets oder JavaScript einzubinden. <br> <br> Diese Funktion ist nicht verfügbar in der Free-Version des Programms!";
$lll["settings_extraBody"]="Zusätzliche BODY Inhalte";
$lll["settings_extraBody_expl"]="Mit diesem, können Sie benutzerdefinierte HTML-Rechte vor dem schließenden BODY-Tag der Seiten hinzufügen. z.B. Sie können Banner in alle Seiten einfügen.<br><br>Diese Funktion ist nicht verfügbar in der Free-Version des Programms!";
$lll["settings_extraTopContent"]="Zusätzlicher Inhalt Oben";
$lll["settings_extraTopContent_expl"]="Mit diesem, können Sie benutzerdefinierte HTML-Rechte unter dem Kopf-Bereich der Seiten (Statusleiste, Menüs)einfügen.<br><br>Diese Funktion ist nicht verfügbar in der Free-Version des Programms!";
$lll["settings_extraBottomContent"]="Zusätzlicher Inhalt Unten";
$lll["settings_extraBottomContent_expl"]="Mit diesem, können Sie benutzerdefinierte HTML-Rechte über der Powered by Fußzeile der Seiten hinzufügen.<br><br>Diese Funktion ist nicht verfügbar in der Free-Version des Programms!";
$lll["settings_extraFooter"]="Zusätzlicher Inhalt im Fussbereich";
$lll["settings_extraFooter_expl"]="Mit diesem, können Sie benutzerdefinierte HTML-Rechte vor dem schließenden BODY-Tag der Seiten einfügen.<br><br>Diese Funktion ist nicht verfügbar in der Free-Version des Programms!";
$lll["securityProperties"]="Sicherheitseinstellungen";
$lll["settings_applyCaptcha"]="Hinzufügen von Spamschutz (CAPTCHA) in den folgenden Formen";
$lll["settings_applyCaptcha_".Settings_response]="in 'Antworten zu den Beiträgen' und 'E-Mail zu einem Freund senden'";
$lll["settings_applyCaptcha_".Settings_login]="im Anmeldeformular";
$lll["settings_applyCaptcha_".Settings_register]="im Registrierungsformular";
$lll["settings_applyCaptcha_".Settings_submitAd]="in Anzeige einreichen";
$lll["settings_joomlaLink"]="Joomla Webseite";
$lll["settings_joomlaLink_expl"]="Wenn sie die Joomla! Brücke installiert haben, können Sie die URL Ihrer Joomla! Seite hier eingeben. Wenn Sie das tun, wird das Anmeldemenü um einen 'Meine Seite' Menüpunkt erweitert, mit dem Link zur URL.";
$lll["enableUserSearch"]="Benutzersuche aktivieren";
$lll["enableUserSearch_expl"]="Diese Funktion ist nicht verfügbar in der Evalutions-Version des Programms!";
$lll["appsettings_modify_completed"]="Die Einstellungen wurden erfolgreich bearbeitet.";
$lll["settings_langDir"]="Sprach-Ausrichtung";
$lll["settings_langDir_ltr"]="Links nach rechts";
$lll["settings_langDir_rtl"]="Rechts nach links";
// Benutzerdefinierte Felder
$lll["customfield"]="Benuzerdefiniertes Feld";
$lll["customfield_fixInfoText"]="Dies ist ein \ 'fix\'-Feld, was bedeutet, dass Sie es nicht löschen können sondern man kann nur einige der Eigenschaften ändern.";
$lll["mustBeCommaSeparated"]="Die möglichen Werte des Auswahl Feldes müssen ausgefüllt werden. Definieren sie dies durch Komma getrennte Zeichenketten";
$lll["invalidDefaultValue"]="Der Standardwert des Auswahl Feldes muss durch ein Komma getrennte Zeichenkette, in der Wert Feld Liste eingetragen werden.";
$lll["descriptionDefaultLabel"]=$lll["description"]="Beschreibung";
$lll["privateField"]="Privat";
$lll["customfield_type"."_".customfield_text]="Text";
$lll["customfield_type"."_".customfield_textarea]="Textbereich";
$lll["customfield_type"."_".customfield_bool]="Boolean";
$lll["customfield_type"."_".customfield_selection]="Auswahl";
$lll["customfield_type"."_".customfield_multipleselection]="Mehrfach Auswahl";
$lll["customfield_type"."_".customfield_separator]="Trenner";
$lll["customfield_type"."_".customfield_checkbox]="Auswahlkästchen";
$lll["customfield_type"."_".customfield_picture]="Bilder";
$lll["customfield_type"."_".customfield_media]="Medien Dateien";
$lll["customfield_type"."_".customfield_url]="Web Link";
$lll["customfield_type"."_".customfield_date]="Datum";
$lll["customfield_dateDefaultNow"]="Standard Datum ist der heutige Tag";
$lll["customfield_fromyear"]="Von Jahr";
$lll["customfield_fromyear_expl"]="Der Bereich der Datumsauswahl beginnend mit diesem Jahr. 
                                   Geben Sie die Aktuelle Jahreszahl ein z.B. '1971', oder geben Sie 'now' ein als Stand von dem aktuellen Jahr.
                                   Sie können auch ein relatives Jahr eingeben: 'now-5' dann entspricht dies dem jetzigen Zeitpunkt vor 5 Jahren!";
$lll["customfield_toyear"]="Zu Jahr";
$lll["customfield_toyear_expl"]="Der bereich der Datumsauswahl endend mit einem bestimmten Jahr.
                                   Geben Sie die Aktuelle Jahreszahl ein z.B. '2010', der geben Sie 'now' ein als Stand von dem aktuellen Jahr.
                                   Sie können auch ein relatives Jahr eingeben: 'now+5' dann entspricht dies dem jetzigen Zeitpunkt in 5 Jahren!";
$lll["customfield_name"]="Name";
$lll["selectUserField"]="-- Benutzerfeld Auswahl --";
$lll["customfield_userField"]="oder wählen Sie die Benutzerfelder";
$lll["customfield_userField_expl"]="Statt der Schaffung eines völlig neuen benutzerdefiniertes Feld, können sie auch den Namen eines Benutzers Feldes angeben. Dieser Weg, den Bereichen des Inhabers eines Anzeige auszuwählen, kann entweder direkt in der Anzeigen-Liste oder auf der Anzeigen-Info-Seite angezeigt werden. <br><br>E.g. you can add the phone number of the owner of the ad to the ad details page. Or if you have a custom 'Zip code' user field, you can display it, too. Moreover, if you specify the Zip code as 'Searchable', users will be able to search for ads by zip code!";
$lll["userField"]="Benutzerfeld";
$lll["customfield_type"]="Typ";
$lll["customfield_default_bool"]=
$lll["customfield_default_text"]=
$lll["customfield_default_multiple"]="Standard Wert";
$lll["customfield_active"]="Aktiv";
$lll["customfield_separator"]="Spalte %s";
$lll["customfield_mandatory"]="Pflichtfeld";
$lll["customfield_checkboxCols"]="Anzahl der Spalten, für das Kontrollkästchen";
$lll["customfield_showInList"]="Anzeigen in der Liste für";
$lll["customfield_values"]="Mögliche Werte";
$lll["customfield_innewline"]="Platz in neuer Zeile";
$lll["customfield_displayLabel"]="Ettiketten anzeigen";
$lll["customfield_displayLabel_expl"]="Wenn diese Option ausgeschaltet ist, wird die Feldbezeichnung nicht angezeigt, in der Anzeigen-Info-Seite und dem Feld Wert wird sich über die Etiketten der anderen Felder legen.";
$lll["userfield_displayLabel_expl"]="Wenn diese Option ausgeschaltet ist, wird die Feldbezeichnung nicht angezeigt, in der Benutzer-Detail-Seite und dem Feld Wert wird sich über die Etiketten der anderen Felder legen.";
$lll["customfield_displaylength"]="Angezeigte Listen Länge";
$lll["customfield_displaylength"."_expl"]="Die maximale Anzahl von Zeichen in einer Liste. Das Erscheinungsbild der Liste, kann gegen die Anzeige sehr lange Felder in einer Zelle geschützt werden.";
$lll["userfield_displaylength"."_expl"]="Die maximale Anzahl von Zeichen die angezeigt wird in der Benutzer-Detail-Liste. Das Erscheinungsbild der Liste, kann gegen die Anzeige sehr lange Felder in einer Zelle geschützt werden.";
// Changed in version 3.1.0. Old text:
//$lll["customfield_searchable"]="Searchable";
// New text:
$lll["customfield_searchable"]="Show in the search form for";
$lll["customfield_searchable"."expl"]="Wenn diese Option aktiviert ist, können Benutzer eine Suche nach diesem Attribut mit einer Reihe von Zahlen wie '10-20' durchführen";
$lll["customfield_rangeSearch"]="Bereichsuche zulassen";
// Changed in version 3.1.0. Old text:
//$lll["customfield_rangeSearch_expl"]="If this is checked than one can define e.g. '10-20' as a search condition to search for ads where the value of this field is between 10 and 20.";
// New text:
$lll["customfield_rangeSearch_expl"]="If this is checked than one can define e.g. '10-20' as a search condition to search for ads where the value of this field is between 10 and 20. Or one can enter a range of dates in case of Date fields.";
$lll["userfield_rangeSearch_expl"]="Wenn dies aktiviert ist können Sie Bereiche definieren, wie z.B. '10-20', als Suchbedingung für die Suche nach Anzeigen, wenn der Wert dieses Feldes zwischen 10 und 20 liegt.";
$lll["customfield_allowHtml"]="Erlaube HTML";
$lll["customfield_allowHtml_expl"]="Dies erlaubt nur 'sichere' HTML Tags! Einige Tags, würden ein Sicherheitsrisiko darstellen, nur das Layout ist ausgeschlossen.";
$lll["customfield_private"]="Privates erlauben";
$lll["customfield_subType"]="Behandeln Sie diese Feld als";
$lll["customfield_subType_expl"]="z.B. wenn Sie ein 'Preis' Feld haben, ist es ratsam eine 'Dezimal Zahl' einzusetzen, so dass die Sortierung in der Preis-Spalte und Reihe eine Suche nach dem Preis Feld richtig erfolgt und arbeitet. Sie können dann das erforderlichen Währungssymbol, die Nachkommawerte und das Tausende Trennzeichen in der 'Anzeige Formatierung' einstellen.";
$lll["userfield_subType_expl"]="";
$lll["customfield_subType_".customfield_alnum]="Text";
$lll["customfield_subType_".customfield_integer]="Integer Zahl";
$lll["customfield_subType_".customfield_float]="Dezimal Zahl";
$lll["customfield_sortable"]="Ermöglicht die Sortierung des Feldes";
$lll["customfield_expl"]="Erläuterungstext";
$lll["customfield_expl"."_expl"]="Hilfe Text wie Sie gerade einen lesen! Eine ausführlichere Beschreibung für ein Formularfeld.";
$lll["private_field"]="(Privates)";
$lll["itemfield_ttitle"]="Benutzerdefinierte Felder der Kategorie '%s'";
$lll["customfield_newitem"]="Neues benutzerdefiniertes Feld hinzufügen";
$lll["customfield_modify_form"]="Benutzerdefiniertes Feld bearbeiten";
$lll["customfield_create_form"]="Benutzerdefiniertes Feld erstellen";
$lll["customfield_sortId"]="Sortierung";
$lll["customfield_sorthelp"]="Benutze die Pfeilsortierung in der Spalte 'Sortierung' um die Reihenfolge der Liste zu ändern. Anschließend klicken Sie auf 'Sortierung speichern' am Ende!";
$lll["customfield_savesorting"]="Sortierung speichern";
$lll["customfield_advanced_form"]="Erweiterte Optionen";
$lll["customfield_sortingsaved"]="Das neue benutzerdefinierte Feld wurde erfolgreich gespeichert.";
$lll["customFields"]="Liste der benutzerdefinierten Felder";
$lll["customfield_rowspan"]="Zeilen Einstellung";
$lll["customfield_seo"]=$lll["seoProperties"];
$lll["customfield_seo_0"]="Keine Zuordnung";
$lll["customfield_seo_".customfield_title]="In diesem Feld wie der TITEL der Info-Seite";
$lll["customfield_seo_".customfield_description]="In diesem Feld wie die BESCHREIBUNG in der Detail Seite";
$lll["customfield_seo_".customfield_keywords]="In diesem Feld wie die KENNWORTER in der Detail Seite";
$lll["customfield_mainPicture"]="Verwenden Sie dieses Feld für wichtige Bilder";
$lll["customfield_mainPicture_expl"]="Verwenden Sie dieses Bild nicht in den Kategorie spezifischen listen und RSS Feeds.";
$lll["userfield_mainPicture_expl"]=" ";
$lll["customfield_seo_expl"]="Sie können hier die benutzerdefinierten Felder als Teil des Inhaltes dem HTML TITEL Tag, der BESCHREIBUNGS Tags und des KENNWORT Tags hinzufügen, bzw. 
                              bei SEO, den Inhalt des TITEL Feldes in der Titelleiste des Browsers erscheinen lassen, wenn die Anzeige angezeigt wird, aber 
                              es wird nicht benutzt um den Titel der Anzeige in den Kategorie spezifischen Listen und in RSS Feeds anzuzeigen.";
$lll["userfield_seo_expl"]="Sie können hier die benutzerdefinierten Felder  der Benutze als Teil des Inhaltes dem HTML TITEL Tag, der BESCHREIBUNGS Tags und des KENNWORT Tags hinzufügen, bzw."; 
$lll["customfield_innewline_expl"]="Statt der Bildung einer neuen Spalte, ermöglicht diese Einstellung, den benutzerdefinierte Feld Wert in einer neuen Zeile, die sich dann über alle anderen Spalten horizontal befindet und darunter.";
$lll["customfield_rowspan_expl"]="Verwenden Sie diese in Verbindung mit dem 'Platz in neue Zeile' als Eigentum von anderen benutzerdefinierten Feldern. Wenn es andere Felder gibt, werden diese in eine neue Zeile gelegt, so können Sie mit dieser Einstellung erreichen, dass dieses Feld vertikal in einer neuen Zeile liegt.";
$lll["customfield_detailsPosition"]="Position";
$lll["customfield_detailsPosition_expl"]="Die Platzierung der Felder auf den Anzeigen-Details-Seiten. Die 'Seitenleiste' ist der richtige Bereich vom Detail-Bereich, wo die Bilder liegen (in der modernen Thema). Mit dieser Einstellung können Sie die Felder über den Bilder Bereich, oder unter diesen legen.";
$lll["userfield_detailsPosition_expl"]="Die Platzierung der Felder auf den Benutzer-Details-Seiten. Die 'Seitenleiste' ist der richtige Bereich vom Detail-Bereich, wo die Bilder liegen (in der modernen Thema). Mit dieser Einstellung können Sie die Felder über den Bilder Bereich, oder unter diesen legen..";
$lll["customfield_detailsPosition_".customfield_normal]="Normal";
$lll["customfield_detailsPosition_".customfield_topright]="Oben in der Seitenleiste";
$lll["customfield_detailsPosition_".customfield_bottomright]="Unten in der Seitenleiste";
$lll["formProperties"]="Formular Einstellungen";
$lll["listProperties"]="Listen-Einstellungen";
$lll["detailsProperties"]="Einstellungen der Detailseite";
$lll["searchProperties"]="Such Einstellungen";
$lll["miscProperties"]="Verschiedene Einstellungen";
$lll["customfield_showInForm"]="Zeige Formulare für";
$lll["userfield_showInForm_expl"]="Beachten Sie, dass im Falle der Festsetzung der Benutzer Felder, hat diese Einstellung nur eine begrenzte Bedeutung! Z.B. Wenn Sie das Feld 'Name' nehmen, das angezeigt werden soll nur für den Administrator, so bezieht es sich nur auf den Benutzer im geänderten Formular (d.h. Sie können nicht das Feld 'Name' verbergen in der Registrierung und im Anmelde-Formular). Ebenso können Sie nicht das 'Email' Feld aus dem Anmeldeformular ausblenden.";
$lll["customfield_showInDetails"]="Anzeigen für";
$lll["enableUserSearch_".customfield_forNone]=$lll["showInForm_".customfield_forNone]=$lll["showInList_".customfield_forNone]=$lll["showInDetails_".customfield_forNone]=$lll["enableFavorities_".customfield_forNone]=$lll["subscriptionType_".customfield_forNone]="nichts";
$lll["enableUserSearch_".customfield_forAll]=$lll["showInForm_".customfield_forAll]=$lll["showInList_".customfield_forAll]=$lll["showInDetails_".customfield_forAll]=$lll["enableFavorities_".customfield_forAll]=$lll["subscriptionType_".customfield_forAll]="alle";
$lll["enableUserSearch_".customfield_forLoggedin]=$lll["showInForm_".customfield_forLoggedin]=$lll["showInList_".customfield_forLoggedin]=$lll["showInDetails_".customfield_forLoggedin]=$lll["subscriptionType_".customfield_forLoggedin]=$lll["enableFavorities_".customfield_forLoggedin]="nur für angemeldete Benutzer";
$lll["showInForm_".customfield_forOwner]=$lll["showInList_".customfield_forOwner]=$lll["showInDetails_".customfield_forOwner]="Nur für die Inhaber der Anzeige";
$lll["enableUserSearch_".customfield_forAdmin]=$lll["showInForm_".customfield_forAdmin]=$lll["showInList_".customfield_forAdmin]=$lll["showInDetails_".customfield_forAdmin]=$lll["subscriptionType_".customfield_forAdmin]=$lll["enableFavorities_".customfield_forAdmin]="nur der Administrator";
$lll["enableFavorities_".customfield_forAllButAdmin]=$lll["subscriptionType_".customfield_forAllButAdmin]="alle ohne Administrator";
$lll["formatSection"]="Anzeige Formatierungen";
$lll["customfield_formatPrefix"]="Präfix";
$lll["customfield_formatPrefix_expl"]="Typische Beispiele sind ein Währung Symbol, Zeichen oder Prozentsatz. Alles, was Sie hier eingeben, wird vor den Werten dieses benutzerdefiniertes Feld genutzt.";
$lll["customfield_formatPostfix"]="Postfix";
$lll["customfield_formatPostfix_expl"]="z.B. Sie können Einheiten auf die Zahlen hier festlegen. Alles, was Sie hier eingeben, werden die Werte dieses benutzerdefinierten Feldes.";
$lll["customfield_precision"]="Dezimalstellen";
$lll["customfield_precision_expl"]="Fließpunkt für das Dezimalzeichen - legen sie anzahl der Detimalstellen nach dem Punkt fest.";
$lll["customfield_precisionSeparator"]="Dezimalpunkt Trennzeichen";
$lll["customfield_precisionSeparator_expl"]="Legen Sie das Trennzeichen für den Dezimalpunkt fest";
$lll["customfield_thousandsSeparator"]="Tausender Trennzeichen";
$lll["customfield_format"]="Anzeige Format";
$lll["customfield_format_expl"]="Fortgeschrittene Benutzer können eine C-Stil sprintf Format-String anlegen.";
$lll["customfield_useMarkitup"]="Verwenden Sie den eingebetteten HTML-Editor statt eines einfachen Textbereiches";
// Benutzerdefinierte Felder der Benutzer:
$lll["userfield_ttitle"]="Benutzerdefiniertes Feld der Benutzer";
$lll["userfield_type"."_expl"] = "";
// Benachrichtigungen:
$lll["notification"]="Benachrichtigung";
$lll["Notifications"]=$lll["notification_ttitle"]="Benachrichtigungen";
$lll["notification_subject"]="E-Mail Betreff";
$lll["notification_body"]="E-Mail Textbereich";
$lll["notification_variables"]="Variablen erlauben";
$lll["notification_active"]="Aktiv";
$lll["notification_modify_form"]="Benachrichtigung bearbeiten";
$lll["notif_remindpass_tit"]="Enthält ein neues Passwort, wenn der Benutzer sein altes vergessen hat.";
$lll["notif_remindpass_subj"]="Neues Passwort";
$lll["notif_initpass_tit"]="Sendet nach der Registrierung dem Benutzer das erste Passwort";
$lll["notif_initpass_subj"]="Erstes-Passwort";
$lll["notification_cc"]="an";
$lll["notification_cc_expl"]="Geben Sie hier die E-Mail-Adresse ein, an wen die Meldung als Kopie gesendet werden soll.";
$lll["notification_active_expl"]="Sie können hier das Versenden der Benachrichtung ein- und ausschalten.";
//Kategorie:
$lll["category_expirationEnabled"]="Ablaufzeit aktivieren";
$lll["category_expirationOverride"]="Erlaube die Ablaufzeit zu überschreiben für";
$lll["category_allowSubmitAdAdmin"]="Nur der Administrator kann Anzeigen zur Kategorie hinzufügen";
$lll["category_expirationOverride_expl"]="Wenn Sie das Feld 'Anzahl der Tage bevor die Anzeige abläuft' aktivieren kann der Inhaber im Erstellen/Bearbeiten Formular eine Anzahl eingeben. Wenn Sie '0' in das Feld eingeben, ist dass für bliebige viele Tage. Wenn Sie aber spezifisch größer als '0' eingeben, dies der Standard und es ist die maximale Anzahl, die der Inhaber der Anzeige eingeben kann.";
$lll["category_expirationOverride_".customfield_forNone]="Nichts";
$lll["category_expirationOverride_".customfield_forLoggedin]="Alle Benutzer";
$lll["category_expirationOverride_".customfield_forAdmin]="Nur für Administrator";
$lll["category_organize"]="Kategorien Organisieren";
$lll["methods"]="Methode";
$lll["clone"]="Kopiere";
$lll["exp"]="Verfallstag";
$lll["useDragAndDrop"]="Verwenden Sie Drag-and-Drop zum reorganisieren der Kategorien und klicken Sie dann auf 'Speichern'!";
$lll["organizeSaveButton"]="Reihenfolge speichern";
$lll["organizeSaveMessage"]="Die Kategorie-Reihenfolge wurde erfolgreich gespeichert.";
$lll["organizeSaveError"]="Konnte nicht die Daten zum Server senden.";
$lll["organizeLoadError"]="Konnte nicht die Daten vom Server laden.";
$lll["copyOfCategory"]="Kopiere in '%s'";
$lll["organizeNextPageDrop"]="Wenn Sie hier mit der Maus über die Kategorie ziehen, kommen Sie in die nächste Seite.";
$lll["organizePreviousPageDrop"]="Wenn Sie hier mit der Maus über die Kategorie ziehen, kommen Sie in die vorhergehende Seite.";
$lll["organizeNextItems"]="Nächste Kategorien &raquo;";
$lll["organizePreviousItems"]="&laquo; Vorangegangenen Kategorien";
// Felder Set:
$lll["fieldset_create_form"]="Erweiterte Möglichkeiten von den benutzerdefinierten Feldern dieser Kategorie (arbeitet nicht in der freien Version!)";
$lll["fieldset_deleteAll"]="Lösche alle Felder";
// Changed in version 3.1.0. Old text:
//$lll["fieldset_deleteAll_expl"]="This will delete all the non-fix custom fields of this category at once.<br><br>Please note that deleting custom fields causes data loss, because the corresponding ad field values will be deleted, too!";
// New text:
$lll["fieldset_deleteAll_expl"]="This will delete all the unique custom fields of this category at once.<br><br>Please note that deleting custom fields causes data loss, because the corresponding ad field values will be deleted, too!";
$lll["fieldset_cloneToSubcats"]="Kopiere in Unterkategorien";
$lll["fieldset_cloneToSubcats_expl"]="Diese Liste der benutzerdefinierten Felder ist in jeder der Unterkategorien von dieser Kategorie.<br><br>Bitte beachten Sie, dass wenn die Unterkategorien bereits benutzerdefinierte Felder haben, diese zuerst gelöscht werden! Also, diese Operationen sind vor allem nützlich, für die Einrichtung neuer Kategorien, aber es kann auch zu Datenverlust führen in den bereits vorhandenen Kategorien mit Anzeigen.";
$lll["fieldset_cloneToCats"]="Kopiere in Kategorien";
$lll["fieldset_cloneToCats_expl"]="Diese Liste der benutzerdefinierten Felder ist in jeder Kategorie, sie könne diese rechts auswählen (Mehrfachauswahl ist möglich!).<br><br>Bitte beachten Sie, dass wenn die Unterkategorien bereits benutzerdefinierte Felder haben, diese zuerst gelöscht werden! Also, diese Operationen sind vor allem nützlich, für die Einrichtung neuer Kategorien, aber es kann auch zu Datenverlust führen in den bereits vorhandenen Kategorien mit Anzeigen.";
$lll["fieldset_cloneFromCat"]="Kopie von der Kategorie";
$lll["fieldset_cloneFromCat_expl"]="Das ist das Gegenteil der vorangegangenen Operation: es wird alle bestehenden benutzerdefinierten Felder dieser Kategorie mit den benutzerdefinierten Feldern der Listen einer andere Kategorie ersetzen. Das gleiche trifft hier zu, es kann zu Datenverlust führen von bereits existierenden Kategorien mit Anzeigen!<br><br>Nur, um es völlig klar zu sagen: keine der Kopien ist tatsächlich die Kopie der Anzeigen oder Anzeigen-Werte! Und um die Kategorien nicht zu kopieren machen Sie entweder, eine Kopie der Feldlisten mit all den Eigenschaften, dann ist eine Verlagerung der Anzeigen in eine andere Kategorie auf der Grundlage von 'Verschieben' der Anzeigen in der Ansicht möglich. Wenn Sie möchten, erstellen Sie Duplikate von ganzen Gruppen (mit all ihren benutzerdefinierte Felder, aber ohne ihre Anzeigen und Unter-Kategorien!), Sie können die 'Kopier'-Funktion im Rahmen des Menüpunktes 'Kategorien Organisieren' durchführen.";
$lll["fieldset_deleteAll_successful"]="Das benutzerdefinierte Feld wurde erfolgreich gelöscht";
$lll["fieldset_cloneToSubcats_successful"]="Die benutzerdefinierten Felder wurden erfolgreich in Unterkategorien kopiert";
$lll["fieldset_cloneToCats_successful"]="Die benutzerdefinierten Felder wurden erfolgreich in die ausgewählten Kategorien kopiert";
$lll["fieldset_cloneFromCat_successful"]="Die benutzerdefinierten Felder der ausgewählten Kategorie wurden erfolgreich hier her kopiert.";
?>
