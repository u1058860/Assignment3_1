<?php
// Translation rate: 58%
// (100% means fully translated, 0% means not translated at all)

// If you edit this file, save it in UTF-8 character encoding! 
// Most text editors allow you to select the character encoding you use - even notepad.
// Saving in UTF-8 is important for Noah's Classifieds to be able to display special characters correctly.

// If you make a new translation (or make fixes in an existing one)and want to share 
// your work with other people, too, send us the language file and we will include it 
// in the next release of Noah's.

// You can read more more about the internationalization in the Noah's documentation under:
// http://www.noahsclassifieds.org/documentation/translation

// Content begins:

// Added in 3.1.3:
$lll["cantRegisterUntilLoggedIn"]="You can't register yourself while you are logged in.";


// Added in 3.1.0:
$lll["item_creationtime"]="Created";
$lll["allowedLanguages_ar"]="Arabic";
$lll["defaultLanguage_ar"]="Arabic";
$lll["listNotFound"]="The requested ad list has not been found";
$lll["categorySearch"]="Category search";
$lll["search_cid_expl"]="If you select a category, the page will be refreshed and the custom fields of the given category will be displayed in the search form, too.";
$lll["hasUploaded"]=" has been uploaded";
$lll["search_status"]="Status";
$lll["search_status_-1"]="-- Any --";
$lll["search_status_0"]="Inactive";
$lll["search_status_1"]="Active";
$lll["search_ownerId"]="Owner is";
$lll["search_creationtime_from"]="Created after";
$lll["search_creationtime_to"]="Created before";
$lll["search_expirationTime_from"]="Expires after";
$lll["search_expirationTime_to"]="Expires before";
$lll["adminsettDescription"]="Configure all the global parameters of the program here. This is the highest level admin tool - the one you should start the setup of the program with.";
$lll["contentManagementDescription"]="Customize the layout of the program here and insert new content into the pages. Enable and disable menu points.";
$lll["usersDescription"]="Manage the list of users. Modify or delete them, create custom user fields that appear on the profile pages and in the registration form.";
$lll["customLists"]="Custom lists";
$lll["customListsDescription"]="Set up custom advertisement lists that can be used throughout the program. Customize their columns and the places they appear. Create a featured ads list!";
$lll["date_years"]="years";
$lll["date_months"]="months";
$lll["date_days"]="days";
$lll["date_hours"]="hours";
$lll["date_minutes"]="minutes";
$lll["date_seconds"]="seconds";
$lll["date_ago"]="ago";
$lll["date_fromNow"]="from now";
$lll["rssLatestOfUser"]="Latest %s ads of this user";


// Added in 3.0.0:
$lll["allowedLanguages_tk"]="Turkish";
$lll["defaultLanguage_tk"]="Turkish";
$lll["allowedLanguages_br"]="Brazilian Portuguese";
$lll["defaultLanguage_br"]="Brazilian Portuguese";
$lll["allowedLanguages_pl"]="Polish";
$lll["defaultLanguage_pl"]="Polish";
$lll["cannotAcceptCookieFav"]="Your browser can not accept cookies, you can't add ads to the favorities.";
$lll["unmoderated"]="Unmoderated";
$lll["immediateAppear_expl"]="Disabling this field makes the category moderated: admin has to approve new ads before they appear for the public.";
$lll["usersearch_create_form"]="Search for users";
$lll["user_search_ttitle"]="Search Result";
$lll["isAnyOf"]=" is any of";
$lll["contentManagement"]="Content";
$lll["mainSite"]="Main site";


// Added in 2.4.0:
$lll["invalidEmail"]="Please, enter a valid email address!";
$lll["appcategory_expiration_expl"]="0 means that the ads never expire per default. However, if you enable the expiration override below, the owner of the ad may still choose an arbitrary expiration time!";
$lll["item_expiration_expl_1"]="Leave it blank for never expire";
$lll["item_expiration_expl_2"]="%s days is the maximum you can enter!";


// Added in 2.3.0:
$lll["URL"]="URL";
$lll["captchaField"]="Validate the form by entering the following characters";
$lll["invalidCaptcha"]="Invalid code entered";

$lll["allowedLanguages_en"]="English";
$lll["defaultLanguage_en"]="English";
$lll["allowedLanguages_ru"]="Russian";
$lll["defaultLanguage_ru"]="Russian";
$lll["allowedLanguages_ja"]="Japanese";
$lll["defaultLanguage_ja"]="Japanese";
$lll["allowedLanguages_zh"]="Chinese";
$lll["defaultLanguage_zh"]="Chinese";
$lll["allowedLanguages_it"]="Italian";
$lll["defaultLanguage_it"]="Italian";
$lll["allowedLanguages_es"]="Spanish";
$lll["defaultLanguage_es"]="Spanish";
$lll["allowedLanguages_de"]="German";
$lll["defaultLanguage_de"]="German";
$lll["allowedLanguages_fr"]="French";
$lll["defaultLanguage_fr"]="French";
$lll["allowedLanguages_el"]="Greek";
$lll["defaultLanguage_el"]="Greek";
$lll["allowedLanguages_lt"]="Lithuanian";
$lll["defaultLanguage_lt"]="Lithuanian";
$lll["allowedLanguages_nl"]="Dutch";
$lll["defaultLanguage_nl"]="Dutch";
$lll["allowedLanguages_pt"]="Portuguese";
$lll["defaultLanguage_pt"]="Portuguese";
$lll["allowedLanguages_af"]="Afrikaans";
$lll["defaultLanguage_af"]="Afrikaans";
$lll["allowedLanguages_da"]="Danish";
$lll["defaultLanguage_da"]="Danish";
$lll["allowedLanguages_hu"]="Hungarian";
$lll["defaultLanguage_hu"]="Hungarian";
$lll["allowedLanguages_id"]="Indonesian";
$lll["defaultLanguage_id"]="Indonesian";
$lll["allowedLanguages_sv"]="Swedish";
$lll["defaultLanguage_sv"]="Swedish";
$lll["user_name"]="Username";
$lll["user_ttitle"]="Utenti";
$lll["user"]="utente";
$lll["user_newitem"]="Aggiungi nuovo utente";
$lll["email"]="Email";
$lll["user_lastClickTime"]="Ultimo click";
$lll["user_passwordCopy"]="Ripeti password";
$lll["user_create_form"]="Registra";
$lll["user_rememberPassword"]="Ricorda password";
$lll["changePassword"]="Cambia password";
$lll["user_remind_password_form"]="Ricorda password";
$lll["remind_me_pw"]="Ho dimenticato la mia password, inviamene un'altra via email!";
$lll["remind_remind_password_form"]="Ricorda Password";
$lll["remindmail_subj"]="Ricorda Password";
$lll["remindmail_text"]="Il tuo username è: %s
La tua nuova password è: %s
Clicca dul seguente link per attivare la password, quindi prova ad effettuare il Login:
%s

Ti raccomandiamo di cambiare la password successivamente al primo Login.";
$lll["remindmail_sent"]="Un messaggio è stato inviato al tuo indirizzo con la comunicazione della nuova password";
$lll["remind_username"]="Il tuo username";
$lll["invalid_email"]="Indirizzo email non valido! Non ci sono utenti nel sistema con questa email.";
$lll["mistypedPassword"]="Hai digitato erroneamente la tua password.";
$lll["passwordTooShort"]="La misura della password deve essere di minimo %s caratteri.";
$lll["userAllreadyExists"]="L'utente scelto già esiste.";
$lll["cannotAcceptCookie"]="Il tuo browser non accetta i cookies, non puoi effettuare la registrazione.";
$lll["wellcomeNewlyRegistered"]="L'utente %s è stato registrato con successo.";
$lll["greeting"]="Ciao %s!";
$lll["loginInvalid"]="La coppia username e password digitata non è valida.";
$lll["never"]="Mai";
$lll["user_login_form"]="Login";
$lll["user_modify_form"]="Modifica il tuo profilo";
$lll["goodbye"]="Arrivederci %s";
$lll["user_change_password_form"]="Cambia password";
$lll["passwordModified"]="La password è stata modificata con successo.";
$lll["timeoutExpired"]="Tempo scaduto. Effettua il Login!";
$lll["youWillGetAEmailCheckEmail"]="La tua registrazione è stata effettuata. Riceverai tra breve una email con la password iniziale.";
$lll["userAllreadyExistsWithEmail"]="A user already exists with this email.";
$lll["userAllreadyExistsWithName"]="A user already exists with this display name.";
$lll["viewAds"]="Click here to view the ads of this user!";
$lll["viewAdsLink"]="Advertisements";
$lll["categories"]="Categorie";
$lll["appcategory"]="Categoria";
$lll["category_create_form"]="Crea nuova Categoria";
$lll["category_newitem"]="Crea nuova Categoria";
$lll["category_modify_form"]="Modifica Categoria";
$lll["subcats"]="Sottocategorie";
$lll["appcategory_allowAd"]="Consenti annunci";
$lll["appcategory_picture"]="Immagine";
$lll["appcategory_ttitle"]="Categorie Annunci";
$lll["directsubcats"]="Sottocategorie dirette";
$lll["directitemnum"]="Annunci diretti";
$lll["appcategory_keywords"]="Keywords";
$lll["appcategory_keywords_expl"]="Used to populate the KEYWORDS meta tag for SEO";
$lll["customAdListTitle"]="Custom item list title";
$lll["customAdListTitle_expl"]="A category specific text that can appear in the header of the ad list instead of 'Advertisements in this category'";
$lll["expiration"]="Ad expiration in days";
$lll["immediateAppear"]="A new ad appears immediatelly";
$lll["mySubscriptions"]="My subscriptions";
$lll["subscription_my_ttitle"]="My subscriptions";
$lll["catSubscriptions"]="Subscriptions on this category";
$lll["subscription_cat_ttitle"]="Subscriptions on this category";
$lll["subscription"]="subscription";
$lll["subscription_create_form"]="Your email address";
$lll["subscription_userName"]="User";
$lll["subscription_catName"]="Category name";
$lll["autoNotifyCat"]="Notify me when new ads are submitted in this category";
$lll["unsubscribeCat"]="Unsubscribe from this category";
$lll["emailMandatory"]="You must supply your email address";
$lll["subscribed"]="You have successfully subscribed to this category.<br>You will be automatically notified by email when a new ad is submitted here.";
$lll["alreadySubscribed"]="You have already subscribed to this category with this email address.";
$lll["unsubscribed"]="You have successfully unsubscribed";
$lll["items"]="Elementi";
$lll["item"]="elemento";
$lll["item_create_form"]="Crea elemento";
$lll["item_newitem"]="Aggiungi nuovo elemento";
$lll["item_modify_form"]="Modifica elemento";
$lll["title"]="Title";
$lll["item_ttitle"]="Elementi";
$lll["item_my_ttitle_own"]="My Advertisements";
$lll["item_my_ttitle"]="I Miei Annunci";
$lll["item_cName"]="Categoria";
$lll["item_cid"]="Categoria";
$lll["item_clicked"]="Visualizza";
$lll["item_id"]="ID";
$lll["item_responded"]="Risposte";
$lll["item_expirationTime"]="Giorni rimanenti prima della scadenza";
$lll["keepPrivate"]="Nascondi i campi Privati";
$lll["expirationProlonged"]="La data di scadenza e' stata prolungata con successo.";
$lll["prolongExp"]="Prolunga";
$lll["lastRenewal"]="<br>Questo era l'ultimo prolungamento possibile.";
$lll["item_inactive_title"]="Immissioni inattive";
$lll["ad_limit_exc"]="Il limite massimo e' di %s caratteri. Tu hai scritto %s caratteri! Abbrevia il tuo annuncio, grazie!";
$lll["item_active"]="Attivo";
$lll["item_picture"]="Immagine";
// Changed in version 2.4.0. Old text:
//$lll["item_active_ttitle"]="Approved items";
// New text:
//$lll["item_active_ttitle"]="Recent ads";
$lll["item_active_ttitle"]="Recent ads";
$lll["item_inactive_ttitle"]="Annunci in Attesa";
$lll["approve"]="approva";
$lll["adApproved"]="L'annuncio e' stato approvato";
$lll["adScheduled"]="e' in attesa di approvazione. Riceverai una e.mail di notifica.";
$lll["N/A"]="N/A";
$lll["item_popular_ttitle"]="Lista Annunci Popolari";
$lll["noPicture"]="No Picture";
$lll["adNotFound"]="Advertisement not found";
$lll["selectCategory"]="-- Select category --";
$lll["item_status"]="Status";
$lll["item_status_0"]="Inactive";
$lll["item_status_1"]="Active";
$lll["item_ownerId"]="Owner";
$lll["item_ownerName"]="Owner";
$lll["whichPictureAttribute"]=" - %s";
$lll["selectCategoryNecessary"]="You must select a category";
$lll["new_resp"]="Rispondi a questo annuncio";
$lll["response_create_form"]="Rispondi a questo annuncio";
$lll["yourname"]="Il tuo nome";
$lll["youremail"]="La tua Email";
$lll["friendsname"]="Il nome del tuo amico";
$lll["friendsemail"]="La Email del tuo amico";
$lll["response_mess"]="Il tuo messaggio";
$lll["friendmail_mess"]="Il tuo messaggio";
$lll["mail_sent"]="L'annuncio e' stato inviato correttamente.";
$lll["mail_fr_sent"]="Abbiamo inviato l'Email al tuo amico.";
$lll["new_frie"]="Invia annuncio ad un amico";
$lll["friendmail_create_form"]="Invia annuncio ad un amico";
$lll["move"]="move";
$lll["item_move_form"]="Move item into an other category";
$lll["onlyCompatibleExpl"]="You may only move an ad into an other category if its custom fields are \"compatible\" with the custom fields of the category
                              of this ad! This means if its custom fields has the same type and they are in the same order. If you can't see any other categories
                              in the drop down list, it means there are no compatible categories at all and you can't move the ad than.";
$lll["adMoved"]="The ad has been successfully moved into the new category.";
$lll["removeFavorities"]="remove from favorites";
$lll["addFavorities"]="add to favorites";
$lll["favAdded"]="The ad has been added to your favorites.";
$lll["favRemoved"]="The ad has been removed from your favorites.";
$lll["favorities"]="Favorites";
$lll["item_favorities_ttitle"]="My favorites";
$lll["picFileSizeToLarge1"]="Errore! Non posso aprire l'immagine allegata, o l'immagine e' troppo grande.";
$lll["picFileSizeNull"]="L'immagine allegata presenta degli errori.";
$lll["picFileSizeToLarge2"]="L'immagine scelta come allegato supera il massimo consentito di %s byte";
$lll["picFileDimensionToLarge"]="Le dimensioni dell'immagine scelta come allegato superano il massimo consentito di %s x %s";
$lll["notValidImageFile"]="Il file scelto non e' una immagine valida (deve essere gif, jpg, o png).";
$lll["cantOpenFile"]="Errore nell'apertura del file!";
$lll["cantdelfile"]="Alcune immagini caricate potrebbero non essere state cancellate.";
$lll["advancedSearch"]="Ricerca avanzata nella catagoria - cerca annuncio che:";
$lll["search_relationBetweenFields_1"]="tutte le condizioni";
$lll["search_relationBetweenFields_2"]="qualsiasi condizione";
$lll["search_create_form"]="Cerca";
$lll["search_relationBetweenFields"]="Cerca risultati che includono";
$lll["search_cid"]="Categoria";
$lll["allCategories"]="Tutte le categorie";
$lll["item_search_ttitle"]="Risultati della Ricerca";
$lll["contains"]=" contiene";
$lll["is"]=" e'";
// Changed in version 3.1.0. Old text:
//$lll["any"]="Any";
// New text:
$lll["any"]="-- Any --";
$lll["dateRangeSearchExpl"]="You can search for dates between two given date if you supply both the 'after' and 'before' criteria.<br>You can search for all the dates after a specific date if you supply only the 'after' criteria.<br>You can search for all the dates before a specific date if you supply only the 'before' criteria.";
$lll["isAfter"]=" is after";
$lll["isBefore"]=" is before";
$lll["rangeSearchExpl"]="You can also enter a range of numbers here to search for occurances where %s falls in a certain range. E.g. 20-30";
// Changed in version 3.0.0. Old text:
//$lll["search_str"]="Search anywhere in the ads";
// New text:
//$lll["search_str"]="Simple search";
$lll["search_str"]="Simple search";
$lll["search_autoNotify"]="Auto notify";
$lll["clickHere"]="Click here";
$lll["saveSearch"]=" to save this search query for later use!";
$lll["applyAutoNotify"]=" if you want to be notified if a new ad that mathes this search condition will be submitted!";
$lll["viewSavedSearches"]=" to view and manage the list of your saved searches and notifications!";
$lll["searchNameMustBeFilledOut"]="You must supply a unique name for this search.";
$lll["searchNameExists"]="The search name must be unique. You have already defined a search with this name.";
$lll["item_my"]="I miei elementi";
$lll["item_Active"]="Elementi approvati";
$lll["item_Inctive"]="Elementi in sospeso";
$lll["item_recent"]="Elementi aggiunti di recente";
$lll["item_popular"]="Elementi più popolari";
$lll["merchants"]="Merchants";
$lll["category_new"]="Aggiungi nuova categoria";
$lll["category_del"]="Cancella categoria";
$lll["category_mod"]="Modifica categoria";
$lll["home"]="Home";
$lll["my_profile"]="Il Mio Profilo";
$lll["register"]="Registrati!";
$lll["loginDifferrent"]="Effettua Login con altro user";
$lll["login"]="Login";
$lll["logout"]="Logout";
$lll["help"]="Aiuto";
$lll["search"]="Cerca";
$lll["adminsett"]="Impostazioni";
$lll["users"]="Utenti";
$lll["ok"]="Ok";
$lll["cancel"]="Cancella";
$lll["back"]="Indietro";
$lll["quickhelp"]="Aiuto";
$lll["emptyList"]="(Lista vuota)";
$lll["nothingSelected"]="(nessuna selezione)";
$lll["orSelectConcreteTime"]="o seleziona tempo corretto";
$lll["youMustSelectOne"]="Devi selezionare un elemento dalla lista";
$lll["onlyOneCanBeSelected"]="Non puoi selezionare più di un elemento per questa operazione";
$lll["yes"]="Si";
$lll["no"]="No";
$lll["linkText"]="Link text";
$lll["permission_denied"]="Permesso negato";
$lll["operation_cancelled"]="Operazione cancellata";
$lll["create_completed"]="Il tuo nuovo %s è stato creato con successo.";
$lll["modify_completed"]="%s modificato con successo.";
$lll["delete_completed"]="%s cancellata con successo.";
$lll["beforeDelete"]="Vuoi cancellare realmente %s?";
$lll["wrongPasswordToDelete"]="Wrong password! Please, try again!";
$lll["mustBeInt"]="Il campo \"%s\" deve contenere un numero";
$lll["mustBeFloat"]="Il campo \"%s\" deve contenere un numero intero";
$lll["mustBeGreaterInt"]="Il campo \"%s\" uguale o maggiore di %s";
$lll["mustBeSmallerInt"]="Il campo \"%s\" deve essee uguale o minore di %s";
$lll["mustBeString"]="Il campo \"%s\" deve essere una stringa";
$lll["mustBeGreaterString"]="La lunghezza del campo \"%s\" deve essere di almeno %s";
$lll["mandatoryField"]="'%s' è un campo obbligatorio";
$lll["mustBeSmallerString"]="La lunghezza del campo \"%s\" deve essere al massimo di %s";
$lll["invalidDate"]="La data digitata non è valida";
$lll["spacenoatt"]="Il nome del file allegato non può contenere spazi.";
$lll["selectAtLeastOne"]="At least %s item must be selected from the list at %s.";
$lll["icon_desc"]="discendente";
$lll["icon_asc"]="ascendente";
$lll["icon_details"]="dettagli";
$lll["icon_modify"]="modifica";
$lll["icon_delete"]="cancella";
$lll["detail_info"]="Dettagli di %s";
$lll["prev"]="precedente";
$lll["next"]="prossimo";
$lll["first"]="primo";
$lll["last"]="ultimo";
$lll["allowedThemes_classic"]="Classic";
$lll["defaultTheme_classic"]="Classic";
$lll["allowedThemes_modern"]="Modern";
$lll["defaultTheme_modern"]="Modern";
$lll["changeTheme"]="-- Change theme --";
$lll["changeLanguage"]="-- Change language --";
// Changed in version 3.0.0. Old text:
//$lll["creationtime"]="Created";
// New text:
//$lll["creationtime"]="create_completed";
// Changed in version 3.1.0. Old text:
//$lll["creationtime"]="create_completed";
// New text:
$lll["creationtime"]="Created";
$lll["registerOrLoginToSubmit"]="Registrati e fai il login per inviare i tuoi annunci!";
$lll["loggedas"]="Sei entrato come %s.";
$lll["logorreg"]="Registrati o fai il login.";
$lll["name"]="Nome";
$lll["emptylist"]="La lista è vuota";
$lll["popuphelp_tit"]="Finestra Aiuto";
$lll["not_found_in_db"]="Non trovato nel DB.";
$lll["deep_struct"]="Errore nella struttura.";
$lll["no_father"]="Errore nella struttura, non esiste 'padre'.";
$lll["not_found_deleted"]="Elemento non trovato, potrebbe essere stato cancellato dal sistema.";
$lll["rssLatest"]="Latest %s ads";
$lll["rssLatestInCategory"]="Latest %s ads in this category";
$lll["pages"]="pages";
?>