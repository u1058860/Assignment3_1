<?php
// Translation rate: 21%
// (100% means fully translated, 0% means not translated at all)

// If you edit this file, save it in UTF-8 character encoding! 
// Most text editors allow you to select the character encoding you use - even notepad.
// Saving in UTF-8 is important for Noah's Classifieds to be able to display special characters correctly.

// If you make a new translation (or make fixes in an existing one)and want to share 
// your work with other people, too, send us the language file and we will include it 
// in the next release of Noah's.

// You can read more more about the internationalization in the Noah's documentation under:
// http://www.noahsclassifieds.org/documentation/translation

// Content begins:

// Added in 3.1.3:
$lll["category_showDescription"]="Display description";
$lll["category_showDescription_expl"]="There may be cases when you don't want to display the description of a category, but still want that the DESCRIPTION meta tag of the category listing page is populated.";
$lll["category_inactivateOnModify"]="Inactivate on modify";
$lll["category_inactivateOnModify_expl"]="Whether an approved ad becomes pending again if the owner of the ad modifies it.";
$lll["clonecat_create_form"]="Clone category";
$lll["clonecat_amount"]="Number of clones";
$lll["clonecat_amount_expl"]="Creating many clones - especially if you clone the sub categories and pictures, too - can take quite a long time and you should not close the browser during that!";
$lll["clonecat_name"]="Clone with name";
$lll["clonecat_name_expl"]="If you are creating more than one clones, you can apply numbering in their names if you insert '%d' here. E.g. 'Cars-%d' will result in the following clones: Cars-1, Cars2, Cars-3, etc.";
$lll["clonecat_recursive"]="Clone sub categories, too";
$lll["clonecat_withPictures"]="Clone the category pictures, too";
$lll["categoriesCloned"]="The categories have been successfully cloned.";


// Added in 3.1.2:
$lll["commonFieldAlreadyExists"]="A common field with this name and type already exists. Please, choose an other name!";


// Added in 3.1.0:
$lll["checkUpdatesDescription"]="Check out if a newer version of Noah's Classifieds has been released. You can even perform the update immediately, or download the update package with a single click!";
$lll["checkconfDescription"]="Click here any time to verify if the program has been set up correctly. In case of any problems being detected, the Check page gives useful hints how to solve them.";
$lll["rssDescription"]="Set up the properties of the RSS feed the program generates.";
$lll["settings_langDir_expl"]="If you enable more languages - some with left to right direction and some with right to left, you should rather specify the direction in the lang file itself! E.g. if you have an Arabian language file, you can put a line like this in it, in order to override this setting in case of the Arabian language:<br><br>$langDir='rtl';<br><br>Use 'rtl' for 'right to left' and 'ltr' for 'left to right'!";
$lll["customfield_default_multiple_expl"]="This must be a comma separated list of possible values. E.g. one,two,three";
$lll["customfield_values_expl"]="This must be a comma separated list of possible values. E.g. one,two,three";
$lll["itemfield_ttitle_global"]="Common custom fields";
$lll["searchable_0"]="none";
$lll["searchable_1"]="all";
$lll["customlist_displayedFor_1"]="all";
$lll["searchable_2"]="logged in users only";
$lll["customlist_displayedFor_2"]="logged in users only";
$lll["searchable_4"]="admin only";
$lll["customlist_displayedFor_4"]="admin only";
$lll["customfield_isCommon"]="Scope of the field";
$lll["customfield_isCommon_colhead"]="Scope";
$lll["common"]="Common";
$lll["unique"]="Unique";
$lll["customfield_isCommon_expl"]="If you set the scope to common, the field will exist in every categories. E.g.: if you have a web shop, whatever categories you set up, a 'Price' field must probably belong to all of them, so the 'Price' is best to define as a common field. If you create a common field, or change a unique field to common, it will suddenly appear in all categories - not just there where you created it. If you delete a common field, it will dissappear from all the categories at once.<br><br>Even if a field is common, it can be differently set up in different categories. E.g. you can set it to appear on the ad details page in one category, but hide it in an other category. Only the 'Name' and the 'Type' properties have to be really equal in all categories.<br><br>You can even set up your classifieds program so that all the fields are common! In some cases, it can make a good sense: e.g. if you have cars and only cars in every categories, probably all the categories have just the same list of custom fileds. The strength of the common fields will really show up in defining custom ad lists! E.g. the 'Recent ads' list can contain ads from many different categories, but if you have common fields, you need not be restricted to show only the 'Title', 'Description', and 'Category' columns in the list any more - you can choose any common field to be a column in the list!";
$lll["customfield_isCommon_0"]="Unique to this category";
$lll["customfield_isCommon_1"]="Common to all the categories";
$lll["userfield_create_completed"]="The custom field has been successfully created.";
$lll["itemfield_create_completed"]="The custom field has been successfully created.";
$lll["itemfield_columnIndex"]="Column index";
$lll["NotificationsDescription"]="Manage the list of notifications here - the emails the program sends out automatically on certain actions.";
$lll["category_restartExpOnModify"]="Restart expiration on modify";
$lll["category_restartExpOnModify_expl"]="You can use this as an alternative of the ad prolonging. If checked and the owner modifies his or her ad (and admin approves it if moderation has been enabled), the ad expiration will start again.";
$lll["controlPanel"]="Control panel";
$lll["controlpanel_ttitle"]="";
$lll["customlist_ttitle"]="Custom lists";
$lll["customlist"]="Custom list";
$lll["customlist_listTitle"]="Title";
$lll["customlist_listDescription"]="Description";
$lll["customlist_listDescription_expl"]="Some notes that can better describe what this custom list is all about. Only visible for admin.";
$lll["customlist_create_form"]="Create custom list";
$lll["customlist_modify_form"]="Modify custom list";
$lll["customlist_newitem"]="Add new custom list";
$lll["checkCustomLists"]="Whenever you delete a custom field, check all the custom lists where a search condition has been supplied by clicking on their Title, because they may become invalid if they referred to the just deleted custom field in their condition!";
$lll["listDisplayProperties"]="List display properties";
$lll["customlist_primarySort"]="Primary sort by";
$lll["customlist_primaryDir"]="Primary sort direction";
$lll["customlist_secondaryDir_DESC"]="Descending";
$lll["customlist_primaryDir_DESC"]="Descending";
$lll["customlist_secondaryDir_ASC"]="Ascending";
$lll["customlist_primaryDir_ASC"]="Ascending";
$lll["customlist_primaryPersistent"]="Primary sort is persistent";
$lll["customlist_primaryPersistent_expl"]="If you leave this unchecked, the users can override the initial sorting of the list by clicking on the sorting icons in the list column headers. If you check this, however, you can force specific ads to always appear say on the top of the list however the users sort the list.<br><br>E.g. if you have a custom field called 'Sponsoring level' with values say 'Gold', 'Silver', 'Bronze' and 'None', you can create a custom list with a persistent sorting by 'Sponsoring level' descending. The Gold ads will always appear on the top of the list then and the non-sponsored ads on the bottom of the list.";
$lll["customlist_secondarySort"]="Secondary sort by";
$lll["customlist_secondaryDir"]="Secondary sort direction";
$lll["customlist_secondaryPersistent"]="Secondary sort is persistent";
$lll["customlist_limit"]="Limit";
// Changed in version 3.1.2. Old text:
//$lll["customlist_limit_expl"]="You can limit the number of ads the list contains. Leave it blank for no limit. E.g. 10 means, the list will display only the first 10 ads in the given sorting order from all the matching ads.";
// New text:
$lll["customlist_limit_expl"]="You can limit the number of ads the list contains. Leave it blank for no limit. E.g. 10 means, the list will display only the first 10 ads in the given sorting order from all the matching ads. If you display this list as a scrollable widget, it is always a good idea to set a reasonable, not too high limit, so that the pages with widgets load faster and have less resource consumption both on the cient and on the server side!";
$lll["customlist_columns"]="Select columns to display";
$lll["customlist_columns_expl"]="If you select more than one, you can re-arrange them by drag-and-drop! 
The columns will be displayed in the order you specify here.<br><br>
So that a column is really displayed in a list, note that it is not enough that you add it here! 
The user who displays the list must have also permission to see that column! 
The visibility of a column can be set from two places depending on the scope of the given field:<br><br>
&nbsp;&nbsp;1. If you want to set the visibility of a column that is in a non-category specific list, 
you can do it from the 'Common custom fields' list (open the modify form and edit the 'Show in lists for' property),<br><br>
&nbsp;&nbsp;2. If you want to set the visibility of a column that is in a category specific list, 
you can do it from the 'List of custom fields of this category' list (open the modify form and edit the 'Show in lists for' property)";
$lll["customlist_displayedFor"]="Display list for";
$lll["customlist_displayedFor_expl"]="Whatever you select here, admin will always be able to view the list by clicking on its Title in the 'List of custom lists'!";
$lll["customlist_pages"]="Display on these pages";
$lll["customlist_pages_expl"]="You can specify a page with its link. E.g. '/item/1' is the details page of ad with ID 1. Use '/' to denote the start page. You can list more pages - one in every line. You can use the '*' wildcard to match more than one pages - e.g.: '/list/*' means all the category listing pages, '/item/*' means all the ad details pages. You can exclude pages by adding the '!' prefix. A more complex example: <br><br>/user/login_form<br>/item/create_form<br>/list/*<br>!/list/1<br>!/list/2<br>/item/4<br>/item/5<br><br>The above says \"display the list on the login page, on the ad submit page, on every category listing pages except of the category with ID 1 and 2, and on the details pages of ads with ID 4 and 5!\"<br><br>This feature doesn't work in the free version!";
$lll["customlist_categorySpecific"]="Content depends on the current category";
// Changed in version 3.1.2. Old text:
//$lll["customlist_categorySpecific_expl"]="If you check this and the custom list is just displayed on a page that is in a \"categy context\" (e.g. on a category listing page or ad details page), the custom list will only include the ads of the given category. This is usefulfif you have a custom list called say 'Featured list' and you want to make this list to be context sensitive - so that when a user is just under the Cars category, it displays the featured cars and when the user is just under the 'Dating' category, it contains the featured dating ads.";
// New text:
$lll["customlist_categorySpecific_expl"]="If you check this and the custom list is just displayed on a page that is in a \"category context\" (e.g. on a category listing page or ad details page), the custom list will only include the ads of the given category. <br><br>This is useful if you have a custom list called say 'Featured list' and you want to make this list to be context sensitive - so that when a user is just under the Cars category, it displays the featured cars and when the user is just under the 'Dating' category, it contains the featured dating ads.";
$lll["customlist_recursive"]="and includes ads from the current category AND any of its subcategories";
$lll["customlist_listStyle"]="List style";
$lll["customlist_listStyle_0"]="Normal list";
$lll["customlist_listStyle_1"]="Scrollable widget";
$lll["customlist_listStyle_expl"]="Visit the demo installation http://noahsclassifieds.org/v8rss/ to see how the 'Scrollable widget' style looks like!";
$lll["customlist_positionScrollable"]="Position";
$lll["customlist_positionNormal"]="Position";
$lll["customlist_positionScrollable_expl"]="The place where the list appears on the page";
$lll["customlist_positionNormal_expl"]="The place where the list appears on the page";
$lll["customlist_positionScrollable_0"]="Above the content";
$lll["customlist_positionNormal_0"]="Above the content";
$lll["customlist_positionScrollable_1"]="Below the content";
$lll["customlist_positionNormal_1"]="Below the content";
$lll["customlist_positionScrollable_4"]="On the left side of the page";
$lll["customlist_positionScrollable_5"]="On the right side of the page";
$lll["customlist_positionScrollable_2"]="On the top of the page";
$lll["customlist_positionScrollable_3"]="On the bottom of the page";
$lll["customlist_displayInMenu"]="Assign menu point in menu";
$lll["customlist_displayInMenu_expl"]="If you don't want that the list is displayed on some of the existing pages, you can assign a menu point to it, so that the users access the list on its separate page. E.g.: the good old 'Recent ads', 'Popular ads', 'Pending ads' and 'Approved ads' menu points are from now on just links to the corresponding custom lists!";
$lll["customlist_displayInMenu_0"]="None";
$lll["customlist_displayInMenu_1"]="Login menu";
$lll["customlist_displayInMenu_2"]="User menu";
$lll["customlist_displayInMenu_3"]="Admin menu";
$lll["customlist_displayInMenu_4"]="Category menu";
$lll["randomOrder"]="-- Random order --";
$lll["noDefaultSort"]="-- No sorting --";
$lll["selectField"]="-- Select field --";
$lll["currentUser"]="-- Current user --";
$lll["customlist_ownerName_expl"]="If you select 'Current user', the list will always only contain the ads of the currently logged in user. E.g. this has been used in the setup of the 'My ads' custom list!";
$lll["customlist_loop"]="Loop ads";
$lll["customlist_loop_expl"]="Whether scrolling starts over when last item is exceeded";
$lll["customlist_autoScroll"]="Auto scroll in every (seconds)";
$lll["customlist_autoScroll_expl"]="Use 0 to disable auto scroll";
$lll["customlist_cache"]="Cache list content and renew the cache in every (minutes)";
$lll["customlist_cache_expl"]="So that pages that display custom lists can be faster, it is possible to cache the content of the list on the server. Use 0 to disable caching!";


// Added in 3.0.0:
// Changed in version 3.1.3. Old text:
//$lll["versionTooLow"]="Required minimum MySql version is %s. The current one is %s. Required minimum MySql version is %s. The current one is %s.";
// New text:
$lll["versionTooLow"]="Required minimum MySql version is %s. The current one is %s. Required minimum Php version is %s. The current one is %s.";
$lll["settings_joomlaLink"]="Joomla site";
$lll["settings_joomlaLink_expl"]="If you have installed a Joomla bridge, you can enter the URL of your main Joomla site here. If you do that, the login menu will contain a 'Main site' menu point that links to the URL.";
$lll["enableUserSearch"]="Enable user search";
$lll["enableUserSearch_expl"]="This feature is not available in the Evaluation version!";
$lll["appsettings_modify_completed"]="The settings have been successfully modified";
$lll["settings_langDir"]="Language direction";
$lll["settings_langDir_ltr"]="Left to right";
$lll["settings_langDir_rtl"]="Right to left";
$lll["customfield_fixInfoText"]="This is a \"fix\" field which means that you can't delete it and you can only change some of its properties.";
$lll["selectUserField"]="-- Select user field --";
$lll["customfield_userField"]="or select one of the user fields";
$lll["customfield_userField_expl"]="Instead of creating a completely new custom field by entering a Name for it above, you have the option to select one of the user fields for display. This way, the fields of the owner of an ad can be displayed directly in either the ad list or on the ad details page. <br><br>E.g. you can add the phone number of the owner of the ad to the ad details page. Or if you have a custom 'Zip code' user field, you can display it, too. Moreover, if you specify the Zip code as 'Searchable', users will be able to search for ads by zip code!";
$lll["userField"]="User field";
$lll["customfield_checkboxCols"]="Number of columns to display the checkboxes in";
$lll["userfield_displayLabel_expl"]="If checked off, the field label will not be displayed on the user details page and the field value will span over the labels of the other fields.";
$lll["userfield_displaylength_expl"]="The maximum number of characters that are displayed on the user list page. The appearance of the list view can be protected against displaying very long fields in a cell.";
$lll["userfield_rangeSearch_expl"]="If this is checked than one can define e.g. '10-20' as a search condition to search for user where the value of this field is between 10 and 20.";
$lll["userfield_subType_expl"]="";
$lll["itemfield_ttitle"]="Custom fields of category '%s'";
$lll["customfield_advanced_form"]="Advanced operations";
$lll["userfield_mainPicture_expl"]=" ";
$lll["userfield_seo_expl"]="You can specify here which custom field of the user will serve as the content of the HTML TITLE tag, DESCRIPTION tag and KEYWORDS tag, respectively.";
$lll["userfield_detailsPosition_expl"]="The placement of the fields on the user details page. The 'sidebar' is the right area of the details panel where the pictures reside (in the modern theme). You can place fields above the pictures area, or below them with this setting.";
$lll["customfield_showInForm"]="Show in forms for";
$lll["userfield_showInForm_expl"]="Note that in case of fix user fields, this setting has a limited meaning only! E.g. if you set the 'Name' field to be displayed for admin only, it only refers to the user modify form (i.e. you can't hide the 'Name' field from the registration and the login forms). Similarly, you can't hide the 'Email' field from the registration form.";
$lll["subscriptionType_0"]="none";
$lll["enableFavorities_0"]="none";
$lll["showInDetails_0"]="none";
$lll["showInList_0"]="none";
$lll["showInForm_0"]="none";
$lll["enableUserSearch_0"]="none";
$lll["subscriptionType_1"]="all";
$lll["enableFavorities_1"]="all";
$lll["showInDetails_1"]="all";
$lll["showInList_1"]="all";
$lll["showInForm_1"]="all";
$lll["enableUserSearch_1"]="all";
$lll["enableFavorities_2"]="logged in users only";
$lll["subscriptionType_2"]="logged in users only";
$lll["showInDetails_2"]="logged in users only";
$lll["showInList_2"]="logged in users only";
$lll["showInForm_2"]="logged in users only";
$lll["enableUserSearch_2"]="logged in users only";
$lll["showInDetails_3"]="owner of the ad only";
$lll["showInList_3"]="owner of the ad only";
$lll["showInForm_3"]="owner of the ad only";
$lll["enableFavorities_4"]="admin only";
$lll["subscriptionType_4"]="admin only";
$lll["showInDetails_4"]="admin only";
$lll["showInList_4"]="admin only";
$lll["showInForm_4"]="admin only";
$lll["enableUserSearch_4"]="admin only";
$lll["subscriptionType_5"]="all but admin";
$lll["enableFavorities_5"]="all but admin";
$lll["userfield_ttitle"]="Custom fields of the users";
$lll["userfield_type_expl"]="";
$lll["methods"]="Methods";
$lll["clone"]="clone";
$lll["copyOfCategory"]="Copy of '%s'";
$lll["organizeNextPageDrop"]="Hover the mouse here when dragging to place the category in the next page.";
$lll["organizePreviousPageDrop"]="Hover the mouse here when dragging to place the category in the previous page.";
$lll["organizeNextItems"]="next categories &raquo;";
$lll["organizePreviousItems"]="&laquo; previous categories";
$lll["fieldset_create_form"]="Advanced operations on the whole list of custom fields of the category (they don't work in the free version!)";
$lll["fieldset_deleteAll"]="Delete all fields";
// Changed in version 3.1.0. Old text:
//$lll["fieldset_deleteAll_expl"]="This will delete all the non-fix custom fields of this category at once.<br><br>Please note that deleting custom fields causes data loss, because the corresponding ad field values will be deleted, too!";
// New text:
$lll["fieldset_deleteAll_expl"]="This will delete all the unique custom fields of this category at once.<br><br>Please note that deleting custom fields causes data loss, because the corresponding ad field values will be deleted, too!";
$lll["fieldset_cloneToSubcats"]="Clone into sub categories";
$lll["fieldset_cloneToSubcats_expl"]="This list of custom fields will be applied in every sub categories of this category.<br><br>Please note that if the sub categories have custom fields already, they will be deleted first! So, this operation is mainly useful for setting up new categories, because it may cause data loss in categories that have ads already.";
$lll["fieldset_cloneToCats"]="Clone into categories";
$lll["fieldset_cloneToCats_expl"]="This list of custom fields will be applied in every category you select on the right (you can select more!).<br><br>Please note that if the categories have custom fields already, they will be deleted first! So, this operation is mainly useful for setting up new categories, because it may cause data loss in categories that have ads already.";
$lll["fieldset_cloneFromCat"]="Clone from category";
$lll["fieldset_cloneFromCat_expl"]="This is the opposite of the previous operation: it will replace all the existing custom fields of this category with the field list of an other category. The same is applied to this one, too: it can cause data loss if if this category has ads already!<br><br>Just to make it completely clear: none of the cloning operations actually copy ads or ad values! And they don't copy categories either! They copy custom field lists with all their properties. Relocating ads from one category into an other is possible with the 'move' feature on a per advertisement basis. If you want to create duplicates of whole categories (with all their custom fields, but without their ads and sub categories!), you can use the 'clone' feature under the 'Organize categories' menu point.";
$lll["fieldset_deleteAll_successful"]="The custom fields have been successfully deleted";
$lll["fieldset_cloneToSubcats_successful"]="The custom fields have been successfully cloned to the sub categories";
$lll["fieldset_cloneToCats_successful"]="The custom fields have been successfully cloned to the selected categories";
$lll["fieldset_cloneFromCat_successful"]="The custom fields of the selected category have been successfully cloned here";
$lll["fields"]="fields";


// Added in 2.4.0:
$lll["settings_charLimit_expl"]="'0' means no limit.";
$lll["settings_extraTopContent"]="Additional top content";
$lll["settings_extraTopContent_expl"]="With this, you can insert custom HTML below the header section of the pages (status bar, menus).<br><br>This feature is not available in the Free version of the program!";
$lll["settings_extraBottomContent"]="Additional bottom content";
$lll["settings_extraBottomContent_expl"]="With this, you can insert custom HTML above the powered footer of the pages.<br><br>This feature is not available in the Free version of the program!";
$lll["customfield_subType_expl"]="E.g. if you have a 'Price' field, it is wise to set it as a 'Float number', so that the sorting by the Price column and range search by the price field can properly work. You can then enter the necessary currency symbol prefix, precision and thousands separator settings under the 'Display formatting' section.";
$lll["formatSection"]="Display Formatting";
$lll["customfield_formatPrefix"]="Prefix";
$lll["customfield_formatPrefix_expl"]="Typical examples are a currency symbol, or percentage sign. Anything you enter here will preceed the values of this custom field.";
$lll["customfield_formatPostfix"]="Postfix";
$lll["customfield_formatPostfix_expl"]="E.g. you can add units to the numbers here. Anything you enter here will follow the values of this custom field.";
$lll["customfield_precision"]="Precision";
$lll["customfield_precision_expl"]="Floating point precision - sets the number of decimal points.";
$lll["customfield_precisionSeparator"]="Precision separator";
$lll["customfield_precisionSeparator_expl"]="Sets the separator for the decimal point";
$lll["customfield_thousandsSeparator"]="Thousands separator";
$lll["customfield_useMarkitup"]="Use embedded HTML editor instead of a simple textarea";
$lll["category_expirationEnabled"]="Enable expiration";
$lll["category_expirationOverride"]="Allow expiration override for";
$lll["category_allowSubmitAdAdmin"]="Only admin can submit ads in this category";
$lll["category_expirationOverride_expl"]="If you enable this, the 'Number of days before the ad expire' field will appear in the ad create/modify form and the owner can enter a number. If you specified '0' in the above field, they can enter an arbitrary number. If you specified anything greater than null, it will serve as the default and in one as the maximum number of days the owner can enter.";
$lll["category_expirationOverride_0"]="None";
$lll["category_expirationOverride_2"]="All users";
$lll["category_expirationOverride_4"]="Admin only";
$lll["category_organize"]="Organize categories";
$lll["exp"]="Expiration";
$lll["useDragAndDrop"]="Use drag-and-drop to reorganize the categories then click on 'Save order'!";
$lll["organizeSaveButton"]="Save order";
$lll["organizeSaveMessage"]="The category order has been successfully saved";
$lll["organizeSaveError"]="Could not send the data to the server.";
$lll["organizeLoadError"]="Could not load the data from the server.";


// Added in 2.3.0:
$lll["appFileRemoveExpl"]="From version 2.3.0, most of the php files that used to be directly under the installation directory, must reside under the htaccess-protected 'app' sub directory.
                           The installation root directory may only contain 'index.php' and 'initdir.php'.";
$lll["appFileRemove"]="In order to start using the program, you have to remove the following unnecessary php files from the installation root: <span class='confexpl'>%s.</span><br><br><a href='%s'>Click here to remove them!</a><span class='confexpl'> (If this message doesn't disappear after you clicked, it means the program has no permission to remove these files. In this case, you must delete them manually!)</span>";
$lll["backupFileRemoveExpl"]="From security reasons, the backup directories created by the automatic updates have to be deleted. If you still need them, save them somewhere above your web root!";
$lll["backupFileRemove"]="In order to start using the program, you have to remove the following backup directories from the installation root: <span class='confexpl'>%s.</span><br><br><a href='%s'>Click here to remove them!</a><span class='confexpl'> (If this message doesn't disappear after you clicked, it means the program has no permission to remove these files. In this case, you must delete them manually!)</span>";
$lll["systemConfCheck"]="System configuration checking...";
$lll["niceURLFeature"]="Nice URL feature:";
$lll["niceURLFeature_1"]="Noah's Classifieds supports using nice URLs. This means for example that the link of an ad details page can look like this:";
$lll["niceURLFeature_2"]="instead of the current solution:";
$lll["niceURLFeature_3"]="Besides that the former one is nicer, it is also said to be more search engine friendly.";
$lll["niceURLFeature_4"]="So that the nice URL feature works the Apache module called %s must be installed. It can't be find out for sure whether it is installed currently (Php is probably installed as a CGI binary).";
$lll["niceURLFeature_5"]="If %s is already installed, you should create a file under the classifieds installation directory called %s and put the following text in it, in order to enable nice URLs:";
$lll["niceURLFeature_6"]="If after doing this, the nice url feature still doesn't work, you should also check the following in the Apache configuration file:";
$lll["niceURLFeature_7"]="%s override for the classifieds webroot is enabled,";
$lll["niceURLFeature_8"]="%s for the classifieds webroot is enabled,";
$lll["niceURLFeature_9"]="So that the nice URL feature works the Apache module called %s must be installed. It's not installed currently.";
$lll["reg_companyName"]="Company name";
$lll["reg_firstName"]="First name";
$lll["reg_lastName"]="Last name";
$lll["reg_email"]="Email";
$lll["reg_submit"]="Submit";
$lll["securityProperties"]="Security settings";
$lll["settings_applyCaptcha"]="Apply Spam protection (CAPTCHA) in the following forms";
$lll["settings_applyCaptcha_1"]="'Reply to this posting' and 'Email this to a friend'";
$lll["settings_applyCaptcha_2"]="Login form";
$lll["settings_applyCaptcha_3"]="Register form";
$lll["settings_applyCaptcha_4"]="Ad submission";
$lll["customfield_displayLabel"]="Display label";
$lll["customfield_displayLabel_expl"]="If checked off, the field label will not be displayed on the ad details page and the field value will span over the labels of the other fields.";
$lll["customfield_detailsPosition"]="Position";
$lll["customfield_detailsPosition_expl"]="The placement of the fields on the ad details page. The 'sidebar' is the right area of the details panel where the pictures reside (in the modern theme). You can place fields above the pictures area, or below them with this setting.";
$lll["customfield_detailsPosition_0"]="Normal";
$lll["customfield_detailsPosition_1"]="Top of the sidebar";
$lll["customfield_detailsPosition_2"]="Bottom of the sidebar";
$lll["formProperties"]="Form settings";
$lll["listProperties"]="List settings";
$lll["detailsProperties"]="Details page settings";
$lll["searchProperties"]="Search settings";
$lll["miscProperties"]="Miscellaneous settings";
$lll["customfield_showInDetails"]="Displayed for";

$lll["mysql_found"]="MySQL has been found.";
$lll["need_pw"]="MySQL require password for user %s.";
$lll["incorr_pw"]="MySQL password for %s is incorrect.";
$lll["mysql_not_found"]="MySQL not found! Please modify the parameters bellow to satisfy your MySQL configuration!";
$lll["db_installed"]="Database has been installed: %s";
$lll["cantcreatedb"]="Can not reach or create database. User %s has no create database permission, or cannot reach the database. Change the name of the user or give him appropriate rights!";
$lll["cantconnectdb"]="Can not connect to database. May be have no rights or not exists, trying to create.";
$lll["inst_create_table_err"]="Error while trying to create tables, %s already installed?";
$lll["db_created"]="Database %s has been created.";
$lll["tables_installed"]="Database tables has been installed.";
$lll["fill_table_err"]="Error while trying to fill tables.";
$lll["tables_filled"]="Database tables has been filled with initial data.";
$lll["inst_click"]="Click here to access %s.";
$lll["createTableFailed"]="Create table failed";
$lll["install"]="Install";
$lll["clickToInstall"]="Click on 'Install' to install %s!";
$lll["admin_ok"]="Administrator user has been created, username: admin, password: admin.";
$lll["create_file_ok"]="Config has been successfully created.";
$lll["create_file_nok"]="Config file have to be created manually.";
$lll["inst_params"]="MySQL database will be created with the following parameters:";
$lll["edit_params"]="Edit parameters";
$lll["acceptTerms"]="I have read through and accept the below terms and conditions: <input type='checkbox' id='accept' name='accept'>";
$lll["youMustAcceptTerms"]="You must accept the terms and conditions in order to continue!";
$lll["hostName"]="Hostname";
$lll["dbHostName"]="Hostname";
$lll["mysqluser"]="Mysql user name";
$lll["dbName"]="Database name";
$lll["dbDbName"]="Database name";
$lll["dbSocket"]="Socket";
$lll["formtitle"]="MySQL Settings";
$lll["password"]="Password";
$lll["dbPort"]="Port";
$lll["cookieok"]="Cookies are enabled.";
$lll["cookienok"]="Enable cookies and start the install process again!";
$lll["conf_file_write_err"]="Can not open config file for write";
$lll["compare_conf"]="Create a file with your favorite text editor named 'app/config.php' in the directory where your source is, and copy the following source code into it! Be sure not to write any newline after the last line!";
$lll["afterwrconf"]="<u>After</u> writing the config file click the link below!";
$lll["move_inst_file"]="Please remove the install.php file from this directory!";
$lll["inst_ch_pw"]="Administrator settings - username: admin, password: admin, don't forget to change the password!";
$lll["create_file_nok_ext"]="The server has no permission to create the config file. You have two choices:<br>
#1: Create an empty file in the application directory with the name app/config.php, and give the server write permission to it. Under unix:<br>touch app/config.php;chmod 777 app/config.php<br>and click on the Reload/Refresh button.<br>#2: You Click on install and create the config file manually with your favorite text editor.<br>The program will show the text you should write into the file app/config.php.";
$lll["registerNoah"]="Register";
$lll["notRegistered"]="Not registered";
$lll["registerNoahTitle"]="Register Noah's Classifieds";
$lll["noahAlreadyRegistered"]="The product is already registered!";
$lll["noahRegistrationFalseResponse"]="Unable to send registration data to the Noah's server. Please, try again later!";
$lll["noahRegistrationSuccessfull"]="Thank you. The product is now registered!";
$lll["download"]="Download";
$lll["u_maintitle"]="Noah's Classifieds update process";
$lll["secure_copy"]="Disarankan untuk menyimpan versi lama Noah's Classifieds sebelum melakukan update.<br>Simpan file program dalam direktori terpisah dan pastikan untuk menyimpan database!<br>Klik OK untuk melanjutkan, atau Cancel untuk membatalkan proses update!";
$lll["ready_to_update"]="Siap untuk to update data base %s ke versi  %s?<br>";
$lll["invalid_version"]="Versi yang diberikan tidak valid: %s";
$lll["updateSuccessful"]="Update berhasil.<br>Hint: Sebagai admin, klik pada menu 'Check' untuk melihat aturan dalam sistem iklan!";
$lll["updating"]="Proses update dari versi %s ke versi %s...";
$lll["already_installed"]="Versi software yang digunakan %s telah terinstal.";
$lll["picturesDirMustbeWritable"]="The '%s' directory must be writable by the program in order to perform the update! Update failed.";
$lll["updateAutomatic"]="Update";
$lll["updateManualZip"]="Download ZIP";
$lll["updateManualTgz"]="Download TGZ";
$lll["downloadFileNotExists"]="Download file '%s' not exists.";
$lll["updateFailed"]="Update failed, because the program has no permission to create or modify files under the installation directory.";
$lll["currentVersionIs"]="The current version is: %s";
$lll["latestVersionIs"]="The latest version is: %s";
$lll["noNeedToUpdate"]="There is no need to update.";
$lll["checkUpdates"]="Updates";
$lll["checkUpdatesTitle"]="Checking the Noah's Classifieds site for available updates";
$lll["nopermission"]="Proses server tidak diijinkan untuk menulis di 'pictures/listings' dan/atau 'pictures/cats' directories.<br>Anda harus masuk dalam 'pictures' dan lakukan eksekuis perintah Unix (dalam sistem Unix, tentu):<br><i>chmod 777 pada listings cats</i>";
$lll["nopermission_expl"]="(Noah's Classifieds mencoba menyimpan hambar iklan dalam 'pictures/listings' dan katgori gambar dalam 'pictures/cats'. Anda harus yakin bahwa program telah diijinkan melakukan ini.)";
$lll["backToIndex"]="Return to the classifieds.";
$lll["onlyFrom1.3"]="You have a version that is older than 1.3. This update script works only with the 1.3 version!";
$lll["cantGetVersionInfo"]="Couldn't get version information. Update failed.";
$lll["checkMailtestTitle"]="Sending out a test mail...";
$lll["triggerMailTest"]="Click here to test mail sending.";
$lll["unableToConnectNoah"]="Unable to connect to the Noah's server. Please, try again later!";
$lll["itemNumbersRecalculated"]="The item numbers have been successfully recalculated";
$lll["dbPrefixExplanation"]="In case Noah's must share the database with tables of other applications, it's wise to specify a table prefix for the Noah's tables, in order to avoid table name collisions. E.g.: 'noah_'";
$lll["dbPrefix"]="Table prefix";
$lll["checkconf"]="Check";
$lll["mailok"]="Email percobaan berhasil dikirim.";
$lll["mailerr"]="Terdapat kesalahan selama pengiriman email percobaan:<br>%s";
$lll["here1"]="klik di sini";
$lll["confpreerr"]="Ada beberapa huruf sebelum &lt;? dalam file config! Silahkan hapus huruf ini (garis baru dan juga spasi)!";
$lll["confposterr"]="Ada beberapa huruf sesudah ?&gt; dalam file config! Silahkan hapus huruf ini (garis baru dan juga spasi)!";
$lll["conffileok"]="File config tampaknya tidak ada masalah.";
$lll["congrat"]="Selamat! Anda telah sukses menginstal Noah's Classifieds!";
$lll["confcheck"]="Pemeriksaan konfigurasi sistem...";
$lll["confdisapp"]="Jika Anda menginkan bekerja dengan software dan menginginkan halaman ini tidak tampak";
$lll["confclicheck"]="Anda dapat mengakses halaman konfigurasi ini pada saat Anda inginkan, jika anda mengklik pada 'Periksa' pada menu link.";
$lll["chadmemail"]="Alamat email Anda adalah admin@admin.admin. Silahkan set secara benar dengan mengklik pada 'Profilku' pada menu link!";
$lll["chsyspass"]="Alamat email sistem Anda adalah system@system.system. Silahkan set secara benar dengan mengklik pada 'Pengaturan' pada menu link!";
$lll["chsyspass_expl"]="The program can't send out notification emails without the system email address that will populate the 'From' and 'Reply-to' fields of the notification emails.";
$lll["chadmpass"]="Password default admin belum diganti! Silahkan ganti pada 'Ubah password' pada menu link!";
$lll["settings_adminEmail"]="Email sistem";
$lll["settings_adminEmail_expl"]="This will appear as the address in the 'From:' field of emails the program sends. If you leave this blank, the program may not be able send out email notifications!";
$lll["nogd"]="Peringatan: server Anda tidak mendukung GD library.";
$lll["nogd_expl"]="(Library ini berguna terhadap program php dalam manipulasi gambar, karena itu mungkin hal ini berguna jika Anda menempatkan dalam server. Dalam program kami hal ini disebut pembuatan gambar thumbnail dari ukuran gambar sepenuhnya yang diupload. Tanpa dukungan program ini maka tidak dapat membuat gambar thumbnails, bagaimanapun browser akan menampilkan gambar yang besar untuk masing-masing gambar. Metode ini berjalan, tetapi hal ini tidak efektif (halaman menjadi didownload setiap kali ada gambar besar). )";
$lll["instFileRemove"]="In order to start using the program, you have to remove the installation files (%s).<br><a href='%s'>Click here to remove them!</a><span class='confexpl'> (If this message doesn't disappear after you clicked, it means the program has no permission to remove these files. In this case, you must delete them manually!)</span>";
$lll["rss"]="RSS";
$lll["rss_modify_form"]="Modify RSS feed";
$lll["rss_language"]="Language";
$lll["rss_link"]="Link";
$lll["rss_link_expl"]="The URL of the classifeds site - e.g.: http://yoursete.com/classifieds";
$lll["rss_descField"]="Description field";
$lll["rss_descField_expl"]="the index of the variable field that serves as the 'Description' of a given ad in the RSS feed. In the default Classifieds installation, it is the 1st field. If you don't have such field, set ot to '0', and no ad description will be displayed in the feed.";
$lll["settings"]="settings";
$lll["settings_modify_form"]="Modify settings";
$lll["settings_expNoticeBefore"]="Jumlah hari yang digunakan untuk memberitahu user sebelum waktu iklan berakhir";
$lll["settings_charLimit"]="Jumlah huruf yang dapat digunakan setiap iklan";
$lll["settings_blockSize"]="Iklan ditampilkan setiap halaman";
$lll["settings_maxPicSize"]="Maksimum ukuran gambar dalam bytes";
$lll["settings_maxPicWidth"]="Maksimum lebar gambar dalam pixel";
$lll["settings_maxPicHeight"]="Maksimum tinggi gambar dalam pixel";
$lll["settings_maxPicHeight_expl"]="'0' means unlimited.";
$lll["settings_maxPicWidth_expl"]="'0' means unlimited.";
$lll["settings_maxPicSize_expl"]="'0' means unlimited.";
$lll["settings_adminFromName"]="System name";
$lll["settings_adminFromName_expl"]="This will appear as the name in the 'From:' field of email notifications the program sends out.";
$lll["settings_versionFooter"]="Version footer";
$lll["settings_titlePrefix"]="Title prefix";
$lll["settings_dateFormat"]="Date format";
$lll["settings_dateFormat_expl"]="For more information and examples on the available date specifiers, <a href='http://php.net/manual/en/function.date.php' target='_blank'>click here</a>";
// Changed in version 3.0.0. Old text:
//$lll["settings_enableFavorities"]="Enable the 'Add to favorities' feature";
// New text:
//$lll["settings_enableFavorities"]="Enable the 'Add to favorities' feature for";
$lll["settings_enableFavorities"]="Enable the 'Add to favorities' feature for";
$lll["settings_enableFavorities_expl"]="This setting has no effect in the Evaluation version";
$lll["settings_updateCheckInterval"]="Check for Noah's updates periodically";
$lll["settings_updateCheckInterval_expl"]="The program can check for updates automatically and when a new release is available, it 
                                              displays the update page for the administrator. This setting specifies the length of the checking period in days.
                                              If you want to disable the feature, set it to 0!";
$lll["mailProperties"]="Mail sending properties";
$lll["themeProperties"]="Theme support";
$lll["settings_defaultTheme"]="Default theme";
$lll["settings_allowedThemes"]="Allowed themes to select from";
$lll["settings_allowedThemes_expl"]="If you create a new subdirectory under 'themes' for your custom theme - e.g. 'my_new_theme', it will automatically appear in this list as a new item 'My new theme'!";
$lll["settings_allowSelectTheme"]="Allow others to change theme";
$lll["settings_allowSelectTheme_expl"]="If this is enabled, a selection drop down will be displayed on the pages that allows the immediate change of the program theme.";
$lll["languageProperties"]="Language support";
$lll["settings_defaultLanguage"]="Default language";
$lll["settings_allowedLanguages"]="Allowed languages to select from";
$lll["settings_allowSelectLanguage"]="Allow others to change language";
$lll["settings_allowSelectLanguage_expl"]="If this is enabled, a selection drop down will be displayed on the pages that allows the immediate change of the program language.";
$lll["settings_smtpServer"]="SMTP server name";
$lll["settings_smtpServer_expl"]="Use these fields if you want that the program sends out the notification emails through an SMTP server. Otherwise, the native Php mail function will be used.";
$lll["settings_smtpUser"]="SMTP user name";
$lll["settings_smtpPass"]="SMTP password";
$lll["settings_fallBackNative"]="Fall back on native mail if SMTP fails";
$lll["settings_titlePrefix_expl"]="This text will preceed any title in the title bar of the browser. E.g.: you can set it to the name of your site.";
$lll["seoProperties"]="Search engine optimization";
$lll["settings_mainTitle"]="Title tag";
$lll["settings_mainTitle_expl"]="The content of the TITLE, DESCRIPTION and KEYWORDS usually depends on which category list or 
                                 which ad details page is currently displayed - i.e. you can define this per category and the users 
                                 may define it per ad. These three fields, however, serve as the defaults for those cases when a page 
                                 is just not in a category or ad context (e.g. the start page itself)";
$lll["settings_mainDescription"]="Description meta tag";
$lll["settings_mainKeywords"]="Keywords meta tag";
$lll["settings_helpLink"]="'Help' link destination";
$lll["settings_helpLink_expl"]="The full URL of the help file. With this, you can define your own Help page. E.g.: http://yoursite/classifieds_dir/customhelp.html";
$lll["settings_maxMediaSize"]="Maximum uploadable media file size in bytes";
$lll["settings_maxMediaSize_expl"]="'0' means unlimited.<br><br>Note, however, that whatever you set here, there are two Php settings that can limit the maximum uploadable file size. They are 'upload_max_filesize' and 'post_max_size'. They can be set either in the 'php.ini' file, or in the 'httpd.conf', or in the '.htaccess' file per directory. Their default is usually 2MB. You can increase their values to say 50MB in the .htaccess file this way:<br><br>php_value upload_max_filesize \"50M\"<br>php_value post_max_size \"50M\" ";
// Changed in version 3.0.0. Old text:
//$lll["settings_subscriptionType"]="Auto notify";
// New text:
//$lll["settings_subscriptionType"]="Enable auto notify for";
$lll["settings_subscriptionType"]="Enable auto notify for";
$lll["settings_subscriptionType_expl"]="Users can subscribe for getting automatic notifications if new ads are submitted in a category";
$lll["settings_subscriptionType_0"]="Disable auto notify";
$lll["settings_subscriptionType_1"]="Allow for registered users only";
$lll["settings_subscriptionType_2"]="Enable for all";
$lll["settings_menuPoints_expl"]="If 'Submit ad' is unchecked, the menu point will only be visible for admin (only admin can submit ads than). You can also disable or reorganize menu points by simply removing or moving their corresponding section in the 'layout.tpl.php' template file!";
$lll["settings_menuPoints"]="Menu points";
$lll["settings_menuPoints_2"]="Logout";
$lll["settings_menuPoints_3"]="Login";
$lll["settings_menuPoints_4"]="Register";
$lll["settings_menuPoints_5"]="Show My profile";
$lll["settings_menuPoints_6"]="My ads";
$lll["settings_menuPoints_7"]="Submit ad";
$lll["settings_menuPoints_8"]="Recent ads";
$lll["settings_menuPoints_9"]="Popular ads";
$lll["settings_menuPoints_10"]="Search";
$lll["settings_menuPoints_11"]="Home";
$lll["settings_menuPoints_12"]="Help";
$lll["menuPointsSep"]="Pengubahan Menu";
$lll["expirationProperties"]="Properti Berakhir";
$lll["imageProperties"]="Batasan upload gambar";
$lll["otherProperties"]="Pengaturan lain";
$lll["adDisplayProperties"]="Ad display settings";
$lll["settings_renewal"]="Jangka waktu yang diijinkan bagi user untuk memperpanjang iklan yang akan berakhir";
$lll["settings_allowModify"]="User diijinkan untuk mengubah iklannya";
$lll["settings_extraHead"]="Additional HEAD content";
$lll["settings_extraHead_expl"]="With this, you can insert custom HTML right before the closing HEAD tag of the pages. This is usually a good place to insert additional style sheets, or JavaScript.<br><br>This feature is not available in the Free version of the program!";
$lll["settings_extraBody"]="Additional BODY content";
$lll["settings_extraBody_expl"]="With this, you can insert custom HTML right after the opening BODY tag of the pages. E.g. you can insert a banner above all the pages here.<br><br>This feature is not available in the Free version of the program!";
$lll["settings_extraFooter"]="Additional footer content";
$lll["settings_extraFooter_expl"]="With this, you can insert custom HTML right before the closing BODY tag of the pages.<br><br>This feature is not available in the Free version of the program!";
$lll["customfield"]="Data variabel";
$lll["mustBeCommaSeparated"]="Nilai yang mungkin dalam tipe yang dipilih didefinisikan dalam batasan tanda koma";
$lll["invalidDefaultValue"]="Nilai default dalam tipe yang dipilih harus dibatasi dengan satu tanda koma dalam nilai yang mungkin dalam daftar.";
$lll["description"]="Description";
$lll["descriptionDefaultLabel"]="Deskripsi";
$lll["privateField"]="Privasi";
$lll["customfield_type_1"]="Text";
$lll["customfield_type_2"]="Textarea";
$lll["customfield_type_3"]="Boolean";
$lll["customfield_type_4"]="Pilihan";
$lll["customfield_type_6"]="Pilihan berganda";
$lll["customfield_type_5"]="Terbagi";
$lll["customfield_type_7"]="Checkbox";
$lll["customfield_type_8"]="Picture";
$lll["customfield_type_10"]="Media file";
$lll["customfield_type_9"]="Web link";
$lll["customfield_type_11"]="Date";
$lll["customfield_dateDefaultNow"]="Default date is the current day";
$lll["customfield_fromyear"]="From year";
$lll["customfield_fromyear_expl"]="The range of the date selector that populates this field will go from this year. 
                                   You can enter an actual year number like '1971', or you can enter 'now' that stands for the current year.
                                   You can also use a relative year: 'now-5' will mean the range will start from 5 years ago!";
$lll["customfield_toyear"]="To year";
$lll["customfield_toyear_expl"]="The range of the date selector that populates this field will go up to this year.
                                   You can enter an actual year number like '2010', or you can enter 'now' that stands for the current year.
                                   You can also use a relative year: 'now+5' will mean the range will end in 5 years from now!";
$lll["customfield_name"]="Nama";
$lll["customfield_type"]="Tipe";
$lll["customfield_default_multiple"]="Default value";
$lll["customfield_default_text"]="Default value";
$lll["customfield_default_bool"]="Default value";
$lll["customfield_active"]="Aktif";
$lll["customfield_separator"]="Kolom 1.";
$lll["customfield_mandatory"]="Butuh ijin";
// Changed in version 3.0.0. Old text:
//$lll["customfield_showInList"]="Appears in list";
// New text:
//$lll["customfield_showInList"]="Show in lists for";
$lll["customfield_showInList"]="Show in lists for";
$lll["customfield_values"]="Nilai yang mungkin";
$lll["customfield_innewline"]="Ditempatkan di baris baru";
$lll["customfield_displaylength"]="List display length";
$lll["customfield_displaylength_expl"]="The maximum number of characters that are displayed on the ads list page. The appearance of the list view can be protected against displaying very long fields in a cell.";
// Changed in version 3.1.0. Old text:
//$lll["customfield_searchable"]="Searchable";
// New text:
$lll["customfield_searchable"]="Show in the search form for";
$lll["customfield_rangeSearch"]="Allow range search";
// Changed in version 3.1.0. Old text:
//$lll["customfield_rangeSearch_expl"]="If this is checked than one can define e.g. '10-20' as a search condition to search for ads where the value of this field is between 10 and 20.";
// New text:
$lll["customfield_rangeSearch_expl"]="If this is checked than one can define e.g. '10-20' as a search condition to search for ads where the value of this field is between 10 and 20. Or one can enter a range of dates in case of Date fields.";
$lll["customfield_allowHtml"]="Mengijinkan HTML";
// Changed in version 2.3.0. Old text:
//$lll["customfield_allowHtml_expl"]="This only allows 'save' HTML tags, however! Some tags that would impose a security risk, or ruin the layout are excluded.";
// New text:
//$lll["customfield_allowHtml_expl"]="This only allows 'safe' HTML tags, however! Some tags that would impose a security risk, or ruin the layout are excluded.";
$lll["customfield_allowHtml_expl"]="This only allows 'safe' HTML tags, however! Some tags that would impose a security risk, or ruin the layout are excluded.";
$lll["customfield_private"]="Semua privasi terjaga";
$lll["customfield_format"]="Display format";
// Changed in version 2.4.0. Old text:
//$lll["customfield_format_expl"]="You can use it a C-style sprintf format string";
// New text:
//$lll["customfield_format_expl"]="Advanced users can apply a C-style sprintf format string, too.";
$lll["customfield_format_expl"]="Advanced users can apply a C-style sprintf format string, too.";
$lll["customfield_subType"]="Treat this field as";
$lll["customfield_subType_1"]="Text";
$lll["customfield_subType_2"]="Integer number";
$lll["customfield_subType_3"]="Float number";
$lll["customfield_sortable"]="Sorting";
$lll["customfield_expl"]="Explanation text";
$lll["customfield_expl_expl"]="Help text like the one you are just reading! A more detailed description of a form field.";
$lll["private_field"]="(private)";
$lll["customfield_newitem"]="Add new custom field";
$lll["customfield_modify_form"]="Tentukan data variabel dalam iklan pada kategori ini";
$lll["customfield_create_form"]="Create custom field";
$lll["customfield_sortId"]="Sort";
$lll["customfield_sorthelp"]="Use the arrow icons in the 'Sort' column to re-arrange the list, then click on the 'Save sorting' button at the bottom!";
$lll["customfield_savesorting"]="Save sorting";
$lll["customfield_sortingsaved"]="The new custom field sorting has been successfully saved.";
// Changed in version 3.0.0. Old text:
//$lll["customFields"]="List of custom fields of this category";
// New text:
//$lll["customFields"]="List of custom fields";
$lll["customFields"]="List of custom fields";
$lll["customfield_rowspan"]="Spans rows";
$lll["customfield_seo"]="Search engine optimization";
$lll["customfield_seo_0"]="No assignment";
// Changed in version 3.0.0. Old text:
//$lll["customfield_seo_1"]="Use this field as the TITLE of the ad";
// New text:
//$lll["customfield_seo_1"]="Use this field as the TITLE of the details page";
$lll["customfield_seo_1"]="Use this field as the TITLE of the details page";
// Changed in version 3.0.0. Old text:
//$lll["customfield_seo_2"]="Use this field as the DESCRIPTION of the ad";
// New text:
//$lll["customfield_seo_2"]="Use this field as the DESCRIPTION of the details page";
$lll["customfield_seo_2"]="Use this field as the DESCRIPTION of the details page";
// Changed in version 3.0.0. Old text:
//$lll["customfield_seo_3"]="Use this field as the KEYWORDS of the ad";
// New text:
//$lll["customfield_seo_3"]="Use this field as the KEYWORDS of the details page";
$lll["customfield_seo_3"]="Use this field as the KEYWORDS of the details page";
// Changed in version 3.0.0. Old text:
//$lll["customfield_mainPicture"]="Use this field as the main picture of the ad";
// New text:
//$lll["customfield_mainPicture"]="Use this field as the main picture";
$lll["customfield_mainPicture"]="Use this field as the main picture";
$lll["customfield_mainPicture_expl"]="To use this picture in non category specific lists and RSS feeds.";
// Changed in version 2.4.0. Old text:
//$lll["customfield_seo_expl"]="You can specify here which custom field of the item will serve as the content of the HTML TITLE tag, DESCRIPTION tag and KEYWORDS tag, respectively. 
//                              Besides SEO, the content of the TITLE fields will appear in the title bar of the browser when one 
//                              displays the ad, it will be used as the title of the ad in non category specific ad lists and in RSS feeds.
//                              The fields designated as the KEYWORD will not be displayed on the ad page - it will only be visible in the create and modify forms of the ads.";
// New tex:
//$lll["customfield_seo_expl"]="You can specify here which custom field of the item will serve as the content of the HTML TITLE tag, DESCRIPTION tag and KEYWORDS tag, respectively. 
//                              Besides SEO, the content of the TITLE fields will appear in the title bar of the browser when one 
//                              displays the ad, it will be used as the title of the ad in non category specific ad lists and in RSS feeds.";
$lll["customfield_seo_expl"]="You can specify here which custom field of the item will serve as the content of the HTML TITLE tag, DESCRIPTION tag and KEYWORDS tag, respectively. 
                              Besides SEO, the content of the TITLE fields will appear in the title bar of the browser when one 
                              displays the ad, it will be used as the title of the ad in non category specific ad lists and in RSS feeds.";
$lll["customfield_innewline_expl"]="Instead of forming a new column, this setting makes the custom field value appear in a new line that spans over all the other columns horizontally and is placed below them.";
// Changed in version 2.3.0. Old text:
//$lll["customfield_rowspan_expl"]="Use this in conjunction with the 'Place in new line' property of other custom fields. If there are other fields which has been placed in a new line, you can specify with this setting that this fields spans over those new lines vertically.";
// New text:
//$lll["customfield_rowspan_expl"]="Use this in conjunction with the 'Place in new line' property of other custom fields. If there are other fields which has been placed in a new line, you can specify with this setting that this field spans over those new lines vertically.";
$lll["customfield_rowspan_expl"]="Use this in conjunction with the 'Place in new line' property of other custom fields. If there are other fields which has been placed in a new line, you can specify with this setting that this field spans over those new lines vertically.";
$lll["notification"]="notification";
$lll["notification_ttitle"]="Notifications";
$lll["Notifications"]="Notifications";
$lll["notification_subject"]="Email subject";
$lll["notification_body"]="Email body";
$lll["notification_variables"]="Allowed variables";
$lll["notification_active"]="Active";
$lll["notification_modify_form"]="Modify notification";
$lll["notif_remindpass_tit"]="Contains a new password if the user forgot the old one.";
$lll["notif_remindpass_subj"]="New password";
$lll["notif_initpass_tit"]="Sent to the user after the registration, contains the initial password";
$lll["notif_initpass_subj"]="Initial password";
$lll["notification_cc"]="CC";
$lll["notification_cc_expl"]="Specify here the email adress the notification should be sent as a carbon copy.";
$lll["notification_active_expl"]="You can switch on and off the sending of this notification here.";
?>