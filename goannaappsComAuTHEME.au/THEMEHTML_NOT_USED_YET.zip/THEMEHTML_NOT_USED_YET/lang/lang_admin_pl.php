<?php
// If you edit this file, save it in UTF-8 character encoding! 
// Most text editors allow you to select the character encoding you use - even notepad.
// Saving in UTF-8 is important for Noah's Classifieds to be able to display special characters correctly.

// If you make a new translation (or make fixes in an existing one)and want to share 
// your work with other people, too, send us the language file and we will include it 
// in the next release of Noah's.

// You can read more more about the internationalization in the Noah's documentation under:
// http://www.noahsclassifieds.org/documentation/translation

// Content begins:

// Added in 3.1.3:
$lll["category_showDescription"]="Display description";
$lll["category_showDescription_expl"]="There may be cases when you don't want to display the description of a category, but still want that the DESCRIPTION meta tag of the category listing page is populated.";
$lll["category_inactivateOnModify"]="Inactivate on modify";
$lll["category_inactivateOnModify_expl"]="Whether an approved ad becomes pending again if the owner of the ad modifies it.";
$lll["clonecat_create_form"]="Clone category";
$lll["clonecat_amount"]="Number of clones";
$lll["clonecat_amount_expl"]="Creating many clones - especially if you clone the sub categories and pictures, too - can take quite a long time and you should not close the browser during that!";
$lll["clonecat_name"]="Clone with name";
$lll["clonecat_name_expl"]="If you are creating more than one clones, you can apply numbering in their names if you insert '%d' here. E.g. 'Cars-%d' will result in the following clones: Cars-1, Cars2, Cars-3, etc.";
$lll["clonecat_recursive"]="Clone sub categories, too";
$lll["clonecat_withPictures"]="Clone the category pictures, too";
$lll["categoriesCloned"]="The categories have been successfully cloned.";


// Added in 3.1.2:
$lll["commonFieldAlreadyExists"]="A common field with this name and type already exists. Please, choose an other name!";


// Added in 3.1.0:
$lll["checkUpdatesDescription"]="Check out if a newer version of Noah's Classifieds has been released. You can even perform the update immediately, or download the update package with a single click!";
$lll["checkconfDescription"]="Click here any time to verify if the program has been set up correctly. In case of any problems being detected, the Check page gives useful hints how to solve them.";
$lll["rssDescription"]="Set up the properties of the RSS feed the program generates.";
$lll["settings_langDir_expl"]="If you enable more languages - some with left to right direction and some with right to left, you should rather specify the direction in the lang file itself! E.g. if you have an Arabian language file, you can put a line like this in it, in order to override this setting in case of the Arabian language:<br><br>$langDir='rtl';<br><br>Use 'rtl' for 'right to left' and 'ltr' for 'left to right'!";
$lll["customfield_default_multiple_expl"]="This must be a comma separated list of possible values. E.g. one,two,three";
$lll["customfield_values_expl"]="This must be a comma separated list of possible values. E.g. one,two,three";
$lll["itemfield_ttitle_global"]="Common custom fields";
$lll["searchable_0"]="none";
$lll["searchable_1"]="all";
$lll["customlist_displayedFor_1"]="all";
$lll["searchable_2"]="logged in users only";
$lll["customlist_displayedFor_2"]="logged in users only";
$lll["searchable_4"]="admin only";
$lll["customlist_displayedFor_4"]="admin only";
$lll["customfield_isCommon"]="Scope of the field";
$lll["customfield_isCommon_colhead"]="Scope";
$lll["common"]="Common";
$lll["unique"]="Unique";
$lll["customfield_isCommon_expl"]="If you set the scope to common, the field will exist in every categories. E.g.: if you have a web shop, whatever categories you set up, a 'Price' field must probably belong to all of them, so the 'Price' is best to define as a common field. If you create a common field, or change a unique field to common, it will suddenly appear in all categories - not just there where you created it. If you delete a common field, it will dissappear from all the categories at once.<br><br>Even if a field is common, it can be differently set up in different categories. E.g. you can set it to appear on the ad details page in one category, but hide it in an other category. Only the 'Name' and the 'Type' properties have to be really equal in all categories.<br><br>You can even set up your classifieds program so that all the fields are common! In some cases, it can make a good sense: e.g. if you have cars and only cars in every categories, probably all the categories have just the same list of custom fileds. The strength of the common fields will really show up in defining custom ad lists! E.g. the 'Recent ads' list can contain ads from many different categories, but if you have common fields, you need not be restricted to show only the 'Title', 'Description', and 'Category' columns in the list any more - you can choose any common field to be a column in the list!";
$lll["customfield_isCommon_0"]="Unique to this category";
$lll["customfield_isCommon_1"]="Common to all the categories";
$lll["userfield_create_completed"]="The custom field has been successfully created.";
$lll["itemfield_create_completed"]="The custom field has been successfully created.";
$lll["itemfield_columnIndex"]="Column index";
$lll["NotificationsDescription"]="Manage the list of notifications here - the emails the program sends out automatically on certain actions.";
$lll["category_restartExpOnModify"]="Restart expiration on modify";
$lll["category_restartExpOnModify_expl"]="You can use this as an alternative of the ad prolonging. If checked and the owner modifies his or her ad (and admin approves it if moderation has been enabled), the ad expiration will start again.";
$lll["controlPanel"]="Control panel";
$lll["controlpanel_ttitle"]="";
$lll["customlist_ttitle"]="Custom lists";
$lll["customlist"]="Custom list";
$lll["customlist_listTitle"]="Title";
$lll["customlist_listDescription"]="Description";
$lll["customlist_listDescription_expl"]="Some notes that can better describe what this custom list is all about. Only visible for admin.";
$lll["customlist_create_form"]="Create custom list";
$lll["customlist_modify_form"]="Modify custom list";
$lll["customlist_newitem"]="Add new custom list";
$lll["checkCustomLists"]="Whenever you delete a custom field, check all the custom lists where a search condition has been supplied by clicking on their Title, because they may become invalid if they referred to the just deleted custom field in their condition!";
$lll["listDisplayProperties"]="List display properties";
$lll["customlist_primarySort"]="Primary sort by";
$lll["customlist_primaryDir"]="Primary sort direction";
$lll["customlist_secondaryDir_DESC"]="Descending";
$lll["customlist_primaryDir_DESC"]="Descending";
$lll["customlist_secondaryDir_ASC"]="Ascending";
$lll["customlist_primaryDir_ASC"]="Ascending";
$lll["customlist_primaryPersistent"]="Primary sort is persistent";
$lll["customlist_primaryPersistent_expl"]="If you leave this unchecked, the users can override the initial sorting of the list by clicking on the sorting icons in the list column headers. If you check this, however, you can force specific ads to always appear say on the top of the list however the users sort the list.<br><br>E.g. if you have a custom field called 'Sponsoring level' with values say 'Gold', 'Silver', 'Bronze' and 'None', you can create a custom list with a persistent sorting by 'Sponsoring level' descending. The Gold ads will always appear on the top of the list then and the non-sponsored ads on the bottom of the list.";
$lll["customlist_secondarySort"]="Secondary sort by";
$lll["customlist_secondaryDir"]="Secondary sort direction";
$lll["customlist_secondaryPersistent"]="Secondary sort is persistent";
$lll["customlist_limit"]="Limit";
// Changed in version 3.1.2. Old text:
//$lll["customlist_limit_expl"]="You can limit the number of ads the list contains. Leave it blank for no limit. E.g. 10 means, the list will display only the first 10 ads in the given sorting order from all the matching ads.";
// New text:
$lll["customlist_limit_expl"]="You can limit the number of ads the list contains. Leave it blank for no limit. E.g. 10 means, the list will display only the first 10 ads in the given sorting order from all the matching ads. If you display this list as a scrollable widget, it is always a good idea to set a reasonable, not too high limit, so that the pages with widgets load faster and have less resource consumption both on the cient and on the server side!";
$lll["customlist_columns"]="Select columns to display";
$lll["customlist_columns_expl"]="If you select more than one, you can re-arrange them by drag-and-drop! 
The columns will be displayed in the order you specify here.<br><br>
So that a column is really displayed in a list, note that it is not enough that you add it here! 
The user who displays the list must have also permission to see that column! 
The visibility of a column can be set from two places depending on the scope of the given field:<br><br>
&nbsp;&nbsp;1. If you want to set the visibility of a column that is in a non-category specific list, 
you can do it from the 'Common custom fields' list (open the modify form and edit the 'Show in lists for' property),<br><br>
&nbsp;&nbsp;2. If you want to set the visibility of a column that is in a category specific list, 
you can do it from the 'List of custom fields of this category' list (open the modify form and edit the 'Show in lists for' property)";
$lll["customlist_displayedFor"]="Display list for";
$lll["customlist_displayedFor_expl"]="Whatever you select here, admin will always be able to view the list by clicking on its Title in the 'List of custom lists'!";
$lll["customlist_pages"]="Display on these pages";
$lll["customlist_pages_expl"]="You can specify a page with its link. E.g. '/item/1' is the details page of ad with ID 1. Use '/' to denote the start page. You can list more pages - one in every line. You can use the '*' wildcard to match more than one pages - e.g.: '/list/*' means all the category listing pages, '/item/*' means all the ad details pages. You can exclude pages by adding the '!' prefix. A more complex example: <br><br>/user/login_form<br>/item/create_form<br>/list/*<br>!/list/1<br>!/list/2<br>/item/4<br>/item/5<br><br>The above says \"display the list on the login page, on the ad submit page, on every category listing pages except of the category with ID 1 and 2, and on the details pages of ads with ID 4 and 5!\"<br><br>This feature doesn't work in the free version!";
$lll["customlist_categorySpecific"]="Content depends on the current category";
// Changed in version 3.1.2. Old text:
//$lll["customlist_categorySpecific_expl"]="If you check this and the custom list is just displayed on a page that is in a \"categy context\" (e.g. on a category listing page or ad details page), the custom list will only include the ads of the given category. This is usefulfif you have a custom list called say 'Featured list' and you want to make this list to be context sensitive - so that when a user is just under the Cars category, it displays the featured cars and when the user is just under the 'Dating' category, it contains the featured dating ads.";
// New text:
$lll["customlist_categorySpecific_expl"]="If you check this and the custom list is just displayed on a page that is in a \"category context\" (e.g. on a category listing page or ad details page), the custom list will only include the ads of the given category. <br><br>This is useful if you have a custom list called say 'Featured list' and you want to make this list to be context sensitive - so that when a user is just under the Cars category, it displays the featured cars and when the user is just under the 'Dating' category, it contains the featured dating ads.";
$lll["customlist_recursive"]="and includes ads from the current category AND any of its subcategories";
$lll["customlist_listStyle"]="List style";
$lll["customlist_listStyle_0"]="Normal list";
$lll["customlist_listStyle_1"]="Scrollable widget";
$lll["customlist_listStyle_expl"]="Visit the demo installation http://noahsclassifieds.org/v8rss/ to see how the 'Scrollable widget' style looks like!";
$lll["customlist_positionScrollable"]="Position";
$lll["customlist_positionNormal"]="Position";
$lll["customlist_positionScrollable_expl"]="The place where the list appears on the page";
$lll["customlist_positionNormal_expl"]="The place where the list appears on the page";
$lll["customlist_positionScrollable_0"]="Above the content";
$lll["customlist_positionNormal_0"]="Above the content";
$lll["customlist_positionScrollable_1"]="Below the content";
$lll["customlist_positionNormal_1"]="Below the content";
$lll["customlist_positionScrollable_4"]="On the left side of the page";
$lll["customlist_positionScrollable_5"]="On the right side of the page";
$lll["customlist_positionScrollable_2"]="On the top of the page";
$lll["customlist_positionScrollable_3"]="On the bottom of the page";
$lll["customlist_displayInMenu"]="Assign menu point in menu";
$lll["customlist_displayInMenu_expl"]="If you don't want that the list is displayed on some of the existing pages, you can assign a menu point to it, so that the users access the list on its separate page. E.g.: the good old 'Recent ads', 'Popular ads', 'Pending ads' and 'Approved ads' menu points are from now on just links to the corresponding custom lists!";
$lll["customlist_displayInMenu_0"]="None";
$lll["customlist_displayInMenu_1"]="Login menu";
$lll["customlist_displayInMenu_2"]="User menu";
$lll["customlist_displayInMenu_3"]="Admin menu";
$lll["customlist_displayInMenu_4"]="Category menu";
$lll["randomOrder"]="-- Random order --";
$lll["noDefaultSort"]="-- No sorting --";
$lll["selectField"]="-- Select field --";
$lll["currentUser"]="-- Current user --";
$lll["customlist_ownerName_expl"]="If you select 'Current user', the list will always only contain the ads of the currently logged in user. E.g. this has been used in the setup of the 'My ads' custom list!";
$lll["customlist_loop"]="Loop ads";
$lll["customlist_loop_expl"]="Whether scrolling starts over when last item is exceeded";
$lll["customlist_autoScroll"]="Auto scroll in every (seconds)";
$lll["customlist_autoScroll_expl"]="Use 0 to disable auto scroll";
$lll["customlist_cache"]="Cache list content and renew the cache in every (minutes)";
$lll["customlist_cache_expl"]="So that pages that display custom lists can be faster, it is possible to cache the content of the list on the server. Use 0 to disable caching!";


// Added in 3.0.0:
// Changed in version 3.1.3. Old text:
//$lll["versionTooLow"]="Required minimum MySql version is %s. The current one is %s. Required minimum MySql version is %s. The current one is %s.";
// New text:
$lll["versionTooLow"]="Required minimum MySql version is %s. The current one is %s. Required minimum Php version is %s. The current one is %s.";
$lll["settings_joomlaLink"]="Joomla site";
$lll["settings_joomlaLink_expl"]="If you have installed a Joomla bridge, you can enter the URL of your main Joomla site here. If you do that, the login menu will contain a 'Main site' menu point that links to the URL.";
$lll["enableUserSearch"]="Enable user search";
$lll["enableUserSearch_expl"]="This feature is not available in the Evaluation version!";
$lll["appsettings_modify_completed"]="The settings have been successfully modified";
$lll["settings_langDir"]="Language direction";
$lll["settings_langDir_ltr"]="Left to right";
$lll["settings_langDir_rtl"]="Right to left";
$lll["customfield_fixInfoText"]="This is a \"fix\" field which means that you can't delete it and you can only change some of its properties.";
$lll["selectUserField"]="-- Select user field --";
$lll["customfield_userField"]="or select one of the user fields";
$lll["customfield_userField_expl"]="Instead of creating a completely new custom field by entering a Name for it above, you have the option to select one of the user fields for display. This way, the fields of the owner of an ad can be displayed directly in either the ad list or on the ad details page. <br><br>E.g. you can add the phone number of the owner of the ad to the ad details page. Or if you have a custom 'Zip code' user field, you can display it, too. Moreover, if you specify the Zip code as 'Searchable', users will be able to search for ads by zip code!";
$lll["userField"]="User field";
$lll["customfield_checkboxCols"]="Number of columns to display the checkboxes in";
$lll["userfield_displayLabel_expl"]="If checked off, the field label will not be displayed on the user details page and the field value will span over the labels of the other fields.";
$lll["userfield_displaylength_expl"]="The maximum number of characters that are displayed on the user list page. The appearance of the list view can be protected against displaying very long fields in a cell.";
$lll["userfield_rangeSearch_expl"]="If this is checked than one can define e.g. '10-20' as a search condition to search for user where the value of this field is between 10 and 20.";
$lll["userfield_subType_expl"]="";
$lll["itemfield_ttitle"]="Custom fields of category '%s'";
$lll["customfield_advanced_form"]="Advanced operations";
$lll["userfield_mainPicture_expl"]=" ";
$lll["userfield_seo_expl"]="You can specify here which custom field of the user will serve as the content of the HTML TITLE tag, DESCRIPTION tag and KEYWORDS tag, respectively.";
$lll["userfield_detailsPosition_expl"]="The placement of the fields on the user details page. The 'sidebar' is the right area of the details panel where the pictures reside (in the modern theme). You can place fields above the pictures area, or below them with this setting.";
$lll["customfield_showInForm"]="Show in forms for";
$lll["userfield_showInForm_expl"]="Note that in case of fix user fields, this setting has a limited meaning only! E.g. if you set the 'Name' field to be displayed for admin only, it only refers to the user modify form (i.e. you can't hide the 'Name' field from the registration and the login forms). Similarly, you can't hide the 'Email' field from the registration form.";
$lll["subscriptionType_0"]="none";
$lll["enableFavorities_0"]="none";
$lll["showInDetails_0"]="none";
$lll["showInList_0"]="none";
$lll["showInForm_0"]="none";
$lll["enableUserSearch_0"]="none";
$lll["subscriptionType_1"]="all";
$lll["enableFavorities_1"]="all";
$lll["showInDetails_1"]="all";
$lll["showInList_1"]="all";
$lll["showInForm_1"]="all";
$lll["enableUserSearch_1"]="all";
$lll["enableFavorities_2"]="logged in users only";
$lll["subscriptionType_2"]="logged in users only";
$lll["showInDetails_2"]="logged in users only";
$lll["showInList_2"]="logged in users only";
$lll["showInForm_2"]="logged in users only";
$lll["enableUserSearch_2"]="logged in users only";
$lll["showInDetails_3"]="owner of the ad only";
$lll["showInList_3"]="owner of the ad only";
$lll["showInForm_3"]="owner of the ad only";
$lll["enableFavorities_4"]="admin only";
$lll["subscriptionType_4"]="admin only";
$lll["showInDetails_4"]="admin only";
$lll["showInList_4"]="admin only";
$lll["showInForm_4"]="admin only";
$lll["enableUserSearch_4"]="admin only";
$lll["subscriptionType_5"]="all but admin";
$lll["enableFavorities_5"]="all but admin";
$lll["userfield_ttitle"]="Custom fields of the users";
$lll["userfield_type_expl"]="";
$lll["methods"]="Methods";
$lll["clone"]="clone";
$lll["copyOfCategory"]="Copy of '%s'";
$lll["organizeNextPageDrop"]="Hover the mouse here when dragging to place the category in the next page.";
$lll["organizePreviousPageDrop"]="Hover the mouse here when dragging to place the category in the previous page.";
$lll["organizeNextItems"]="next categories &raquo;";
$lll["organizePreviousItems"]="&laquo; previous categories";
$lll["fieldset_create_form"]="Advanced operations on the whole list of custom fields of the category (they don't work in the free version!)";
$lll["fieldset_deleteAll"]="Delete all fields";
// Changed in version 3.1.0. Old text:
//$lll["fieldset_deleteAll_expl"]="This will delete all the non-fix custom fields of this category at once.<br><br>Please note that deleting custom fields causes data loss, because the corresponding ad field values will be deleted, too!";
// New text:
$lll["fieldset_deleteAll_expl"]="This will delete all the unique custom fields of this category at once.<br><br>Please note that deleting custom fields causes data loss, because the corresponding ad field values will be deleted, too!";
$lll["fieldset_cloneToSubcats"]="Clone into sub categories";
$lll["fieldset_cloneToSubcats_expl"]="This list of custom fields will be applied in every sub categories of this category.<br><br>Please note that if the sub categories have custom fields already, they will be deleted first! So, this operation is mainly useful for setting up new categories, because it may cause data loss in categories that have ads already.";
$lll["fieldset_cloneToCats"]="Clone into categories";
$lll["fieldset_cloneToCats_expl"]="This list of custom fields will be applied in every category you select on the right (you can select more!).<br><br>Please note that if the categories have custom fields already, they will be deleted first! So, this operation is mainly useful for setting up new categories, because it may cause data loss in categories that have ads already.";
$lll["fieldset_cloneFromCat"]="Clone from category";
$lll["fieldset_cloneFromCat_expl"]="This is the opposite of the previous operation: it will replace all the existing custom fields of this category with the field list of an other category. The same is applied to this one, too: it can cause data loss if if this category has ads already!<br><br>Just to make it completely clear: none of the cloning operations actually copy ads or ad values! And they don't copy categories either! They copy custom field lists with all their properties. Relocating ads from one category into an other is possible with the 'move' feature on a per advertisement basis. If you want to create duplicates of whole categories (with all their custom fields, but without their ads and sub categories!), you can use the 'clone' feature under the 'Organize categories' menu point.";
$lll["fieldset_deleteAll_successful"]="The custom fields have been successfully deleted";
$lll["fieldset_cloneToSubcats_successful"]="The custom fields have been successfully cloned to the sub categories";
$lll["fieldset_cloneToCats_successful"]="The custom fields have been successfully cloned to the selected categories";
$lll["fieldset_cloneFromCat_successful"]="The custom fields of the selected category have been successfully cloned here";
$lll["fields"]="fields";

// Installation:
$lll["mysql_found"]="Baza MySQL została znaleziona.";
$lll["need_pw"]="Baza MySQL wymaga podania hasła użytkownika %s.";
$lll["incorr_pw"]="Hasło do bazy MySQL dla użytkownika %s jest niepoprawne.";
$lll["mysql_not_found"]="Baza MySQL nie została znaleziona! Zmień podane poniżej parametry tak, aby odpowiadały konfiguracji MySQL!";
$lll["db_installed"]="Baza danych został zainstalowana: %s";
$lll["cantcreatedb"]="Baza nie jest dostępna albo nie mogła zostać stworzona. Użytkownik %s nie ma uprawnień do tworzenia bazy albo baza nie jest dostępna. Zmień nazwę użytkownika lub nadaj mu niezbędne prawa!";
$lll["cantconnectdb"]="Połączenie z bazą niemożliwe. Być może nie masz odpowiednich uprawnień lub baza nie istnieje. Spróbuję utworzyć bazę.";
$lll["inst_create_table_err"]="W trakcie tworzenia tabel pojawił się błąd, czy %s nie jest już zainstalowany?";
$lll["db_created"]="Baza danych %s została utworzona.";
$lll["tables_installed"]="Tabele zostały utworzone.";
$lll["fill_table_err"]="Błąd przy wypełnianiu tabel.";
$lll["tables_filled"]="Tabele bazy danych zostały wypełnione przykładowymi danymi.";
$lll["inst_click"]="Kliknij, aby przejść do %s.";
$lll["createTableFailed"]="Tworzenie tabel nie powiodło się";
$lll["install"]="Zainstaluj";
$lll["clickToInstall"]="Kliknij 'Zainstaluj' aby rozpocząć instalację %s!";
$lll["admin_ok"]="Użytkownik o uprawnieniach administratora został utworzony, nazwa użytkownika: admin, hasło: admin.";
$lll["create_file_ok"]="Plik konfiguracyjny został pomyślnie utworzony.";
$lll["create_file_nok"]="Plik konfiguracyjny musi zostać utworzony ręcznie.";
$lll["inst_params"]="Za chwilę zostanie utworzona baza MySQL o następujących parametrach:";
$lll["edit_params"]="Modyfikuj parametry";
$lll["acceptTerms"] = "Przeczytałem i akceptuję niżej opisane warunki umowy: <input type='checkbox' id='accept' name='accept'>";
$lll["youMustAcceptTerms"] = "Musisz zaakceptować warunki umowy, aby móc kontynuować!";
$lll["dbHostName"]=$lll["hostName"]="Nazwa hosta";
$lll["mysqluser"]="Nazwa użytkownika Mysql";
$lll["dbDbName"]=$lll["dbName"]="Nazwa bazy danych";
$lll["dbSocket"]="Gniazdo";
$lll["formtitle"]="Ustawienia MySQL";
$lll["password"]="Hasło";
$lll["dbPort"]="Port";
$lll["cookieok"]="Przeglądarka może zapisywać ciasteczka (cookies).";
$lll["cookienok"]="Włącz w przeglądarce obsługę ciasteczek (cookies) i rozpocznij proces instalacji od początku!";
$lll["conf_file_write_err"]="Nie mogę otworzyć pliku konfiguracyjnego. Zapisanie zmian niemożliwe";
$lll["compare_conf"]="Utwórz w ulubionym edytorze tekstów plik o nazwie 'app/config.php' w folderze źródłowym skryptu i przekopiuj do niego następujący kod! Upewnij się, że ostatnia linia kodu jest ostatnim wierszem w pliku!";
$lll["afterwrconf"]="<u>Po</u> zapisaniu pliku konfiguracyjnego kliknij podany niżej link!";
$lll["move_inst_file"]="Usuń plik install.php z głównego foldera programu!";
$lll["inst_ch_pw"]="Ustawienia konta administratora - nazwa użytkownika: admin, hasło: admin, nie zapomnij zmienić domyślnego hasła!";
$lll["create_file_nok_ext"]="Serwer nie może utworzyć pliku konfiguracyjnego. Masz dwie możliwości:<br>\n#1: Utwórz pusty plik w folderze programu o nazwie app/config.php, daj serwerowi prawa do zapisu tego pliku. W systemie unix wykonaj polecenie:<br>chmod 777 app/config.php<br> i odśwież okno przeglądarki. .<br>#2: Kliknij polecenie instaluj i utwórz plik konfiguracyjny ręcznie przy pomocy dowolnego edytora tekstów.<br>Program pokaże tekst, który powinieneś umieścić w pliku app/config.php.";
// register:
$lll["registerNoah"]="Zarejestruj";
$lll["notRegistered"]="Nie zarejestrowany"; 
$lll["registerNoahTitle"]="Zarejestruj Noah's Classifieds"; 
$lll["noahAlreadyRegistered"]="Ten produkt jest już zarejestrowany!"; 
$lll["noahRegistrationFalseResponse"]="Wysłanie danych rejestracyjnych na serwer Noah jest w tej chwili niemożliwe. Spróbuj ponownie później!"; 
$lll["noahRegistrationSuccessfull"]="Dziękujemy. Produkt został zarejestrowany!"; 
// update:
$lll["download"]="Pobierz";
$lll["u_maintitle"]="Noah's Classifieds - aktualizacja";
$lll["secure_copy"]="Zaleca się wykonanie kopii bezpieczeństwa aktualizowanej wersji Noah's Classifieds.<br>Skopiuj do niezależnego folderu skopiuj wszystkie pliki wchodzące w skład programu. Dla bezpieczeństwa zapisz również zawartość bazy danych!<br>Kliknij 'OK', aby kontynuować lub 'Anuluj' aby zakończyć proces aktualizacji!";
$lll["ready_to_update"]="Gotowy do aktualizacji bazy danych %s do wersji %s?<br>";
$lll["invalid_version"]="Ta wersja jest błędna: %s";
$lll["updateSuccessful"]="Aktualizacja zakończona z powodzeniem.<br>Wskazówka: Jako administrator kliknij element menu 'Sprawdź', aby zapoznać się ze stanem systemu ogłoszeń!";
$lll["updating"]="Aktualizacja z wersji %s do wersji %s...";
$lll["already_installed"]="Najaktualniejsza wersja %s jest już zainstalowana.";
$lll["picturesDirMustbeWritable"]="Folder '%s' musi pozwalać na zapis przez program, aby dokonać aktualizacji! Aktualizacja zakończyła się niepowodzeniem.";
$lll["updateAutomatic"]="Aktualizuj";
$lll["updateManualZip"]="Ściągnij plik ZIP";
$lll["updateManualTgz"]="Ściągnij plik TGZ";
$lll["downloadFileNotExists"]="Ściągany plik '%s' nie istnieje.";
$lll["updateFailed"]="Aktualizacja nieudana. Program nie ma praw do tworzenia/modyfikowania plików w folderze instalacyjnym.";
$lll["currentVersionIs"]="Obecna wersja to: %s";
$lll["latestVersionIs"]="Najnowsza wersja to: %s";
$lll["noNeedToUpdate"]="Nie ma potrzeby uaktualnienia.";
$lll["checkUpdates"]="Uaktualnienia"; 
$lll["checkUpdatesTitle"]="Sprawdzam stronę Noah's Classifieds w poszukiwaniu aktualizacji"; 
$lll["nopermission"]="Program nie ma praw do zapisu w następujących folderach: %s<br>Użyj polecenia (w systemach Unixowych):<br><i>chmod 777 &lt;nazwa_folderu&gt;</i>";
$lll["nopermission_expl"]="W trakcie działania program Noah's Classifieds musi zapisywać dane w kilku folderach podrzędnych (wczytywanie zdjęć na serwer, zapisywanie napotkanych błędów w pliku log, tworzenie plików cache). Upewnij się, że program ma prawa do zapisu.)";
$lll["backToIndex"]="Powrót do ogłoszeń.";
$lll["onlyFrom1.3"]="Masz wersję, która jest starsza niż 1.3. To uaktualnienie działa wyłącznie z wersją 1.3!";
$lll["cantGetVersionInfo"]="Uzyskanie numeru wersji było niemożliwe. Proces uaktualniania zakończył się niepowodzeniem.";
// checking configuration:
$lll["checkMailtestTitle"]="Wysyłanie wiadomości testowej..."; 
$lll["triggerMailTest"]="Kliknij tu, aby sprawdzić wysyłanie wiadomości email."; 
$lll["unableToConnectNoah"]="Nie można się połączyć z serwerem Noah's. Spróbuj ponownie później!"; 
$lll["itemNumbersRecalculated"]="Numery elementów zostały z powodzeniem przeliczone powtórnie"; 
$lll["dbPrefixExplanation"]="Jeśli Noah's Classifieds musi dzielić bazę danych z innym programem, dobrze jest określić prefiks tabeli, aby uniknąć konfliktu nazw. Proponowany prefix: 'noah_'";
$lll["dbPrefix"]="Prefiks tabeli";
$lll["checkconf"]="Sprawdź";
$lll["mailok"]="Wysyłanie wiadomości testowej zakończyło się powodzeniem. Wkrótce otrzymasz wiadomość na adres %s";
$lll["mailerr"]="W trakcie wysyłania wiadomości testowej pojawiły się następujące błędy:<br>%s";
$lll["here1"]="Kliknij tutaj";
$lll["confpreerr"]="Przed &lt;? w pliku konfiguracyjnym znajdują się zbędne znaki! Usuń je (również znaki nowej linii i spacje)!";
$lll["confposterr"]="Po ?&gt; w pliku konfiguracyjnym znajdują się zbędne znaki! Usuń je (również znaki nowej linii i spacje)!";
$lll["conffileok"]="Plik konfiguracyjny wydaje się być poprawny";
$lll["congrat"]="Gratulacje! Z powodzeniem zainstalowałeś program Noah's Classifieds!";
$lll["confcheck"]="Program sprawdza konfigurację...";
$lll["confdisapp"]="Ukryj tę stronę - chcę zacząć pracę z programem";
$lll["confclicheck"]="Możesz wywołać tę stronę i sprawdzić konfigurację systemu w dowolnym momencie klikając 'Sprawdź' w menu programu.";
$lll["chadmemail"]="Twój obecny adres email to admin@admin.admin. Ustaw ten adres poprawnie po kliknięciu 'Mój profil' w menu programu!";
$lll["chsyspass"]="Twój systemowy adres email nie został jeszcze ustalony. Przejdź do strony konfiguracyjnej klikając 'Ustawienia' w menu programu!";
$lll["chsyspass_expl"]="Program nie może wysyłać powiadomień do czasu, gdy systemowy adres email nie zostanie poprawnie wprowadzony w 'Ustawieniach'! Adres systemowy pojawia się w polu 'Od' i 'Odpowiedz' wysyłanych powiadomień";
$lll["chadmpass"]="Domyślne hasło adminitratora nie zostało jeszcze zmienione! Zmień je w ustawieniach swojego profilu - kliknij 'Mój profil' w menu programu!";
$lll["settings_adminEmail"]="Systemowy email";
$lll["settings_adminEmail_expl"]="Ten adres pojawi się w polu 'Od:' we wiadomościach wysyłanych przez program. Jeśli pozostawisz to pole puste, program może nie być w stanie wysyłać powiadomień!";
$lll["nogd"]="Ostrzeżenie: twój serwer nie ma zainstalowanej biblioteki GD.";
$lll["nogd_expl"]="(Biblioteka GD odpowiada w programach napisanych w PHP za przetwarzanie obrazów - warto zainstalować ją na serwerze. W naszym programie tworzy ona miniatury zdjęć dodawanych do ogłoszeń. Bez GD program nie będzie w stanie wygenerować miniatur przez co, nawet w miejscach gdzie pojawiają się miniatury system będzie musiał wykorzystać zdjęcie pełnej rozdzielczości, przeskalowane 'w locie' do rozmiaru miniatury przez przeglądarkę. Taka metoda oczywiście zadziała, ale nie będzie bardzo nieefektywna  (wyświetlana strona za każdym razem będzie musiała ładować zdjęcie w maksymalnych rozmiarach). )";
$lll["instFileRemove"]="Aby zacząć korzystać z programu musisz usunąć wszystkie pliki instalacyjne (%s).<br><a href='%s'>Kliknij tu, aby je automatycznie usunąć!</a><span class='confexpl'> (Jeśli ta wiadomość nie znika po kliknięciu oznacza to, że program nie ma dostatecznych uprawnień, aby wykasować pliki. Musisz skasować je ręcznie!)</span>";
$lll["appFileRemoveExpl"]="Od wersji 2.3.0, większość z plików php, która znajdowała się w folderze instalacyjnym musi znajdować się w chronionym przez plik htaccess folderze 'app'.
                           W głównym folderze programu mogą się tylko znajdować pliki 'index.php' oraz 'initdir.php'.";
$lll["appFileRemove"]="Aby zacząć korzystać z programu musisz usunąć następujące niepotrzebne pliki php z głównego foldera programu: <span class='confexpl'>%s.</span><br><br><a href='%s'>Kliknij tutaj, aby je automatycznie usunąć!</a><span class='confexpl'> (Jeśli ta wiadomość nie znika po kliknięciu oznacza to, że program nie ma dostatecznych uprawnień, aby wykasować pliki. Musisz skasować je ręcznie!)</span>";
$lll["backupFileRemoveExpl"]="Ze względow bezpieczeństwa folder z zarchiwizowanymi plikami stworzonymi przez skrypt aktualizacyjny prgramu musi być usunięty. Jeśli nadal chcesz przechowywać te pliki umieść je ponad folderem domyślnym w strukturze folderów na serwerze!";
$lll["backupFileRemove"]="Aby zacząć korzystać z programu musisz usunąć następujące zarchiwizowane foldery z foldera instalacyjnego: <span class='confexpl'>%s.</span><br><br><a href='%s'>Kliknij tu, aby je automatycznie usunąć!</a><span class='confexpl'> (Jeśli ta wiadomość nie znika po kliknięciu oznacza to, że program nie ma dostatecznych uprawnień, aby wykasować pliki. Musisz skasować je ręcznie!)</span>";
$lll["systemConfCheck"]="Sprawdzam konfigurację systemu...";
$lll["niceURLFeature"]="'Nice URL':";
$lll["niceURLFeature_1"]="Noah's Classifieds wspiera używanie technologii 'nice URL'. Oznacza to, że link do strony ze szczegółami ogłoszenia może wyglądać w taki sposób:";
$lll["niceURLFeature_2"]="zamiast obecnych rozwiązań:";
$lll["niceURLFeature_3"]="Poza tym, że poprzednia wersja jest ładniejsza, mówi się również, że jest przyjaźniejsza dla wyszukiwarek sieciowych.";
$lll["niceURLFeature_4"]="Aby technologia 'nice URL' mogła zadziałać serwer Apache musi mieć zainstalowany moduł %s. W tej chwili nie można stwierdzić, czy znajduje się on na serwerze (Php jest prawdopodobnie zainstalowane jako CGI binary).";
$lll["niceURLFeature_5"]="Jeśli %s jest już zainstalowany powinieneś stworzyć plik w folderze instalacyjnym Noah's Classifieds o nazwie %s i wstawić tak nastepujący tekst - umożliwi to korzystanie z technologii 'nice URL':";
$lll["niceURLFeature_6"]="Jeśli po wykonaniu tych czynności technologia 'nice URL' nie działa, powinieneś sprawdzić następujące zapisy w pliku konfiguracyjnym Apache:";
$lll["niceURLFeature_7"]="%s anulowanie dla foldera głównego Noah's Classifieds jest aktywne,";
$lll["niceURLFeature_8"]="%s dla foldera instalacyjnego Noah's Classifieds jest aktywne,";
$lll["niceURLFeature_9"]="Aby technologia 'nice URL' mogła działać konieczna jest instalacja modułu %s serwera Apache. Obecnie nie jest on zainstalowany.";
// Product registration:
$lll["reg_companyName"]="Nazwa firmy";
$lll["reg_firstName"]="Imię";
$lll["reg_lastName"]="Nazwisko";
$lll["reg_email"]="Email";
$lll["reg_submit"]="Wyślij";
// RSS feed:
$lll["rss"]="RSS";
$lll["rss_modify_form"]="Edytuj kanał RSS";
$lll["rss_language"]="Język";
$lll["rss_link"]="Link";
$lll["rss_link_expl"]="Adres URL strony z ogłoszeniami - np.: http://twojastrona.pl/ogloszenia";
$lll["rss_descField"]="Pole opisowe";
$lll["rss_descField_expl"]="Indeks pola, które służy jako 'Opis' danego ogłoszenia w kanale RSS. Podczas typowej instalacji Noah's' Classifieds jest to pierwsze pole. Jeśli nie masz takiego pola ustaw je na '0', a opis ogłoszenia nie będzie się pojawiał w kanale RSS.";
//globalsettings
$lll["settings"]="settings";
$lll["settings_modify_form"]="Zmień ustawienia";
$lll["settings_expNoticeBefore"]="Na ile dni przed wygaśnięciem ważności ogłoszenia użytkownik musi zostać poinformowany?";
$lll["settings_charLimit"]="Maksymalna liczba znaków jaką może mieć post";
$lll["settings_charLimit_expl"]="'0' oznacza brak ograniczeń.";
$lll["settings_blockSize"]="Liczba ogłoszeń wyświetlanych na stronie";
$lll["settings_maxPicSize"]="Maksymalna wielkość zdjęcia w bajtach";
$lll["settings_maxPicWidth"]="Maksymalna szerokość zdjęcia w pikselach";
$lll["settings_maxPicHeight"]="Maksymalna wysokość zdjęcia w pikselach";
$lll["settings_maxPicSize_expl"]=$lll["settings_maxPicWidth_expl"]=$lll["settings_maxPicHeight_expl"]="'0' oznacza brak ograniczeń.";
$lll["settings_adminFromName"]="Nazwa systemu";
$lll["settings_adminFromName_expl"]="Zawartość tego pola pojawi się jako nazwa nadawcy w polu 'Od' w emailowych powiadomieniach jakie wysyła system.";
$lll["settings_versionFooter"]="Stopka - numer wersji";
$lll["settings_titlePrefix"]="Prefiks tytułu"; 
$lll["settings_dateFormat"]="Format daty"; 
$lll["settings_dateFormat_expl"]="Aby uzyskać więcej informacji i przykłady formatu zapisu daty, <a href='http://php.net/manual/en/function.date.php' target='_blank'>kliknij tu</a>"; 
// Changed in version 3.0.0. Old text:
//$lll["settings_enableFavorities"]="Enable the 'Add to favorities' feature";
// New text:
//$lll["settings_enableFavorities"]="Enable the 'Add to favorities' feature for";
$lll["settings_enableFavorities"]="Enable the 'Add to favorities' feature for";
$lll["settings_enableFavorities_expl"]="To ustawienie nie zostanie zapisane w darmowej wersji programu!"; 
$lll["settings_updateCheckInterval"]="Sprawdzaj czy są dostępne aktualizację"; 
$lll["settings_updateCheckInterval_expl"]="System może sprawdzać dostępność aktualizacji programu i, kiedy pojawi się nowa wersja, pokazać na stronie administracyjnej odpowiedni komunikat. Wartość wprowadzona w tym polu określa co ile dni program ma sprawdzać dostępność aktualizacji. Jeśli chcesz dezaktywować tę funkcję wprowadź liczbę '0'!"; 
$lll["mailProperties"]="Właściwości wysyłania"; 
$lll["themeProperties"]="Motywy graficzne"; 
$lll["settings_defaultTheme"]="Domyślny motyw graficzny"; 
$lll["settings_allowedThemes"]="Dozwolone motywy graficzne"; 
$lll["settings_allowedThemes_expl"]="Jeśli utworzysz nowy folder podrzędny w 'motywach graficznych' zawierający pliki źródłowe motywu - np. 'moj_nowy_motyw', pokaże się on automatycznie na tej liście jako nowy element 'Moj nowy motyw'!"; 
$lll["settings_allowSelectTheme"]="Pozwól innym użytkownikom na zmianę motywu"; 
$lll["settings_allowSelectTheme_expl"]="Jeśli zaznaczysz tę opcję na stronach systemu pojawi się rozwijalna lista, która pozwala na natychmiastową zmianę motywu graficznego."; 
$lll["languageProperties"]="Języki"; 
$lll["settings_defaultLanguage"]="Język domyślny"; 
$lll["settings_allowedLanguages"]="Dozwolone języki"; 
$lll["settings_allowSelectLanguage"]="Pozwól użytkownikom zmieniać język"; 
$lll["settings_allowSelectLanguage_expl"]="Jeśli ta opcja jest zaznaczona, na stronach serwisu pojawi się rozwijalna lista, która umożliwia nastychmiastową zmianę języka interfejsu."; 
$lll["settings_smtpServer"]="Nazwa serwera SMTP"; 
$lll["settings_smtpServer_expl"]="Użyj poniższych pó jeśli chcesz, aby system wysyłał powiadomienia mailem przez serwer SMTP. W przeciwnym razie wkorzystane zostanie obsługa poczty wbudowana w PHP."; 
$lll["settings_smtpUser"]="Nazwa użytkownika SMTP"; 
$lll["settings_smtpPass"]="Hasło do serwera SMTP"; 
$lll["settings_fallBackNative"]="Wróć do obsługi poczty przy pomocy PHP jeśli serwer SMTP zawiedzie"; 
$lll["settings_titlePrefix_expl"]="Ten tekst pojawi się przed tytułem strony w przeglądarce. Możesz tu wpisać np. nazwę swojej strony."; 
$lll["seoProperties"]="Optymalizacja wyszukiwarki"; 
$lll["settings_mainTitle"]="Znacznik meta 'TITLE'"; 
$lll["settings_mainTitle_expl"]=

"Zawartość meta-znaczników TITLE, DESCRIPTION oraz KEYWORDS zależy od wyświetlanej kategorii ogłoszeń/aktualnie wyświetlanego ogłoszenia. Administrator może ją określić dla kategorii, a użytkownicy dla poszczególnych ogłoszeń. Zawartość wprowadzona do poniższych trzech pól będzie domyślnie wykorzystana, gdy strona nie jest kategorią, ani nie jest wyświetlana w kontekście ogłoszenia (np. strona początkowa)."; 
$lll["settings_mainDescription"]="Znacznik meta - 'DESCRIPTION'"; 
$lll["settings_mainKeywords"]="Znacznik meta - 'KEYWORDS'"; 
$lll["settings_helpLink"]="Adres wywoływany po kliknięciu elementu 'Pomoc'";
$lll["settings_helpLink_expl"]="Pełny adres (URL) do strony z plikiem pomocy. Dzięku niemu możliwe jest zdefiniowanie własnego pliku pomocy. Np. http://twojadomena/ogloszenia/pomoc.html";
$lll["settings_maxMediaSize"]="Maksymalna rozmiar wgrywanego pliku w bajtach.";
$lll["settings_maxMediaSize_expl"]="'0' oznacza brak limitów.<br><br>Uwaga! Bez względu na wartość wpisaną do tego pola dwa z wielu ustawień PHP ograniczają maksymalny rozmiar pliku wysyłanego na serwer: 'upload_max_filesize' oraz 'post_max_size'. Wartości tych zmiennych mogą byc ustawione albo w pliku 'php.ini', albo w pliku 'httpd.conf', albo w pliku '.htaccess' (dotyczą wówczas folderu, w którym znajduje się plik). Ustawienia domyślne to 2MB. Można zwiększyć ten limit do np. 50MB przez zmianę pliku .htaccess w następujący sposób:<br><br>php_value upload_max_filesize \"50M\"<br>php_value post_max_size \"50M\" ";
// Changed in version 3.0.0. Old text:
//$lll["settings_subscriptionType"]="Auto notify";
// New text:
//$lll["settings_subscriptionType"]="Enable auto notify for";
$lll["settings_subscriptionType"]="Enable auto notify for";
$lll["settings_subscriptionType_expl"]="Użytkownicy systemu mogą zgłosić chęć otrzymywania automatycznych powiadomień o nowo dodanych ogłoszeniach w danej kategorii.<br><br>Ta funkcja jest zablokowana w darmowej wersji programu!";
$lll["settings_menuPoints_expl"]="Jeśli element 'Dodaj ogłoszenie' nie będzie zaznaczony, widoczny będzie wyłącznie dla administratora (tylko administrator będzie mógł dodawać ogłoszenia). Elementy menu mogą być usuwane, a ich porządek zmieniany przez prostą edycję odpowiednich ustawień w pliku 'layout.tpl.php'!";
$lll["settings_menuPoints"]="Elementy menu";
$lll["settings_menuPoints_".Settings_showLogout]="Wyloguj się";
$lll["settings_menuPoints_".Settings_showLogin]="Zaloguj się";
$lll["settings_menuPoints_".Settings_showRegister]=$lll["registerNoah"];
$lll["settings_menuPoints_".Settings_showMyProfile]="Mój profil";
$lll["settings_menuPoints_".Settings_showMyAds]="Moje ogłoszenia";
$lll["settings_menuPoints_".Settings_showSubmitAd]="Dodaj ogłoszenie";
$lll["settings_menuPoints_".Settings_showRecentAds]="Ostatnio dodane";
$lll["settings_menuPoints_".Settings_showMostPopularAds]="Popularne";
$lll["settings_menuPoints_".Settings_showSearch]="Szukaj";
$lll["settings_menuPoints_".Settings_showHome]="Strona główna";
$lll["settings_menuPoints_".Settings_displayHelp]="Pomoc";
$lll["menuPointsSep"]="Modyfikacja układu strony";
$lll["expirationProperties"]="Wygasanie ważności ogłoszeń";
$lll["imageProperties"]="Ograniczenia wielkości plików";
$lll["otherProperties"]="Inne ustawienia";
$lll["adDisplayProperties"]="Ustawienia dotyczące wyświetlania ogłoszeń";
$lll["settings_renewal"]="Ile razy użytkownik może przedłużyć ważność swojego ogłoszenia";
$lll["settings_allowModify"]="Użytkownik ma prawo edytować swoje ogłoszenia";
$lll["settings_extraHead"]="Dodatkowa zawartość sekcji HEAD";
$lll["settings_extraHead_expl"]="Przy pomocy tego pola możesz umieścić kod HTML przed znacznikiem zamykającym sekcję HEAD stron wyświetlanych w systemie. W tym miejscu możesz na przykład dołączyć dodatkowe arkusze CSS lub skrypty JavaScript.<br><br>Ta funkcja jest zablokowana w darmowej wersji programu!";
$lll["settings_extraBody"]="Dodatkowa zawartość sekcji BODY";
$lll["settings_extraBody_expl"]="Przy pomocy tego pola możesz wprowadzać dowolny kod HTML, który zostanie dołączony po otwierającym znaczniku BODY. Możesz, na przykład, umieścić baner, który ukaże sie w górnej części strony, ponad zawartością generowaną przez system.<br><br>Ta funkcja jest zablokowana w darmowej wersji programu!";
$lll["settings_extraTopContent"]="Dodatkowa zawartość pod nagłówkiem strony";
$lll["settings_extraTopContent_expl"]="Przy pomocy tego pola możesz umieścić dowolny kod HTML poniżej sekcji nagłówka każdej ze stron (poniżej paska stanu i menu).<br><br>Ta funkcja jest zablokowana w darmowej wersji programu!";
$lll["settings_extraBottomContent"]="Dodatkowa zawartość nad stopką strony";
$lll["settings_extraBottomContent_expl"]="Przy pomocy tego pola możesz umieścić dowolny kod HTML ponad stopką strony generowaną przez system.<br><br>Ta funkcja jest zablokowana w darmowej wersji programu!";
$lll["settings_extraFooter"]="Dodatkowa zawartość stopki strony";
$lll["settings_extraFooter_expl"]="Przy pomocy tego pola możesz umieścić dodatkowy kod HTML przed zamykającym stronę znacznikiem BODY.<br><br>Ta funkcja jest zablokowana w darmowej wersji programu!";
$lll["securityProperties"]="Bezpieczeństwo systemu";
$lll["settings_applyCaptcha"]="Zastosuj graficzną weryfikację użytkownika (CAPTCHA) w następujących formularzach";
$lll["settings_applyCaptcha_".Settings_response]="'Odpowiedz na ten wpis' oraz 'Wyślij informację do znajomego'";
$lll["settings_applyCaptcha_".Settings_login]="Formularz logowania";
$lll["settings_applyCaptcha_".Settings_register]="Formularz rejestracyjny";
$lll["settings_applyCaptcha_".Settings_submitAd]="Dodawanie ogłoszeń";
$lll["settings_showEmail_".customfield_forNone]="nikomu";
$lll["settings_showEmail_".customfield_forAll]="wszystkim";
$lll["settings_showEmail_".customfield_forLoggedin]="tylko zalogowanym użytkownikom";
$lll["settings_showEmail_".customfield_forAdmin]="tylko administratorowi";
// Custom Fields
$lll["customfield"]="Pole użytkownika";
$lll["mustBeCommaSeparated"]="W polach zawierających listę poszczególne wartości muszą być zdefiniowane jako łańcuchy tekstowe oddzielone przecinkiem";
$lll["invalidDefaultValue"]="Wartość domyślna w polach pozwalających na wybór z listy musi odpowiadać jednemu z łańcuchów tekstowych umieszczonych na liście wartości, które może przymować dane pole.";
$lll["descriptionDefaultLabel"]=$lll["description"]="Opis";
$lll["privateField"]="Prywatne";
$lll["customfield_type"."_".customfield_text]="Tekst";
$lll["customfield_type"."_".customfield_textarea]="Pole tekstowe (textarea)";
$lll["customfield_type"."_".customfield_bool]="Pole opcji";
$lll["customfield_type"."_".customfield_selection]="Lista wyboru";
$lll["customfield_type"."_".customfield_multipleselection]="Wielokrotny wybór";
$lll["customfield_type"."_".customfield_separator]="Separator";
$lll["customfield_type"."_".customfield_checkbox]="Pole wyboru";
$lll["customfield_type"."_".customfield_picture]="Grafika";
$lll["customfield_type"."_".customfield_media]="Plik multimedialny";
$lll["customfield_type"."_".customfield_url]="Link";
$lll["customfield_type"."_".customfield_date]="Data";
$lll["customfield_dateDefaultNow"]="Datą domyślną jest data bieżąca";
$lll["customfield_fromyear"]="Od roku";
$lll["customfield_fromyear_expl"]="Zakres dat wypełniający kontrolkę kalendarza będzie zaczynał się do tego roku. 
                                   Możesz wprowadzić rzeczywistą wartość liczbową np. '1971', lub wpisać 'now' (=teraz), która zastąpi bieżący rok.
                                   Możesz wprowadzić również wartość względną np. 'now-5' (=teraz-5) - pierwsze data kalendarza będzie ustalona dokładnie na pięć lat przez datą bieżącą!";
$lll["customfield_toyear"]="Do roku";
$lll["customfield_toyear_expl"]="Zakres dat kontrolki będzie kończył się na wybranym roku. 
                                   Możesz wprowadzić rzeczywistą wartość liczbową np. '2010', lub wpisać 'now' (=teraz), która zastąpi bieżący rok.
                                   Możesz wprowadzić również wartość względną np. 'now+5' (=teraz+5) - ostatnia data kalendarza będzie ustalona dokładnie na pięć lat w przyszłości!";
$lll["customfield_name"]="Nazwa";
$lll["customfield_type"]="Typ";
$lll["customfield_type"."_expl"]="Uwaga: aby uniknąć konfliktu typów jeśli kiedykolwiek aktywizujesz tę kolumnę i będą znajdowały się w niej jakieś wpisy, nie będziesz mógł jej zmienić. Jeśli będziesz chciał mimo wszystko dokonać zmiany, będziesz musiał usunąć wszystkie elementy z tej kategorii.";
$lll["customfield_default_bool"]=
$lll["customfield_default_text"]=
$lll["customfield_default_multiple"]="Wartość domyślna";
$lll["customfield_active"]="Aktywna";
$lll["customfield_separator"]="Kolumna %s";
$lll["customfield_mandatory"]="Pole obowiązkowe";
// Changed in version 3.0.0. Old text:
//$lll["customfield_showInList"]="Appears in list";
// New text:
//$lll["customfield_showInList"]="Show in lists for";
$lll["customfield_showInList"]="Show in lists for";
$lll["customfield_values"]="Możliwe wartości";
$lll["customfield_innewline"]="Umieść w nowej linii";
$lll["customfield_displayLabel"]="Wyświetlana etykieta";
$lll["customfield_displayLabel_expl"]="Jeśli to pole będzie nie będzie zaznaczone opis edytowanego pola nie będzie się pojawiał na stronie ogłoszenia, a zawartość pola będzie rozciągała się ponad opisy innych pól.";
$lll["customfield_displaylength"]="Długość listy ogłoszeń";
$lll["customfield_displaylength"."_expl"]="Maksymalna liczba znaków, które pojawiają się na liście ogłoszeń. Dzięki temu ustawieniu można chronić Wygląd listy przed nadmiernie długimi wpisami.";
// Changed in version 3.1.0. Old text:
//$lll["customfield_searchable"]="Searchable";
// New text:
$lll["customfield_searchable"]="Show in the search form for";
$lll["customfield_searchable"."expl"]="Jeśli to pole jest zaznaczone, użytkownicy mogą przeszukiwać system przy wykorzystaniu tego atrybutu wykorzystujące do tego celu zakresy liczbowe np.'10-20'";
$lll["customfield_rangeSearch"]="Pozwól na wyszukiwanie wg zakresu";
// Changed in version 3.1.0. Old text:
//$lll["customfield_rangeSearch_expl"]="If this is checked than one can define e.g. '10-20' as a search condition to search for ads where the value of this field is between 10 and 20.";
// New text:
$lll["customfield_rangeSearch_expl"]="If this is checked than one can define e.g. '10-20' as a search condition to search for ads where the value of this field is between 10 and 20. Or one can enter a range of dates in case of Date fields.";
$lll["customfield_allowHtml"]="Pozwól na wykorzystanie HTML";
$lll["customfield_allowHtml_expl"]="Zaznaczenie tego pola pozwala na używanie wyłącznie 'bezpeicznych' znaczników HTML! Niektóre znaczniki, które mogłyby spowodować zagrożenie bezpieczeństwa lub zburzyć układ stron są zakazane.";
$lll["customfield_private"]="Pozwól na prywatne";
$lll["customfield_subType"]="Traktuj zawartość tego pola jak";
$lll["customfield_subType_expl"]="Np. jeśli masz pole o nazwie 'Cena', dobrze jest ustawić je jako 'Liczbę zmiennoprzecinkową', tak aby sortowanie wg kolumny 'Cena' i przeszukiwanie zakresu cenowego mogło działać poprawnie. W sekcji 'Pokaż format' możesz wprowadzić odpowiedni symbol waluty, ustawić liczbę miejsc po przecinku i separator tysięcy.";
$lll["customfield_subType_".customfield_alnum]="Tekst";
$lll["customfield_subType_".customfield_integer]="Liczba całkowita";
$lll["customfield_subType_".customfield_float]="Liczba zmiennoprzecinkowa";
$lll["customfield_sortable"]="Pozwól na sortowanie wg tego pola";
$lll["customfield_expl"]="Wyjaśnienie";
$lll["customfield_expl"."_expl"]="Tekst pomocy podobny do tego, który czytasz! Bardziej szczegółowy opis pola formularza.";
$lll["private_field"]="(private)";
$lll["customfield_newitem"]="Dodaj nowe pole użytkownika";
$lll["customfield_modify_form"]="Edytuj pole użytkownika";
$lll["customfield_create_form"]="Utwórz pole użytkownika";
$lll["customfield_sortId"]="Posortuj";
$lll["customfield_sorthelp"]="Użyj strzałek w kolumnie 'Posortuj', aby zmienić porządek listy, a następnie kliknij przycisk 'Zapisz parametry sortowania' pod tabelą!";
$lll["customfield_savesorting"]="Zapisz parametry sortowania";
$lll["customfield_sortingsaved"]="Sortowanie według pola użytkownika zostało zapisane.";
// Changed in version 3.0.0. Old text:
//$lll["customFields"]="List of custom fields of this category";
// New text:
//$lll["customFields"]="List of custom fields";
$lll["customFields"]="List of custom fields";
$lll["customfield_rowspan"]="Objemuje wiele rzędów";
$lll["customfield_seo"]=$lll["seoProperties"];
$lll["customfield_seo_0"]="Brak przypisania";
$lll["customfield_seo_".customfield_title]="Wykorzystaj to pole jako tytuł (TITLE) ogłoszenia";
$lll["customfield_seo_".customfield_description]="Wykorzystaj to pole jako opis (DESCRIPTION) ogłoszenia";
$lll["customfield_seo_".customfield_keywords]="Wykorzystaj to pole jako słowa kluczowe (KEYWORDS) ogłoszenia";
// Changed in version 3.0.0. Old text:
//$lll["customfield_mainPicture"]="Use this field as the main picture of the ad";
// New text:
//$lll["customfield_mainPicture"]="Use this field as the main picture";
$lll["customfield_mainPicture"]="Use this field as the main picture";
$lll["customfield_mainPicture_expl"]="Aby wykorzystać to zdjęcie w listach bez określonej kategorii i RSS.";
$lll["customfield_seo_expl"]="Możesz w tym miejscu określić, które z pól użytkownika przypisanych do tego ogłoszenia będą stanowiły treść znaczników TITLE, DESCRIPTION oraz KEYWORDS. 
                              Poza możliwością lepszego pozycjonowania stron (SEO) zawartość znacznika TITLE będzie pokazywała się w tytule okna przeglądarki w trakcie wyślwietlania ogłoszenia. Będzie również używane jako tytuł ogłoszenia na listach bez określonej kategorii oraz w kanałach RSS.";
$lll["customfield_innewline_expl"]="Zamiast tworzenia nowej kolumny ten parametr decyduje o wyświetleniu zawartości nowego pola użytkownika w nowej linii, która obejmuje wszystkie pozostałem kolumny w poziomie i umieszczona jest pod nimi.";
$lll["customfield_rowspan_expl"]="Używaj tego parametru wraz z 'Umieść w nowej linii' innych pól użytkownika. Jeśli nie ma innych pól, które zostały umieszczone w nowej linii, możesz przy pomocy tego ustawienia osiągnąć efekt rozciągnięcia tego pola pionowo tak aby objęło ono nowe linie.";
$lll["customfield_detailsPosition"]="Pozycja";
$lll["customfield_detailsPosition_expl"]="Umieszczenie pól na stronie ogłoszenia. Kolumna boczna jest dobrym miejscem na panel ze zdjęciami (gdy wybrany jest temat: nowoczesny). Przy pomocy tych ustawień możesz umieścić te pola ponad obszarem zdjęcia, albo poniżej.";
$lll["customfield_detailsPosition_".customfield_normal]="Normal";
$lll["customfield_detailsPosition_".customfield_topright]="Górna część kolumny bocznej";
$lll["customfield_detailsPosition_".customfield_bottomright]="Dolna część kolumny bocznej";
$lll["formProperties"]="Ustawienia formularza";
$lll["listProperties"]="Ustawienie listy";
$lll["detailsProperties"]="Ustawienia strony prezentacji ogłoszenia";
$lll["searchProperties"]="Ustawienia funkcji 'szukaj'";
$lll["miscProperties"]="Rozmaite ustawienia";
$lll["customfield_showInDetails"]="Widoczne dla";
$lll["customfield_showInDetails_".customfield_forNone]="nikogo";
$lll["customfield_showInDetails_".customfield_forAll]="wszystkich";
$lll["customfield_showInDetails_".customfield_forLoggedin]="zalogowanych użytkowników";
$lll["customfield_showInDetails_".customfield_forOwner]="właściciela ogłoszenia";
$lll["customfield_showInDetails_".customfield_forAdmin]="wyłącznie administratora";
$lll["formatSection"]="Pokaż formatowanie";
$lll["customfield_formatPrefix"]="Prefiks";
$lll["customfield_formatPrefix_expl"]="Typowe zastosowania to symbol waluty lub znak procent. Każda wprowadzona w tym polu wartość będzie poprzedzona wybranym symbolem.";
$lll["customfield_formatPostfix"]="Sufiks";
$lll["customfield_formatPostfix_expl"]="Np. możesz dodać do liczb jednostki. Cokolwiek tu wprowadzisz pojawi się po wartościach liczbowych tego pola użytkownika.";
$lll["customfield_precision"]="Precyzja";
$lll["customfield_precision_expl"]="Ustaw liczbę miejsc po przecinku.";
$lll["customfield_precisionSeparator"]="Separator";
$lll["customfield_precisionSeparator_expl"]="Ustawia separator dla oddzielenia wartości dziesiętnych";
$lll["customfield_thousandsSeparator"]="Separator tysięcy";
$lll["customfield_format"]="Parametry wyświetlania";
$lll["customfield_format_expl"]="Użytkownicy zaawansowani mogą wykorzystać łańcuch formatujący w stylu języka C (sprintf).";
$lll["customfield_useMarkitup"]="Wykorzystaj wbudowany edytor HTML zamiast zwykłego pola tekstowego";
// Notifications:
$lll["notification"]="powiadomienie";
$lll["Notifications"]=$lll["notification_ttitle"]="Powiadomienia";
$lll["notification_subject"]="Temat wiadomości";
$lll["notification_body"]="Treść wiadomości";
$lll["notification_variables"]="Dozwolone zmienne";
$lll["notification_active"]="Aktywne";
$lll["notification_modify_form"]="Zmień powiadomienia";
$lll["notif_remindpass_tit"]="Zawiera nowe hasło jeśli użytkownik zapomniał dotychczasowe.";
$lll["notif_remindpass_subj"]="Nowe hasło";
$lll["notif_initpass_tit"]="Wysłane do użytkownika po rejestracji, zawiera początkowe hasło";
$lll["notif_initpass_subj"]="Początkowe hasło";
$lll["notification_cc"]="Adres DW (do wiadomości)";
$lll["notification_cc_expl"]="Podaj adres email, na który mają być kopiowane zawiadomienia.";
$lll["notification_active_expl"]="Tu możesz wyłączyć wysyłanie tego zawiadomienia.";
//Category:
$lll["category_expirationEnabled"]="Ogłoszenia mogą mieć datę ważności";
$lll["category_expirationOverride"]="Zezwól na nie uwzględnianie daty ważności dla";
$lll["category_allowSubmitAdAdmin"]="Tylko administrator może dodawać ogłoszenia";
$lll["category_expirationOverride_expl"]="Jeśli zaznaczysz to pole wówczas w formularzu tworzenia/edycji ogłoszenia pojawi się opcja 'Domyślna liczba dni do wygaśnięcia ważności ogłoszenia'. Właściciel może podać dowolną wartość liczbową. Jeśli w tym polu wpiszesz wartość '0', właściciel może ustalić dowolną liczbę dni. Jeśli podasz jakąkolwiek wartość większą od zera posłuży ona za wartość domyślną oraz, jednocześnie, wartość maksymalną, która może ustawić użytkownik.";
$lll["category_expirationOverride_".customfield_forNone]="Nikt";
$lll["category_expirationOverride_".customfield_forLoggedin]="Wszyscy użytkownicy";
$lll["category_expirationOverride_".customfield_forAdmin]="Tylko administrator";
$lll["category_organize"]="Zmień układ kategorii";
$lll["exp"]="Wygasa?";
$lll["useDragAndDrop"]="Użyj myszki, aby przeciągać kategorię. Aby zatwierdzić nowy porządek kliknij 'Zachowaj układ'!";
$lll["organizeSaveButton"]="Zachowaj układ";
$lll["organizeSaveMessage"]="Układ kategorii został z powodzeniem zapisany";
$lll["organizeSaveError"]="Nie można wysłać danych na serwer.";
$lll["organizeLoadError"]="Nie można pobrać danych z serwera.";
?>