<?php
defined('_NOAH') or die('Restricted access');
if( !isset($gorumdetailstemplate) ) $gorumdetailstemplate = "default_details.tpl.php";

class DetailsPresentation extends Presentation
{
    
var $zebraDetails;

function DetailsPresentation(&$base)
{
    $this->Presentation($base, "details");  
    $this->zebraDetails = G::getSetting($this->typ, "zebraDetails" );
}

function processContent(&$tpl)
{
    global $lll,$gorumroll,$list2Colors;
    
    $tpl->zebraDetails = $this->zebraDetails;
    $tpl->listAndMethod = "$gorumroll->list-$gorumroll->method";
    $tpl->detailsMethods = "";
    $class = $this->base->get_class();
    $attrs=$this->typ["attributes"];
    $this->base->hasGeneralRights($rights);
    $attributeList = isset($this->typ["order"]) ?
                     $this->typ["order"] : array_keys($this->typ["attributes"]);
    $tpl->headerMethods=array();
    if( $s=$this->base->showModTool($rights) ) $tpl->headerMethods[]=$s;
    if( $s=$this->base->showDelTool($rights) ) $tpl->headerMethods[]=$s;

    $lllGlobProp =& new LllGlobalProperties( $this->base );
    $tpl->title = sprintf($lll["detail_info"],ucfirst($lllGlobProp->getLabel()));
    
    $tpl->rows = array();
    foreach( $attributeList as $attr )
    {
        $val = & $this->typ["attributes"][$attr];
        if ( in_array("details",$val) )
        {
            if( in_array("section",$val) )
            {
                if( isset($lll[$attr]) )$tpl->rows[$attr]=array("separator"=>$lll[$attr]);
            }
            elseif( in_array("widecontent_details",$val) )
            {
                if( !($valTxt=$this->base->showListVal($attr)) ) $valTxt="&nbsp;";
                $tpl->rows[$attr]=array("widecontent"=>$valTxt);
            }
            elseif( in_array("notable",$val) )
            {
                $valTxt=$this->base->showListVal($attr);
                $tpl->rows[$attr]=array("notable"=>$valTxt);
            }
            else
            {
                $lllProp =& new LllProperties( $this->base, $attr );
                $txt = $lllProp->getLabel();
                if( !($valTxt=$this->base->showListVal($attr)) ) $valTxt="&nbsp;";
                $tpl->rows[$attr]=array("label"=>$txt, "value"=>$valTxt);
            }    
        }
    }
}

} // end class
?>
