<?php defined('_NOAH') or die('Restricted access'); ?>
Gyakran ismételt kérdések (példaoldal)
