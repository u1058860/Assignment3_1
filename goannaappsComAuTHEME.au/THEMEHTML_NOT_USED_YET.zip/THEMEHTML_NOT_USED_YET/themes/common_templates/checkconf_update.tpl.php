<?php defined('_NOAH') or die('Restricted access'); ?>
<div id='checkconf'>
  <h1><?php echo $this->get("checkTitle") ?></h1>
  <?php foreach($this->get("report") as $report): ?>
    <p class='<?php echo $report[1] ?>'><?php echo $report[0] ?></p>
  <?php endforeach; ?>
  <?php if( $this->get("releaseNotes") ): ?>
    <br>
    <div id='releaseNotes'>
      <?php echo $this->get("releaseNotes") ?>
    </div>
  <?php endif; ?>
  <?php if( $this->get("updateAutomatic") ): ?> 
    <br>
    <br>
    <h1>You can choose from two different methods to perform the update. 
    The following table is an overview of the steps each one requires and a comparision of the pros and cons of them:</h1>
    <table class='chart'>
      <tr>
        <td class='label' style='text-align: center'>Automatic update</td><td class='label' style='text-align: center'>Manual update</td>
      </tr>
      <tr>
        <td>
          <p class='confok'>Steps of the update:</p>        
          <p class='confexpl'>
            <ol>
              <li>You click on the below 'Update' button,</li>
              <li>The program checks whether it may modify the files it must update. 
              If it has no write permission, it lists all the files it must be able to modify, and stops. In this case you must grant enough
              permission to write these files and restart the update,</li>
              <li>The program lists all the files it is about to modify or delete during the update</li>
              <li>You accept this by clinking on an other button</li>
              <li>The program makes a backup copy of the old files (if you happened to altered some of them (e.g. template files),
              this gives you a chance that you later "merge" your changes into the new files!)</li>
              <li>The program unpacks the new files and performs the necessary database changes, too. This completes the update process.</li>                
            </ol>
          </p>    
        </td>
        <td>
          <p class='confok'>Steps of the update:</p>        
          <p class='confexpl'>
            <ol>
              <li>You click on one of the below 'Download' buttons,</li>
              <li>You save the update package (either the zip, or the tgz format - your choice) on your local computer,</li>
              <li>You unpack the update package,</li>
              <li>You upload the content of the update package to your server overwriting with it the old files of your Noah's Classifieds installation,</li>
              <li>You click on any link in Noah's Classifieds - 
              the program detects automatically that it has new files and redirects you to an update page,</li>
              <li>You click on 'go ahead' there and the program performs the necessary database update. With this, the whole update process is completed.</li>                
            </ol>
          </p>    
        </td>
      </tr>  
      <tr>
        <td class='label' style='text-align: center' colspan='2'>Comparision, pros and cons:</td>
      </tr>
      <tr>
        <td style='text-align: justify'>If the program has write access to the files/directories it must update, this can be the easiest method - just two clicks and it's ready.</td>
        <td style='text-align: justify'>This involves more manual steps, but works always - regardless from the file permissions</td>
      </tr>
      <tr>
        <td style='text-align: justify'>If the program complains about the missing write permissions and you once give it write permission to all the files of the Noah's installation (simply giving 777 permission to all),
        You need not do this any more and any future automatic updates will be easy and smooth,</td>
        <td style='text-align: justify'>Any other future manual updates will have always the same steps</td>
      </tr>
      <tr>
        <td style='text-align: justify'>The program itself makes a backup copy of the files it overwrites or deletes during the update.</td>
        <td style='text-align: justify'>You must make a backup copy of the old files yourself, before you overwite them with the content of the update package - 
        at least this is highly recommended</td>
      </tr>
      <tr>
        <td style='text-align: justify'>If you give the program full write permission to the source files, it is though very comfortable, 
        but also considered to be less secure (whether one worry about this, it is a question of personal taste and the personal level of paranoia). 
        Of course you can do that you only grant write permission right before the update and reset the permissions to a more secure level after the update, but with this, just the comfort level of the automatic update will be lost.</td>
        <td style='text-align: justify'>The program needs to have a write permission to only those few directories it anyway must be able to write. This is more secure.</td>
      </tr>
      <tr>
        <td>
          <form method='post' action='index.php'>
            <input type='hidden' name='list' value='checkconf'>
            <input type='hidden' name='method' value='do_update'>
            <p class='confok'>Click here to update to <?php echo $this->get("latestVersion") ?>:</p>
            <input class='updateButton' type='submit' name='automatic' value='<?php echo $this->get("updateAutomatic") ?>'>
          </form>
        </td>
        <td>
          <form method='post' action='index.php'>
            <input type='hidden' name='list' value='checkconf'>
            <input type='hidden' name='method' value='do_update'>
            <p class='confok'>Click here to download the update in ZIP format:</p>
            <input class='updateButton'  type='submit' name='manualZip' value='<?php echo $this->get("updateManualZip") ?>'><br>
            <p class='confok'>Click here to download the update in TGZ format:</p>
            <input class='updateButton'  type='submit' name='manualTgz' value='<?php echo $this->get("updateManualTgz") ?>'>
          </form>
        </td>
      </tr>
    </table>  
  <?php endif; ?>
  <?php if( $this->get("branch")!="RSS" ): ?> 
    <br><br><br>
    <h1>You are currently using the <?php echo $this->get("branch") ?> version of the program.</h1>
    <p class='confexpl'>This is an overview of the benefits of upgrading your program to the RSS version:</p>
    <table class='chart'>
      <tr>
        <td class='label'>Features</td><td><b>Free</b></td><td><b>RSS</b></td>
      </tr>
      <tr>
        <td class='label'>RSS feed<br>
        <p class='confexpl'>Noah's Classifieds can generate RSS feeds that can highly improve the marketing possibilities of your site. 
        It displays the list of latest ads in the feed, which people can insert in their news reader for example.</p>
        </td><td></td><td>Yes</td>
      </tr>  
      <tr>
        <td class='label'>Powered footer customization<br>
        <p class='confexpl'>The "Powered by..." footer text can be customized from the admin interface.</p>
        </td><td></td><td>Yes</td>
      </tr>
      <tr>
        <td class='label'>Category organizer<br>
        <p class='confexpl'>Possibility to change the order of categories and reorganize them completely with a drag-and-drop interface.</p>
        </td><td></td><td>Yes</td>
      </tr>
      <tr>
        <td class='label'>Category cloning<br>
        <p class='confexpl'>Making copies of categories with all their properties and custom fields</p>
        </td><td></td><td>Yes</td>
      </tr>
      <tr>
        <td class='label'>Featured ads display<br>
        <p class='confexpl'>The automatic display of the featured ads list (or any other admin configured custom lists) in various areas of the Noah's pages.</p>
        </td><td></td><td>Yes</td>
      </tr>
      <tr>
        <td class='label'></td><td></td>
        <td><?php if( $this->get("branch")!="RSS" ) echo "<a href='http://www.noahsclassifieds.org' target='_blank'>Click here to get RSS!</a>"; ?></td>
      </tr>
    </table>  
  <?php endif; ?>
</div>
