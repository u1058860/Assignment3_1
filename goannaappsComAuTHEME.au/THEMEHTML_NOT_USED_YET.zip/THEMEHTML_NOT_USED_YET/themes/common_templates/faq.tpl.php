<?php defined('_NOAH') or die('Restricted access'); ?>
This is an example FAQ page
