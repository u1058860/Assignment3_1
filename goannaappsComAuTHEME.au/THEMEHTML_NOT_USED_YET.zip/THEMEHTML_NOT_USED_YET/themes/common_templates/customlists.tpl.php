<?php defined('_NOAH') or die('Restricted access'); ?>
<?php global $contentSeparator; ?>

<div class='checkconf'>
  <h1>Let's have an overview on the different kind of item (advertisement) lists in Noah's Classifieds:</h1>
  <ul>
    <li>The most frequently used item lists are the category listings - you can see them whenever you click on the name of a category,</li>
    <li>Search result list: if a search result list contains ads from only one category, it will be displayed just like the category listings - with all the category specific columns,</li>
    <li>All the ads of one user, including the 'My ads' list,</li>
    <li>Special lists: 'Recent ads', 'Popular ads', 'Approved ads', 'Pending ads'</li>
  </ul>
  <p style='font-weight: bold;'>
  If we want to generalize the lists under the latter two points, we can name one common factor: all of them are actually special search result lists!
  E.g. The 'My ads' list is the result of a search for ads where the owner is the currently logged in one. 
  The 'Popular ads' is a result of a search where all the ads are listed ordered by the number they are displayed descending.</p>
  
  This approach opened the way to making the program even more flexible. In the 3.1.0 release, we have added the following changes:
  <ul>
    <li>We introduce the term of "custom list" - this is an item list that admin can create and arbitrarily configure by supplying a search condition and some other properties,</li>
    <li>We replace the special lists of the above latter two points with their pre-configured custom list counterpart! 
    'My ads', 'Recent ads', 'Popular ads' and 'Pending ads' are nothing but ordinary custom lists from now on,</li>
    <li>There are several things you can do with a custom list:
      <ul>
        <li>You can tell which ads it contains (by giving a search condition),</li>
        <li>You can tell what columns it displays and how it looks like,</li>
        <li>You can put a menu point that links to it in any of the four menu bars,</li>
        <li>You can make it so that the list is automatically displayed on any Noah's page! 
        In this case you can specify, which pages you want to see the list on and exactly where the list should appear and how (RSS version only!)</li>
        <li>And of course, you can create any number of new custom lists! It's up to your creativity what you use them for.</li>
      </ul>
    </li>
  </ul>
  <h1>This is a long and complicated page, so let's see what you can do here:</h1>
  <p class='confok'><a href='<?php echo $_SERVER["REQUEST_URI"] ?>#manageList'>Click here to manage the list of custom lists!</a></p>
  <p class='confok'><a href='<?php echo $_SERVER["REQUEST_URI"] ?>#addList'>Click here to create a new custom lists!</a></p>
  <p class='confok'><a href='<?php echo $_SERVER["REQUEST_URI"] ?>#manageCommonFields'>Click here to manage the list of common custom fields!</a></p>
</div>
<a name='manageList' id='manageList'></a>
<?php $this->displayContent("listOfCustomLists"); ?>
<a name='addList' id='addList'></a>
<?php echo $contentSeparator ?> 
<?php $this->displayContent("createCustomList"); ?>
<?php echo $contentSeparator ?> 
<a name='manageCommonFields' id='manageCommonFields'></a>
<div class='checkconf'>
So that the custom  list feature can be even more flexible, it was necessary to add one more major improvement and it was the introduction of 
"common custom fields". You can learn more about the common custom fields from the explanation texts of the custom field create/modify form.
If you read them, you can know that some of the custom item fields can be unique (they belong to only one category) and some can be common 
(common fields appear amongst the custom fields of all the categories). The reason why we display here a separate list of all the common fields 
is that they are essential for the configuration of the custom lists!
<br><br>
The most important advantage of the common fields that they can appear in the advanced search form even if the search is not "category specific".
Similarly: they can be displayed as columns in a search result list (or in other custom lists) even if the list contains items from more than one categories. Without the common fields,
we were restricted to display only those obvious few columns in our custom lists that every ads have per default - like a "TITLE" field, 
"DESCRIPTION" field, category name, owner name and all the other fixed fields. With the common field feature, however, 
we can say create a common field 'Picture' (or make the existing one to be common!) and once it's already common, we can decorate our custom lists 
with a picture column! A featured ad list still looks better if it displays pictures, too, doesn't it?
<br><br>
The below list has one more important meaning: you can use it to customize the advanced search form. The search form has three sections:
'Simple search', 'Advanced search' - it contains only common fields, and 'Category search' - it can contain common and unique fields mixed.
The 'Simple search' section is always there, but from the other two sections, there is always only one displayed. The below list is where you can configure the 
'Advanced search' section! It is important to make it clear that the configuration of the 'Category search' section doesn't happen here! It happens in the 
given 'List of custom fields of this category' list! If you have a common field say 'Picture' and you set it in the 'List of custom fields of this category' list
so that it is searchable, it will appear in the 'Category section'. But if you modify the "same" Picture field in the below list and set its 
'Show in the search form for' property, it will affect the 'Advanced search' section. Similarly, the order of fields you set here will affect the order of fields 
in the 'Advanced search' section. On the other hand, if you change the order of fields in the
'List of custom fields of this category' list, it will refer to the order of fields in the 'Category search' section.
</div>
<?php $this->displayContent("globalCommonFields"); ?>

