-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 30, 2015 at 07:47 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `GoannaApps`
--

-- --------------------------------------------------------

--
-- Table structure for table `registeredUsers`
--

CREATE TABLE IF NOT EXISTS `registeredUsers` (
  `id` int(11) NOT NULL,

  `username` varchar(255) NOT NULL,
-- 255 is the default, it will allow a string of 255 characters or less`

  `sign_up_date` datetime NOT NULL,
-- I chose datetime instead of just "date" in case I need it later.

  `email` varchar(255) NOT NULL,

  `bio` text NOT NULL,
-- Users will have to include some sort of information about themselves (not null).

  `account_permissions` enum('a','b','c') NOT NULL DEFAULT 'a',
-- I decided on 3 (a,b,c) permission levels just in case - default is a.

  `email_activation` enum('0','1') NOT NULL DEFAULT '0'
-- This will ensure that users need to click on "confirm" email link. They will then be 
-- registered to my GoannaApps listing website.

) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
